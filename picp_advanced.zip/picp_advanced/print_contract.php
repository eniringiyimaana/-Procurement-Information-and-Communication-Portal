<?php
session_start();
require_once 'users.php';

if (!isset($_GET['contract_id'])) {
    die("Contract ID is required");
}

$conn = connectDB();
$contract_id = intval($_GET['contract_id']);

$sql = "SELECT c.contract_no, c.total_value, c.award_date, c.status,
               r.rfq_no, r.title AS rfq_title,
               s.name AS supplier_name, s.address AS supplier_address, s.contact_person, s.phone, s.email,
               c.terms, c.payment_terms, c.delivery_terms
        FROM contracts c
        JOIN rfqs r ON c.rfq_id = r.id
        JOIN suppliers s ON c.supplier_id = s.id
        WHERE c.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $contract_id);
$stmt->execute();
$result = $stmt->get_result();
$contract = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Format dates
$award_date = date('F j, Y', strtotime($contract['award_date']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contract <?= htmlspecialchars($contract['contract_no']); ?> | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @media print {
            body * {
                visibility: hidden;
            }
            .print-section, .print-section * {
                visibility: visible;
            }
            .print-section {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }
            .no-print {
                display: none !important;
            }
        }
        
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .print-container {
            background: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            border-radius: 10px;
            margin: 20px auto;
            max-width: 210mm;
            padding: 30px;
        }
        
        .contract-header {
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .company-logo {
            max-width: 180px;
            margin-bottom: 15px;
        }
        
        .contract-title {
            color: #2c3e50;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .contract-number {
            color: #6c757d;
            font-size: 1.1rem;
        }
        
        .section-title {
            border-left: 4px solid #2c3e50;
            padding-left: 10px;
            margin: 25px 0 15px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .signature-area {
            margin-top: 50px;
            border-top: 1px dashed #ccc;
            padding-top: 20px;
        }
        
        .signature-line {
            border-top: 1px solid #000;
            width: 70%;
            margin: 40px 0 5px;
        }
        
        .terms-container {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .watermark {
            position: absolute;
            opacity: 0.1;
            font-size: 8rem;
            font-weight: bold;
            color: #2c3e50;
            transform: rotate(-45deg);
            z-index: -1;
            top: 30%;
            left: 10%;
            white-space: nowrap;
        }
        
        .footer {
            font-size: 0.8rem;
            color: #6c757d;
            text-align: center;
            margin-top: 40px;
        }
        
        .status-badge {
            font-size: 0.9rem;
            padding: 5px 15px;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <div class="container py-4 no-print">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-primary"><i class="fas fa-file-contract me-2"></i>Contract Details</h2>
            <div>
                <button class="btn btn-outline-secondary me-2" onclick="window.history.back()">
                    <i class="fas fa-arrow-left me-1"></i> Back
                </button>
                <button class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print me-1"></i> Print Contract
                </button>
            </div>
        </div>
        
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i> This view is optimized for printing. Click the print button to generate a physical copy.
        </div>
    </div>

    <div class="print-container print-section">
        <!-- Watermark -->
        <div class="watermark">CONTRACT</div>
        
        <!-- Header Section -->
        <div class="contract-header text-center">
            <!-- In a real implementation, you would use your company logo here -->
            <div class="company-logo-placeholder bg-primary text-white d-inline-block p-3 rounded">
                <h4 class="mb-0">YOUR COMPANY</h4>
            </div>
            <h1 class="contract-title mt-3">Procurement Contract</h1>
            <p class="contract-number">Contract No: <?= htmlspecialchars($contract['contract_no']); ?></p>
        </div>
        
        <!-- Parties Section -->
        <div class="row">
            <div class="col-md-6">
                <h4 class="section-title">The Company</h4>
                <p>
                    <strong>Your Company Name</strong><br>
                    123 Business Avenue<br>
                    City, State 12345<br>
                    Phone: (123) 456-7890<br>
                    Email: procurement@yourcompany.com
                </p>
            </div>
            <div class="col-md-6">
                <h4 class="section-title">The Supplier</h4>
                <p>
                    <strong><?= htmlspecialchars($contract['supplier_name']); ?></strong><br>
                    <?= !empty($contract['supplier_address']) ? htmlspecialchars($contract['supplier_address']) . '<br>' : ''; ?>
                    Contact: <?= !empty($contract['contact_person']) ? htmlspecialchars($contract['contact_person']) : 'N/A'; ?><br>
                    Phone: <?= !empty($contract['phone']) ? htmlspecialchars($contract['phone']) : 'N/A'; ?><br>
                    Email: <?= !empty($contract['email']) ? htmlspecialchars($contract['email']) : 'N/A'; ?>
                </p>
            </div>
        </div>
        
        <!-- Contract Details -->
        <h4 class="section-title">Contract Details</h4>
        <div class="table-responsive">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">RFQ Reference</th>
                    <td><?= htmlspecialchars($contract['rfq_no']); ?></td>
                </tr>
                <tr>
                    <th>RFQ Title</th>
                    <td><?= htmlspecialchars($contract['rfq_title']); ?></td>
                </tr>
                <tr>
                    <th>Contract Value</th>
                    <td>$<?= number_format($contract['total_value'], 2); ?></td>
                </tr>
                <tr>
                    <th>Award Date</th>
                    <td><?= $award_date; ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <span class="status-badge 
                            <?= $contract['status'] == 'active' ? 'bg-success' : 
                              ($contract['status'] == 'pending' ? 'bg-warning text-dark' : 'bg-secondary'); ?>">
                            <?= ucfirst($contract['status']); ?>
                        </span>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- Terms and Conditions -->
        <h4 class="section-title">Terms and Conditions</h4>
        <div class="terms-container">
            <?php if (!empty($contract['terms'])): ?>
                <?= nl2br(htmlspecialchars($contract['terms'])); ?>
            <?php else: ?>
                <p class="fst-italic">Standard terms and conditions apply as per company procurement policy.</p>
            <?php endif; ?>
        </div>
        
        <!-- Payment Terms -->
        <h4 class="section-title">Payment Terms</h4>
        <div class="terms-container">
            <?php if (!empty($contract['payment_terms'])): ?>
                <?= nl2br(htmlspecialchars($contract['payment_terms'])); ?>
            <?php else: ?>
                <p>Payment will be made within 30 days of invoice receipt and satisfactory delivery of goods/services.</p>
            <?php endif; ?>
        </div>
        
        <!-- Delivery Terms -->
        <h4 class="section-title">Delivery Terms</h4>
        <div class="terms-container">
            <?php if (!empty($contract['delivery_terms'])): ?>
                <?= nl2br(htmlspecialchars($contract['delivery_terms'])); ?>
            <?php else: ?>
                <p>Delivery must be completed within the timeframe specified in the RFQ documentation.</p>
            <?php endif; ?>
        </div>
        
        <!-- Signatures -->
        <div class="row signature-area">
            <div class="col-md-6">
                <p><strong>For The Company:</strong></p>
                <div class="signature-line"></div>
                <p>Authorized Signature</p>
                <p>Name: ________________________</p>
                <p>Title: ________________________</p>
                <p>Date: ________________________</p>
            </div>
            <div class="col-md-6">
                <p><strong>For The Supplier:</strong></p>
                <div class="signature-line"></div>
                <p>Authorized Signature</p>
                <p>Name: ________________________</p>
                <p>Title: ________________________</p>
                <p>Date: ________________________</p>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <p>Contract <?= htmlspecialchars($contract['contract_no']); ?> | Generated on <?= date('F j, Y'); ?> | <?= $_SESSION["username"]; ?></p>
        </div>
    </div>

    <!-- Print Control Buttons (visible only when printing) -->
    <div class="container mt-3 no-print">
        <div class="d-flex justify-content-center">
            <button class="btn btn-success me-2" onclick="window.print()">
                <i class="fas fa-print me-1"></i> Print Contract
            </button>
            <button class="btn btn-secondary" onclick="window.history.back()">
                <i class="fas fa-arrow-left me-1"></i> Back to Previous Page
            </button>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>