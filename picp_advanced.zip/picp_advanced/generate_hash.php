<?php
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);
echo "The password hash for '{$password}' is: " . $hash;
?>