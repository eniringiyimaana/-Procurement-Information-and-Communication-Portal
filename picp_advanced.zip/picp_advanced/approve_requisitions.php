<?php
session_start();
require_once 'users.php';

// Only allow Procurement Officer (role_id = 2) to access this page
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 2) {
    header("location: dashboard.php");
    exit;
}

$conn = connectDB();
$message = '';
$message_type = '';

// Handle form submission for approval or rejection
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['requisition_id'])) {
    $requisition_id = $_POST['requisition_id'];
    $decision = $_POST['decision'];
    $comment = $_POST['comment'];
    $approver_id = $_SESSION['user_id'];

    $conn->begin_transaction();

    try {
        if ($decision == 'approved') {
            // First, get the requisition's total amount and department ID
            $sql_get_requisition = "SELECT total_amount, department_id FROM requisitions WHERE id = ?";
            $stmt_get_requisition = $conn->prepare($sql_get_requisition);
            $stmt_get_requisition->bind_param("i", $requisition_id);
            $stmt_get_requisition->execute();
            $result_requisition = $stmt_get_requisition->get_result();
            $requisition = $result_requisition->fetch_assoc();
            $stmt_get_requisition->close();

            if ($requisition) {
                $total_amount = $requisition['total_amount'];
                $department_id = $requisition['department_id'];

                // Update the committed_amount in the budgets table
                $sql_budget = "UPDATE budgets SET committed_amount = committed_amount + ? WHERE department_id = ?";
                $stmt_budget = $conn->prepare($sql_budget);
                if (!$stmt_budget) {
                    throw new Exception("Budget update failed: " . $conn->error);
                }
                $stmt_budget->bind_param("di", $total_amount, $department_id);
                $stmt_budget->execute();
                $stmt_budget->close();
            }
        }

        // Update the requisition status
        $sql_requisition = "UPDATE requisitions SET status=?, updated_at=NOW() WHERE id=?";
        $stmt_requisition = $conn->prepare($sql_requisition);
        if (!$stmt_requisition) {
            throw new Exception("Requisition update failed: " . $conn->error);
        }
        $stmt_requisition->bind_param("si", $decision, $requisition_id);
        $stmt_requisition->execute();
        $stmt_requisition->close();

        // Record the approval decision in the approvals table
        $sql_approval = "INSERT INTO approvals (object_type, object_id, approver_id, decision, comment, decided_at) VALUES ('requisition', ?, ?, ?, ?, NOW())";
        $stmt_approval = $conn->prepare($sql_approval);
        if (!$stmt_approval) {
            throw new Exception("Approval record failed: " . $conn->error);
        }
        $stmt_approval->bind_param("iiss", $requisition_id, $approver_id, $decision, $comment);
        $stmt_approval->execute();
        $stmt_approval->close();

        $conn->commit();
        $message = "Requisition ID " . htmlspecialchars($requisition_id) . " has been " . htmlspecialchars($decision) . ".";
        $message_type = 'success';
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Transaction failed: " . $e->getMessage();
        $message_type = 'danger';
    }
}

// Fetch requisitions waiting for approval
$sql = "SELECT r.id, r.requisition_no, r.title, r.total_amount, r.created_at,
               u.name AS requested_by_name,
               d.name AS department_name
        FROM requisitions r
        JOIN users u ON r.requested_by = u.id
        JOIN departments d ON r.department_id = d.id
        WHERE r.status = 'pending_approval'
        ORDER BY r.created_at ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approve Requisitions | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --light-bg: #f8f9fa;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .breadcrumb {
            background-color: transparent;
            padding: 0;
        }
        
        .table th {
            background-color: var(--light-bg);
            border-top: none;
        }
        
        .requisition-card {
            border-left: 4px solid var(--secondary-color);
            transition: all 0.3s;
        }
        
        .requisition-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .badge-pending {
            background-color: #ffc107;
            color: #212529;
        }
        
        .btn-approve {
            background-color: var(--success-color);
            border-color: var(--success-color);
        }
        
        .btn-reject {
            background-color: var(--danger-color);
            border-color: var(--danger-color);
        }
        
        .comment-box {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 10px;
            background-color: var(--light-bg);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Approve Requisitions</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php"><i class="fas fa-home me-1"></i>Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Approve Requisitions</li>
            </ol>
        </nav>

        <!-- Content -->
        <div class="container-fluid">
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-check-circle me-2"></i>Pending Requisition Approvals
                    </div>
                    <span class="badge bg-primary"><?php echo $result->num_rows; ?> Pending</span>
                </div>
                <div class="card-body">
                    <?php if ($result->num_rows > 0): ?>
                        <div class="row">
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <div class="col-md-6 mb-4">
                                    <div class="card requisition-card h-100">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start mb-3">
                                                <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                                                <span class="badge badge-pending">Pending Approval</span>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <div class="col-6">
                                                    <small class="text-muted">Requisition No:</small>
                                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($row['requisition_no']); ?></p>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Amount:</small>
                                                    <p class="mb-0 fw-bold text-primary">$<?php echo number_format($row['total_amount'], 2); ?></p>
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <div class="col-6">
                                                    <small class="text-muted">Department:</small>
                                                    <p class="mb-0"><?php echo htmlspecialchars($row['department_name']); ?></p>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Requested By:</small>
                                                    <p class="mb-0"><?php echo htmlspecialchars($row['requested_by_name']); ?></p>
                                                </div>
                                            </div>
                                            
                                            <small class="text-muted">Created:</small>
                                            <p class="mb-3"><?php echo date('M j, Y g:i A', strtotime($row['created_at'])); ?></p>
                                            
                                            <hr>
                                            
                                            <form method="post" action="approve_requisitions.php">
                                                <input type="hidden" name="requisition_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label">Decision:</label>
                                                    <select name="decision" class="form-select" required>
                                                        <option value="approved">Approve</option>
                                                        <option value="rejected">Reject</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label class="form-label">Comments:</label>
                                                    <textarea name="comment" class="form-control" rows="3" placeholder="Add your comments here..."></textarea>
                                                </div>
                                                
                                                <div class="d-grid gap-2">
                                                    <button type="submit" class="btn btn-approve">
                                                        <i class="fas fa-check me-1"></i> Submit Decision
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-check-circle fs-1 text-success mb-3"></i>
                            <h4>No Pending Requisitions</h4>
                            <p class="text-muted">All requisitions have been processed. Check back later for new requests.</p>
                            <a href="dashboard.php" class="btn btn-primary">
                                <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>