<?php
// manage_departments.php
session_start();
require_once 'users.php'; // Includes database connection functions

// Check if the user is logged in and has the correct role
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    // Only allow Admin (role_id = 1) to access this page
    header("location: dashboard.php");
    exit;
}

$conn = connectDB();

// Handle delete request
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $dept_id = intval($_GET['id']);
    
    // Check if department is associated with any users
    $sql_check_users = "SELECT COUNT(*) FROM users WHERE department_id = ?";
    $stmt_check_users = $conn->prepare($sql_check_users);
    $stmt_check_users->bind_param("i", $dept_id);
    $stmt_check_users->execute();
    $stmt_check_users->bind_result($user_count);
    $stmt_check_users->fetch();
    $stmt_check_users->close();

    if ($user_count > 0) {
        $message = "Cannot delete department. There are {$user_count} users associated with it.";
        $message_type = 'danger';
    } else {
        $sql_delete = "DELETE FROM departments WHERE id = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $dept_id);
        if ($stmt_delete->execute()) {
            $message = "Department deleted successfully!";
            $message_type = 'success';
        } else {
            $message = "Error deleting department: " . $stmt_delete->error;
            $message_type = 'danger';
        }
        $stmt_delete->close();
    }
}

// Fetch all departments
$sql = "SELECT id, name, description, created_at FROM departments ORDER BY name ASC";
$result = $conn->query($sql);
$message = isset($message) ? $message : '';
$message_type = isset($message_type) ? $message_type : '';

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Departments | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .department-card {
            border-left: 4px solid var(--secondary-color);
            transition: all 0.3s;
        }
        
        .department-card:hover {
            border-left-color: var(--primary-color);
        }
        
        .action-btn {
            padding: 5px 10px;
            border-radius: 4px;
            transition: all 0.2s;
        }
        
        .action-btn:hover {
            background-color: #f8f9fa;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="manage_departments.php">
                    <i class="fas fa-building"></i>
                    <span>Manage Departments</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_budgets.php">
                    <i class="fas fa-wallet"></i>
                    <span>Manage Budgets</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Departments</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Department Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Quick Stats -->
            <?php
            // Reconnect to get department count
            $conn = connectDB();
            $sql_count = "SELECT COUNT(*) as dept_count FROM departments";
            $result_count = $conn->query($sql_count);
            $dept_count = $result_count->fetch_assoc()['dept_count'];
            $conn->close();
            ?>
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary"><?php echo $dept_count; ?></div>
                        <div class="stats-label">Total Departments</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="stats-label">Department Management</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <a href="add_department.php" class="dashboard-card stats-card text-decoration-none">
                        <div class="stats-number text-secondary">
                            <i class="fas fa-plus-circle"></i>
                        </div>
                        <div class="stats-label">Add New Department</div>
                    </a>
                </div>
            </div>

            <!-- Department List -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-building me-2"></i>Department Management</span>
                    <a href="add_department.php" class="btn btn-light">
                        <i class="fas fa-plus me-1"></i> Add New Department
                    </a>
                </div>
                <div class="card-body">
                    <?php if ($result && $result->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Department Name</th>
                                    <th>Description</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-building text-muted me-2"></i>
                                            <strong><?php echo htmlspecialchars($row['name']); ?></strong>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['description']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="edit_department.php?id=<?php echo htmlspecialchars($row['id']); ?>" class="btn btn-outline-primary btn-sm">
                                                <i class="fas fa-edit me-1"></i> Edit
                                            </a>
                                            <a href="manage_departments.php?action=delete&id=<?php echo htmlspecialchars($row['id']); ?>" 
                                               class="btn btn-outline-danger btn-sm" 
                                               onclick="return confirm('Are you sure you want to delete this department?');">
                                                <i class="fas fa-trash me-1"></i> Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-building fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No Departments Found</h4>
                        <p class="text-muted">Get started by adding your first department.</p>
                        <a href="add_department.php" class="btn btn-primary mt-2">
                            <i class="fas fa-plus me-1"></i> Add Department
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>