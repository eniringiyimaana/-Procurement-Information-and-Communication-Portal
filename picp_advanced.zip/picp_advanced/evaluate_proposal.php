<?php
// evaluate_proposal.php
session_start();
require_once 'users.php';

// Only Admin (role_id=1) or Procurement Officer (role_id=2) can access
if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: dashboard.php");
    exit;
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$conn = connectDB();
$proposal_details = null;
$message = '';
$error = '';

if (isset($_GET['proposal_id']) && !empty($_GET['proposal_id'])) {
    $proposal_id = intval($_GET['proposal_id']);

    // Fetch proposal details
    $sql_proposal = "
        SELECT sp.id, sp.submitted_at AS proposal_date, sp.status, sp.proposal_file, sp.amount,
               r.id AS rfq_id, r.rfq_no, r.title AS rfq_title,
               s.id AS supplier_id, s.name AS supplier_name, s.contact_person, s.contact_email
        FROM supplier_proposals sp
        JOIN rfqs r ON sp.rfq_id = r.id
        JOIN suppliers s ON sp.supplier_id = s.id
        WHERE sp.id = ?
    ";
    $stmt_proposal = $conn->prepare($sql_proposal);
    $stmt_proposal->bind_param("i", $proposal_id);
    $stmt_proposal->execute();
    $result_proposal = $stmt_proposal->get_result();
    $proposal_details = $result_proposal->fetch_assoc();
    $stmt_proposal->close();
} else {
    $error = "No proposal selected.";
}

// Handle decision (Approve or Reject)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['proposal_id'])) {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid CSRF token. Please try again.";
    } else {
        $proposal_id = $_POST['proposal_id'];
        $decision = $_POST['decision'];

        $conn->begin_transaction();

        try {
            if ($decision === 'approve') {
                // Update proposal status
                $sql_update = "UPDATE supplier_proposals SET status='accepted' WHERE id=?";
                $stmt = $conn->prepare($sql_update);
                $stmt->bind_param("i", $proposal_id);
                $stmt->execute();
                $stmt->close();

                // Create contract
                $contract_no = 'CON-' . date('Ymd') . '-' . substr(md5(uniqid(rand(), true)), 0, 8);
                $award_date = date("Y-m-d");
                $total_value = $proposal_details['amount'];
                $status = 'active';

                $sql_contract = "INSERT INTO contracts (contract_no, rfq_id, supplier_id, award_date, total_value, status)
                                 VALUES (?, ?, ?, ?, ?, ?)";
                $stmt_contract = $conn->prepare($sql_contract);
                $stmt_contract->bind_param(
                    "siisds",
                    $contract_no,
                    $proposal_details['rfq_id'],
                    $proposal_details['supplier_id'],
                    $award_date,
                    $total_value,
                    $status
                );
                $stmt_contract->execute();
                $contract_id = $stmt_contract->insert_id;
                $stmt_contract->close();

                // Link proposal to contract
                $sql_link = "UPDATE supplier_proposals SET contract_id=? WHERE id=?";
                $stmt_link = $conn->prepare($sql_link);
                $stmt_link->bind_param("ii", $contract_id, $proposal_id);
                $stmt_link->execute();
                $stmt_link->close();

                // Update RFQ status
                $sql_update_rfq = "UPDATE rfqs SET status='awarded', awarded_proposal_id=? WHERE id=?";
                $stmt_rfq = $conn->prepare($sql_update_rfq);
                $stmt_rfq->bind_param("ii", $proposal_id, $proposal_details['rfq_id']);
                $stmt_rfq->execute();
                $stmt_rfq->close();

                $message = "Proposal approved and contract created successfully!";

            } elseif ($decision === 'reject') {
                $sql_update = "UPDATE supplier_proposals SET status='rejected' WHERE id=?";
                $stmt = $conn->prepare($sql_update);
                $stmt->bind_param("i", $proposal_id);
                $stmt->execute();
                $stmt->close();
                $message = "Proposal rejected successfully.";
            }

            $conn->commit();

            // Refresh proposal details
            $stmt_refresh = $conn->prepare("
                SELECT sp.id, sp.submitted_at AS proposal_date, sp.status, sp.proposal_file, sp.amount,
                       r.id AS rfq_id, r.rfq_no, r.title AS rfq_title,
                       s.id AS supplier_id, s.name AS supplier_name, s.contact_person, s.contact_email
                FROM supplier_proposals sp
                JOIN rfqs r ON sp.rfq_id = r.id
                JOIN suppliers s ON sp.supplier_id = s.id
                WHERE sp.id = ?
            ");
            $stmt_refresh->bind_param("i", $proposal_id);
            $stmt_refresh->execute();
            $result_refresh = $stmt_refresh->get_result();
            $proposal_details = $result_refresh->fetch_assoc();
            $stmt_refresh->close();

        } catch (Exception $e) {
            $conn->rollback();
            $error = "Transaction failed: " . $e->getMessage();
        }
    }
}

$conn->close();

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = isset($_SESSION['role_name']) ? $_SESSION['role_name'] : getUserRoleName($user_role_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluate Proposal | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 0.35em 0.65em;
        }
        
        .info-card {
            border-left: 4px solid var(--secondary-color);
            background-color: #f8f9fa;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        .decision-btn {
            min-width: 120px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1 || $user_role_id == 2) { ?>
            <li class="nav-item">
                <a class="nav-link" href="view_proposals.php">
                    <i class="fas fa-file-contract"></i>
                    <span>View Proposals</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="#">
                    <i class="fas fa-clipboard-check"></i>
                    <span>Evaluate Proposals</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Evaluate Proposal</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <a href="view_proposals.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to All Proposals
                </a>
            </div>
            
            <?php if ($proposal_details): ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-clipboard-check me-2"></i>Proposal Evaluation
                        </div>
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <h5>Proposal Details</h5>
                                    <table class="table table-sm">
                                        <tr>
                                            <th width="40%">Proposal ID:</th>
                                            <td>#<?php echo htmlspecialchars($proposal_details['id']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>RFQ Number:</th>
                                            <td><?php echo htmlspecialchars($proposal_details['rfq_no']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>RFQ Title:</th>
                                            <td><?php echo htmlspecialchars($proposal_details['rfq_title']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date Submitted:</th>
                                            <td><?php echo date('M j, Y g:i A', strtotime($proposal_details['proposal_date'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Amount:</th>
                                            <td class="fw-bold">$<?php echo number_format($proposal_details['amount'], 2); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Status:</th>
                                            <td>
                                                <span class="badge 
                                                    <?php 
                                                    if ($proposal_details['status'] == 'accepted') echo 'bg-success';
                                                    elseif ($proposal_details['status'] == 'rejected') echo 'bg-danger';
                                                    else echo 'bg-warning';
                                                    ?> status-badge">
                                                    <?php echo ucfirst($proposal_details['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                
                                <div class="col-md-6">
                                    <h5>Supplier Information</h5>
                                    <table class="table table-sm">
                                        <tr>
                                            <th width="40%">Supplier:</th>
                                            <td><?php echo htmlspecialchars($proposal_details['supplier_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Person:</th>
                                            <td><?php echo htmlspecialchars($proposal_details['contact_person']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Email:</th>
                                            <td><?php echo htmlspecialchars($proposal_details['contact_email']); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <h5>Proposal Document</h5>
                                <?php if ($proposal_details['proposal_file']): ?>
                                    <a href="<?php echo htmlspecialchars($proposal_details['proposal_file']); ?>" 
                                       target="_blank" class="btn btn-outline-primary">
                                        <i class="fas fa-download me-1"></i>Download Proposal
                                    </a>
                                <?php else: ?>
                                    <p class="text-muted">No proposal file uploaded.</p>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($proposal_details['status'] === 'pending'): ?>
                            <div class="mt-4">
                                <h5>Evaluation Decision</h5>
                                <form method="post" id="evaluationForm">
                                    <input type="hidden" name="proposal_id" value="<?php echo htmlspecialchars($proposal_details['id']); ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="decision" class="form-label">Decision:</label>
                                            <select name="decision" id="decision" class="form-select" required>
                                                <option value="">Select Decision</option>
                                                <option value="approve">Approve Proposal</option>
                                                <option value="reject">Reject Proposal</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex gap-2 mt-3">
                                        <button type="submit" class="btn btn-success decision-btn">
                                            <i class="fas fa-check-circle me-1"></i>Submit Decision
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-1"></i>
                                    This proposal has already been <?php echo $proposal_details['status']; ?>.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-info-circle me-2"></i>Evaluation Guidelines
                        </div>
                        <div class="card-body">
                            <div class="alert alert-info">
                                <h6><i class="fas fa-lightbulb me-1"></i>Evaluation Criteria</h6>
                                <ul class="small mb-0 ps-3">
                                    <li>Price competitiveness</li>
                                    <li>Technical compliance with requirements</li>
                                    <li>Supplier reputation and past performance</li>
                                    <li>Delivery timeline</li>
                                    <li>Quality assurance measures</li>
                                </ul>
                            </div>
                            
                            <div class="alert alert-warning">
                                <h6><i class="fas fa-exclamation-triangle me-1"></i>Important Notes</h6>
                                <ul class="small mb-0 ps-3">
                                    <li>Approving a proposal will automatically create a contract</li>
                                    <li>The RFQ status will be updated to "Awarded"</li>
                                    <li>All decisions are logged for audit purposes</li>
                                    <li>Ensure compliance with procurement policies</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-card mt-4">
                        <div class="card-header">
                            <i class="fas fa-history me-2"></i>Quick Actions
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="view_proposals.php" class="btn btn-outline-primary">
                                    <i class="fas fa-list me-1"></i>View All Proposals
                                </a>
                                <a href="create_rfq.php" class="btn btn-outline-success">
                                    <i class="fas fa-plus me-1"></i>Create New RFQ
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <?php echo htmlspecialchars($error ? $error : "Proposal not found."); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        // Form validation
        document.getElementById('evaluationForm').addEventListener('submit', function(e) {
            const decision = document.getElementById('decision').value;
            
            if (!decision) {
                e.preventDefault();
                alert('Please select a decision.');
                document.getElementById('decision').focus();
                return false;
            }
            
            if (decision === 'approve') {
                if (!confirm('Are you sure you want to APPROVE this proposal? This action will create a contract and cannot be undone.')) {
                    e.preventDefault();
                    return false;
                }
            } else if (decision === 'reject') {
                if (!confirm('Are you sure you want to REJECT this proposal? This action cannot be undone.')) {
                    e.preventDefault();
                    return false;
                }
            }
        });
    </script>
</body>
</html>