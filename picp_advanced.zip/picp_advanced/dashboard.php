<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

$user_role_id = $_SESSION['role_id'];

// Get the role name for display purposes
$role_name = getUserRoleName($user_role_id);
$_SESSION['role_name'] = $role_name;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .quick-action {
            background: var(--light-bg);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }
        
        .quick-action:hover {
            background: var(--secondary-color);
            color: white;
            cursor: pointer;
        }
        
        .quick-action i {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--secondary-color);
        }
        
        .quick-action:hover i {
            color: white;
        }
        
        .section-title {
            border-left: 4px solid var(--secondary-color);
            padding-left: 10px;
            margin: 25px 0 15px;
            font-weight: 600;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Dashboard</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Dashboard Content -->
        <div class="container-fluid">
            <!-- Quick Stats -->
            <div class="row">
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number">5</div>
                        <div class="stats-label">Pending Requisitions</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number">12</div>
                        <div class="stats-label">Approved This Month</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number">3</div>
                        <div class="stats-label">Pending Approvals</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number">7</div>
                        <div class="stats-label">New Messages</div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row mt-4">
                <div class="col-12">
                    <h4 class="section-title">Quick Actions</h4>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="dashboard-card quick-action text-center" onclick="location.href='create_requisition.php'">
                        <i class="fas fa-file-alt"></i>
                        <h6>Create Requisition</h6>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="dashboard-card quick-action text-center" onclick="location.href='inbox.php'">
                        <i class="fas fa-inbox"></i>
                        <h6>Check Inbox</h6>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="dashboard-card quick-action text-center" onclick="location.href='view_my_requisitions.php'">
                        <i class="fas fa-list"></i>
                        <h6>My Requisitions</h6>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="dashboard-card quick-action text-center" onclick="location.href='compose_message.php'">
                        <i class="fas fa-envelope"></i>
                        <h6>Compose Message</h6>
                    </div>
                </div>
            </div>

            <!-- Main Dashboard Sections -->
            <div class="row mt-4">
                <!-- General Actions -->
                <div class="col-md-6">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-cogs me-2"></i>General Actions
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item border-0"><a href="create_requisition.php" class="text-decoration-none"><i class="fas fa-plus-circle me-2 text-primary"></i>Create New Requisition</a></li>
                                <li class="list-group-item border-0"><a href="view_my_requisitions.php" class="text-decoration-none"><i class="fas fa-list me-2 text-primary"></i>View My Requisitions</a></li>
                                <li class="list-group-item border-0"><a href="profile.php" class="text-decoration-none"><i class="fas fa-user me-2 text-primary"></i>My Profile</a></li>
                                <li class="list-group-item border-0"><a href="settings.php" class="text-decoration-none"><i class="fas fa-cog me-2 text-primary"></i>Settings</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Messaging & Notifications -->
                <div class="col-md-6">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-envelope me-2"></i>Messaging & Notifications
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item border-0"><a href="inbox.php" class="text-decoration-none"><i class="fas fa-inbox me-2 text-primary"></i>Inbox</a></li>
                                <li class="list-group-item border-0"><a href="compose_message.php" class="text-decoration-none"><i class="fas fa-edit me-2 text-primary"></i>Compose Message</a></li>
                                <li class="list-group-item border-0"><a href="notifications.php" class="text-decoration-none"><i class="fas fa-bell me-2 text-primary"></i>My Notifications</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Role-Based Sections -->
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <div class="row mt-4">
                <div class="col-12">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-shopping-cart me-2"></i>Procurement & Finance
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item border-0"><a href="approve_requisitions.php" class="text-decoration-none"><i class="fas fa-check me-2 text-success"></i>Approve Requisitions</a></li>
                                        <li class="list-group-item border-0"><a href="create_po.php" class="text-decoration-none"><i class="fas fa-file-invoice me-2 text-success"></i>Create Purchase Order</a></li>
                                        <li class="list-group-item border-0"><a href="manage_purchase_orders.php" class="text-decoration-none"><i class="fas fa-tasks me-2 text-success"></i>Manage Purchase Orders</a></li>
                                        <li class="list-group-item border-0"><a href="goods_receipt.php" class="text-decoration-none"><i class="fas fa-truck-loading me-2 text-success"></i>Goods Receipt (GRN)</a></li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item border-0"><a href="create_invoice.php" class="text-decoration-none"><i class="fas fa-receipt me-2 text-success"></i>Create Invoice</a></li>
                                        <li class="list-group-item border-0"><a href="manage_invoices.php" class="text-decoration-none"><i class="fas fa-file-invoice-dollar me-2 text-success"></i>Manage Invoices</a></li>
                                        <li class="list-group-item border-0"><a href="manage_payments.php" class="text-decoration-none"><i class="fas fa-money-check me-2 text-success"></i>Manage Payments</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>

            <!-- System Administration (Admin Only) -->
<?php if ($user_role_id == 1) { ?>
    <div class="row mt-4">
        <div class="col-12">
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-cogs me-2"></i>System Administration
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item border-0"><a href="manage_users.php" class="text-decoration-none"><i class="fas fa-users me-2 text-danger"></i>Manage Users</a></li>
                                <li class="list-group-item border-0"><a href="manage_departments.php" class="text-decoration-none"><i class="fas fa-building me-2 text-danger"></i>Manage Departments</a></li>
                                <li class="list-group-item border-0"><a href="add_department.php" class="text-decoration-none"><i class="fas fa-plus-circle me-2 text-danger"></i>Add Department</a></li>
                                <li class="list-group-item border-0"><a href="manage_items.php" class="text-decoration-none"><i class="fas fa-boxes me-2 text-danger"></i>Manage Inventory Items</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item border-0"><a href="manage_gl_accounts.php" class="text-decoration-none"><i class="fas fa-chart-line me-2 text-danger"></i>Manage GL Accounts</a></li>
                                <li class="list-group-item border-0"><a href="manage_spend_categories.php" class="text-decoration-none"><i class="fas fa-tags me-2 text-danger"></i>Manage Spend Categories</a></li>
                                <li class="list-group-item border-0"><a href="manage_budgets.php" class="text-decoration-none"><i class="fas fa-wallet me-2 text-danger"></i>Manage Budgets</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
            
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>