<?php
session_start();
require_once 'users.php'; // Reuse the database connection

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

// Get user role for conditional elements
$user_role_id = $_SESSION['role_id'];

// In a full implementation, you would query the database here to fetch notifications for $_SESSION['user_id']
// For example:
// $conn = connectDB();
// $sql = "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
// $stmt = $conn->prepare($sql);
// $stmt->bind_param("i", $_SESSION['user_id']);
// $stmt->execute();
// $result = $stmt->get_result();
// $notifications = $result->fetch_all(MYSQLI_ASSOC);
// $stmt->close();
// $conn->close();

// Placeholder data for demonstration
$notifications = [
    ['id' => 1, 'message' => 'Your requisition #123 has been approved.', 'read_status' => 'unread', 'created_at' => '2025-08-26 10:00:00', 'type' => 'success'],
    ['id' => 2, 'message' => 'A new purchase order #PO-12345 has been created.', 'read_status' => 'read', 'created_at' => '2025-08-25 15:30:00', 'type' => 'info'],
    ['id' => 3, 'message' => 'The invoice for PO #12345 is now overdue.', 'read_status' => 'unread', 'created_at' => '2025-08-24 09:00:00', 'type' => 'danger'],
    ['id' => 4, 'message' => 'Your profile information was updated successfully.', 'read_status' => 'read', 'created_at' => '2025-08-23 14:20:00', 'type' => 'success'],
    ['id' => 5, 'message' => 'Requisition #124 requires additional information before approval.', 'read_status' => 'unread', 'created_at' => '2025-08-22 11:45:00', 'type' => 'warning'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .notification-item {
            border-left: 4px solid transparent;
            transition: all 0.2s;
        }
        
        .notification-item.unread {
            background-color: #f8f9fa;
            border-left-color: var(--secondary-color);
        }
        
        .notification-item:hover {
            background-color: #e9ecef;
        }
        
        .notification-dot {
            height: 10px;
            width: 10px;
            background-color: var(--secondary-color);
            border-radius: 50%;
            display: inline-block;
        }
        
        .notification-type-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        
        .notification-type-success {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .notification-type-info {
            background-color: rgba(23, 162, 184, 0.1);
            color: #17a2b8;
        }
        
        .notification-type-warning {
            background-color: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        
        .notification-type-danger {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .filter-buttons .btn {
            border-radius: 20px;
            margin-right: 8px;
            margin-bottom: 10px;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 0;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 5rem;
            margin-bottom: 20px;
            color: #dee2e6;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="notifications.php">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Notifications</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Notifications Content -->
        <div class="container-fluid">
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-bell me-2"></i>My Notifications
                    </div>
                    <div class="filter-buttons">
                        <button class="btn btn-sm btn-outline-primary active" data-filter="all">All</button>
                        <button class="btn btn-sm btn-outline-primary" data-filter="unread">Unread</button>
                        <button class="btn btn-sm btn-outline-primary" data-filter="read">Read</button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <?php if (count($notifications) > 0) { ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($notifications as $notification) { 
                                $icon_class = '';
                                $type_class = '';
                                
                                switch($notification['type']) {
                                    case 'success':
                                        $icon_class = 'fa-check-circle';
                                        $type_class = 'notification-type-success';
                                        break;
                                    case 'info':
                                        $icon_class = 'fa-info-circle';
                                        $type_class = 'notification-type-info';
                                        break;
                                    case 'warning':
                                        $icon_class = 'fa-exclamation-triangle';
                                        $type_class = 'notification-type-warning';
                                        break;
                                    case 'danger':
                                        $icon_class = 'fa-exclamation-circle';
                                        $type_class = 'notification-type-danger';
                                        break;
                                    default:
                                        $icon_class = 'fa-bell';
                                        $type_class = 'notification-type-info';
                                }
                            ?>
                                <div class="list-group-item notification-item <?php echo $notification['read_status'] == 'unread' ? 'unread' : ''; ?>" data-status="<?php echo $notification['read_status']; ?>">
                                    <div class="d-flex align-items-center">
                                        <div class="notification-type-icon <?php echo $type_class; ?>">
                                            <i class="fas <?php echo $icon_class; ?>"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="mb-1 fw-bold"><?php echo htmlspecialchars($notification['message']); ?></p>
                                                <?php if ($notification['read_status'] == 'unread') { ?>
                                                    <span class="notification-dot"></span>
                                                <?php } ?>
                                            </div>
                                            <small class="text-muted"><?php echo date('M j, Y \a\t g:i A', strtotime($notification['created_at'])); ?></small>
                                        </div>
                                        <div class="dropdown ms-3">
                                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end">
                                                <?php if ($notification['read_status'] == 'unread') { ?>
                                                    <li><a class="dropdown-item mark-as-read" href="#" data-id="<?php echo $notification['id']; ?>"><i class="fas fa-check me-2"></i>Mark as read</a></li>
                                                <?php } else { ?>
                                                    <li><a class="dropdown-item mark-as-unread" href="#" data-id="<?php echo $notification['id']; ?>"><i class="fas fa-circle me-2"></i>Mark as unread</a></li>
                                                <?php } ?>
                                                <li><a class="dropdown-item" href="#"><i class="fas fa-trash me-2"></i>Delete</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    <?php } else { ?>
                        <div class="empty-state">
                            <i class="fas fa-bell-slash"></i>
                            <h4>No notifications yet</h4>
                            <p>When you have notifications, they'll appear here.</p>
                        </div>
                    <?php } ?>
                </div>
                <?php if (count($notifications) > 0) { ?>
                <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                    <div>
                        <button class="btn btn-sm btn-outline-primary mark-all-read">
                            <i class="fas fa-check-double me-1"></i> Mark all as read
                        </button>
                    </div>
                    <div>
                        <button class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-trash me-1"></i> Clear all
                        </button>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Filter buttons functionality
            const filterButtons = document.querySelectorAll('.filter-buttons .btn');
            const notificationItems = document.querySelectorAll('.notification-item');
            
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const filter = this.getAttribute('data-filter');
                    
                    // Update active button
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Filter notifications
                    notificationItems.forEach(item => {
                        if (filter === 'all') {
                            item.style.display = 'block';
                        } else {
                            const status = item.getAttribute('data-status');
                            if (status === filter) {
                                item.style.display = 'block';
                            } else {
                                item.style.display = 'none';
                            }
                        }
                    });
                });
            });
            
            // Mark as read/unread functionality
            const markAsReadButtons = document.querySelectorAll('.mark-as-read');
            const markAsUnreadButtons = document.querySelectorAll('.mark-as-unread');
            const markAllReadButton = document.querySelector('.mark-all-read');
            
            markAsReadButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const notificationId = this.getAttribute('data-id');
                    // In a real implementation, you would send an AJAX request to update the notification status
                    const notificationItem = this.closest('.notification-item');
                    notificationItem.classList.remove('unread');
                    notificationItem.setAttribute('data-status', 'read');
                    notificationItem.querySelector('.notification-dot').style.display = 'none';
                    
                    // Show a temporary success message
                    showToast('Notification marked as read');
                });
            });
            
            markAsUnreadButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const notificationId = this.getAttribute('data-id');
                    // In a real implementation, you would send an AJAX request to update the notification status
                    const notificationItem = this.closest('.notification-item');
                    notificationItem.classList.add('unread');
                    notificationItem.setAttribute('data-status', 'unread');
                    const dot = document.createElement('span');
                    dot.className = 'notification-dot';
                    notificationItem.querySelector('.flex-grow-1 .d-flex').appendChild(dot);
                    
                    // Show a temporary success message
                    showToast('Notification marked as unread');
                });
            });
            
            if (markAllReadButton) {
                markAllReadButton.addEventListener('click', function() {
                    // In a real implementation, you would send an AJAX request to update all notifications
                    notificationItems.forEach(item => {
                        item.classList.remove('unread');
                        item.setAttribute('data-status', 'read');
                        const dot = item.querySelector('.notification-dot');
                        if (dot) dot.style.display = 'none';
                    });
                    
                    // Show a temporary success message
                    showToast('All notifications marked as read');
                });
            }
            
            // Helper function to show toast messages
            function showToast(message) {
                // Create toast element
                const toast = document.createElement('div');
                toast.className = 'position-fixed bottom-0 end-0 p-3';
                toast.style.zIndex = '11';
                toast.innerHTML = `
                    <div id="liveToast" class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="toast-header">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <strong class="me-auto">System Message</strong>
                            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                            ${message}
                        </div>
                    </div>
                `;
                
                document.body.appendChild(toast);
                
                // Remove toast after 3 seconds
                setTimeout(() => {
                    toast.remove();
                }, 3000);
            }
        });
    </script>
</body>
</html>