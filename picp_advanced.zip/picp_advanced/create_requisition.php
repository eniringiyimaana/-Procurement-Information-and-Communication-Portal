<?php 
session_start();
require_once 'users.php';

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

// Get user role name for display
$user_role_id = $_SESSION['role_id'];
$role_name = getUserRoleName($user_role_id);
$_SESSION['role_name'] = $role_name;

$message = '';
$departments = [];
$items = [];
$users = [];

$conn = connectDB();

// Fetch all users for the "Requested By" dropdown
$sql_users = "SELECT id, name FROM users ORDER BY name ASC";
$users_result = $conn->query($sql_users);
if ($users_result) {
    while ($row = $users_result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Fetch departments for the form dropdown
$sql_departments = "SELECT id, name FROM departments";
$departments_result = $conn->query($sql_departments);
if ($departments_result) {
    while ($row = $departments_result->fetch_assoc()) {
        $departments[] = $row;
    }
}

// Fetch items and their associated GL accounts and spend categories
$sql_items = "SELECT i.id, i.item_description, i.unit_of_measure, i.spend_category_id, ga.account_name, ga.account_no, ga.id as gl_account_id
              FROM items i
              JOIN gl_accounts ga ON i.gl_account_id = ga.id
              ORDER BY i.item_description ASC";
$items_result = $conn->query($sql_items);
if ($items_result) {
    while ($row = $items_result->fetch_assoc()) {
        $items[] = $row;
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $title = $_POST['title'] ?? '';
    $justification = $_POST['justification'] ?? '';
    $requested_by = $_POST['requested_by'] ?? 0;
    $department_id = $_POST['department_id'] ?? 0;
    $total_estimated_cost = 0;

    // Generate a unique requisition number
    $requisition_no = 'REQ-' . date('Y-m-d') . '-' . substr(md5(uniqid(rand(), true)), 0, 8);

    // Calculate total estimated cost
    if (isset($_POST['estimated_cost']) && is_array($_POST['estimated_cost'])) {
        foreach ($_POST['estimated_cost'] as $cost) {
            $total_estimated_cost += floatval($cost);
        }
    }

    $item_ids = $_POST['item_id'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    $estimated_costs = $_POST['estimated_cost'] ?? [];
    $gl_account_ids = $_POST['gl_account_id'] ?? [];

    $count = min(count($item_ids), count($quantities), count($estimated_costs), count($gl_account_ids));

    $conn->begin_transaction();
    try {
        if (empty($title) || empty($justification) || empty($requested_by) || empty($department_id)) {
            throw new Exception("Please fill all required fields.");
        }

        // Insert requisition
        $sql_requisition = "INSERT INTO requisitions 
                            (requisition_no, title, justification, created_by, requested_by, department_id, total_amount, total_estimated_cost) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_requisition = $conn->prepare($sql_requisition);
        if (!$stmt_requisition) {
            throw new Exception("Requisition statement failed: " . $conn->error);
        }
        $stmt_requisition->bind_param("sssiiidd", $requisition_no, $title, $justification, $_SESSION['user_id'], $requested_by, $department_id, $total_estimated_cost, $total_estimated_cost);
        $stmt_requisition->execute();
        $requisition_id = $stmt_requisition->insert_id;
        $stmt_requisition->close();

        // Insert items
        $sql_items = "INSERT INTO requisition_items (requisition_id, item_id, quantity, estimated_cost, gl_account_id) VALUES (?, ?, ?, ?, ?)";
        $stmt_items = $conn->prepare($sql_items);
        if (!$stmt_items) {
            throw new Exception("Requisition items statement failed: " . $conn->error);
        }

        for ($i = 0; $i < $count; $i++) {
            $stmt_items->bind_param("iiidd", $requisition_id, $item_ids[$i], $quantities[$i], $estimated_costs[$i], $gl_account_ids[$i]);
            $stmt_items->execute();
        }
        $stmt_items->close();

        $conn->commit();
        $message = '<div class="alert alert-success" role="alert">New requisition created successfully with number ' . htmlspecialchars($requisition_no) . '</div>';
    } catch (Exception $e) {
        $conn->rollback();
        $message = '<div class="alert alert-danger" role="alert">Transaction failed: ' . $e->getMessage() . '</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Requisition | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .item-row {
            border-left: 4px solid var(--secondary-color);
            padding: 20px;
            margin-bottom: 20px;
            background-color: var(--light-bg);
            border-radius: 8px;
        }
        
        .total-display {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary-color);
            padding: 12px 20px;
            background-color: #eaecf4;
            border-radius: 8px;
        }
        
        .required-field::after {
            content: "*";
            color: var(--accent-color);
            margin-left: 4px;
        }
        
        .btn-add-item {
            background-color: var(--secondary-color);
            color: white;
            border: none;
        }
        
        .btn-add-item:hover {
            background-color: #2980b9;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Create New Requisition</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="dashboard-card mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h4 class="m-0"><i class="fas fa-file-alt me-2"></i>Create New Requisition</h4>
                            <a href="dashboard.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                            </a>
                        </div>
                        <div class="card-body">
                            <?php echo $message; ?>
                            
                            <div class="alert alert-info mb-4">
                                <h5 class="alert-heading"><i class="fas fa-info-circle me-2"></i>Requisition Information</h5>
                                <p class="mb-0">Fill out the form below to create a new requisition. All fields are required.</p>
                            </div>

                            <form action="create_requisition.php" method="post" id="requisitionForm">
                                <div class="dashboard-card mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0"><i class="fas fa-info-circle me-2"></i>Basic Information</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group mb-3">
                                                    <label for="title" class="form-label required-field">Requisition Title</label>
                                                    <input type="text" id="title" name="title" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group mb-3">
                                                    <label for="justification" class="form-label required-field">Justification</label>
                                                    <textarea id="justification" name="justification" class="form-control" rows="4" required></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="requested_by" class="form-label required-field">Requested By</label>
                                                    <select id="requested_by" name="requested_by" class="form-select" required>
                                                        <option value="">Select User</option>
                                                        <?php foreach ($users as $user) { ?>
                                                            <option value="<?php echo htmlspecialchars($user['id']); ?>"><?php echo htmlspecialchars($user['name']); ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="department_id" class="form-label required-field">Department</label>
                                                    <select id="department_id" name="department_id" class="form-select" required>
                                                        <option value="">Select Department</option>
                                                        <?php foreach ($departments as $department) { ?>
                                                            <option value="<?php echo htmlspecialchars($department['id']); ?>"><?php echo htmlspecialchars($department['name']); ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="dashboard-card mb-4">
                                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                        <h6 class="m-0"><i class="fas fa-list-alt me-2"></i>Items</h6>
                                        <button type="button" class="btn btn-add-item" onclick="addItemRow()">
                                            <i class="fas fa-plus me-1"></i> Add Item
                                        </button>
                                    </div>
                                    <div class="card-body">
                                        <div id="items-container">
                                            <div class="item-row">
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <div class="form-group mb-3">
                                                            <label class="form-label required-field">Select Item</label>
                                                            <select name="item_id[]" class="form-select" required onchange="updateGLAccount(this)">
                                                                <?php foreach ($items as $item) { ?>
                                                                    <option value="<?php echo htmlspecialchars($item['id']); ?>" data-gl-account-id="<?php echo htmlspecialchars($item['gl_account_id']); ?>">
                                                                        <?php echo htmlspecialchars($item['item_description'] . ' (' . $item['unit_of_measure'] . ') - ' . $item['account_no']); ?>
                                                                    </option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="form-group mb-3">
                                                            <label class="form-label required-field">Quantity</label>
                                                            <input type="number" name="quantity[]" class="form-control" min="1" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group mb-3">
                                                            <label class="form-label required-field">Estimated Cost</label>
                                                            <input type="number" name="estimated_cost[]" class="form-control" step="0.01" min="0" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="form-group mb-3">
                                                            <label class="form-label">GL Account</label>
                                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($items[0]['account_no'] ?? ''); ?>" readonly>
                                                            <input type="hidden" name="gl_account_id[]" value="<?php echo htmlspecialchars($items[0]['gl_account_id'] ?? 0); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row mt-4">
                                            <div class="col-md-12 text-end">
                                                <div class="total-display d-inline-block px-4 py-2">
                                                    Total: $<span id="totalAmount">0.00</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mt-4">
                                    <div class="col-md-12 text-end">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fas fa-paper-plane me-1"></i> Submit Requisition
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script>
        function updateGLAccount(selectElement) {
            var selectedOption = selectElement.options[selectElement.selectedIndex];
            var glAccountId = selectedOption.getAttribute('data-gl-account-id');
            var parentDiv = selectElement.closest('.item-row');
            var hiddenInput = parentDiv.querySelector('input[name="gl_account_id[]"]');
            var displayInput = parentDiv.querySelector('input[type="text"][readonly]');
            
            if (hiddenInput && displayInput) {
                hiddenInput.value = glAccountId;
                // Extract account number from option text (last part after dash)
                var optionText = selectedOption.text;
                var accountNo = optionText.split(' - ').pop();
                displayInput.value = accountNo;
            }
            
            // Update total amount
            updateTotalAmount();
        }
        
        function addItemRow() {
            var container = document.getElementById("items-container");
            var newItemRow = document.createElement("div");
            newItemRow.className = "item-row";
            
            var itemOptions = '';
            var firstGlAccountId = '';
            var firstAccountNo = '';
            
            <?php foreach ($items as $index => $item) { ?>
                itemOptions += `<option value="<?php echo htmlspecialchars($item['id']); ?>" data-gl-account-id="<?php echo htmlspecialchars($item['gl_account_id']); ?>">
                                    <?php echo htmlspecialchars($item['item_description'] . ' (' . $item['unit_of_measure'] . ') - ' . $item['account_no']); ?>
                                </option>`;
                <?php if ($index === 0) { ?>
                    firstGlAccountId = `<?php echo htmlspecialchars($item['gl_account_id']); ?>`;
                    firstAccountNo = `<?php echo htmlspecialchars($item['account_no']); ?>`;
                <?php } ?>
            <?php } ?>

            newItemRow.innerHTML = `
                <div class="row">
                    <div class="col-md-5">
                        <div class="form-group mb-3">
                            <label class="form-label required-field">Select Item</label>
                            <select name="item_id[]" class="form-select" required onchange="updateGLAccount(this)">${itemOptions}</select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group mb-3">
                            <label class="form-label required-field">Quantity</label>
                            <input type="number" name="quantity[]" class="form-control" min="1" required onchange="updateTotalAmount()">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group mb-3">
                            <label class="form-label required-field">Estimated Cost</label>
                            <input type="number" name="estimated_cost[]" class="form-control" step="0.01" min="0" required onchange="updateTotalAmount()">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group mb-3">
                            <label class="form-label">GL Account</label>
                            <input type="text" class="form-control" value="${firstAccountNo}" readonly>
                            <input type="hidden" name="gl_account_id[]" value="${firstGlAccountId}">
                        </div>
                    </div>
                </div>
            `;
            container.appendChild(newItemRow);
            
            // Initialize the new row
            var newSelect = newItemRow.querySelector('select[name="item_id[]"]');
            if (newSelect) {
                updateGLAccount(newSelect);
            }
        }

        function updateTotalAmount() {
            var total = 0;
            var costInputs = document.querySelectorAll('input[name="estimated_cost[]"]');
            var quantityInputs = document.querySelectorAll('input[name="quantity[]"]');
            
            for (var i = 0; i < costInputs.length; i++) {
                var cost = parseFloat(costInputs[i].value) || 0;
                var quantity = parseFloat(quantityInputs[i].value) || 0;
                total += cost * quantity;
            }
            
            document.getElementById('totalAmount').textContent = total.toFixed(2);
        }

        document.addEventListener('DOMContentLoaded', function() {
            var firstSelect = document.querySelector('select[name="item_id[]"]');
            if (firstSelect) {
                updateGLAccount(firstSelect);
            }
            
            // Add event listeners for quantity and cost inputs
            document.querySelectorAll('input[name="quantity[]"], input[name="estimated_cost[]"]').forEach(function(input) {
                input.addEventListener('input', updateTotalAmount);
            });
            
            // Form validation
            document.getElementById('requisitionForm').addEventListener('submit', function(e) {
                let valid = true;
                const requiredFields = this.querySelectorAll('[required]');
                
                requiredFields.forEach(field => {
                    if (!field.value) {
                        valid = false;
                        field.classList.add('is-invalid');
                    } else {
                        field.classList.remove('is-invalid');
                    }
                });
                
                if (!valid) {
                    e.preventDefault();
                    alert('Please fill in all required fields.');
                }
            });
        });
    </script>
</body>
</html>