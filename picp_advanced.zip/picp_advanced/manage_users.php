<?php
session_start();
require_once 'users.php';

// Check if the user is logged in
if (!isset($_SESSION["user_id"]) || !isset($_SESSION["username"])) {
    header("location: index.php");
    exit;
}

// Check if the user is an admin (e.g., role_id = 1)
if ($_SESSION['role_id'] != 1) {
    echo "You do not have permission to view this page.";
    exit;
}

$message = '';
$conn = connectDB();

// Handle user activation/deactivation
if (isset($_GET['activate_id'])) {
    $user_id = $_GET['activate_id'];
    $sql = "UPDATE users SET status = 'active' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $message = "User activated successfully!";
    } else {
        $message = "Error activating user: " . $stmt->error;
    }
    $stmt->close();
} elseif (isset($_GET['deactivate_id'])) {
    $user_id = $_GET['deactivate_id'];
    // Prevent deactivating the currently logged-in admin
    if ($user_id != $_SESSION['user_id']) {
        $sql = "UPDATE users SET status = 'inactive' WHERE id = ?";
        $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $message = "User deactivated successfully!";
        } else {
            $message = "Error deactivating user: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "Error: You cannot deactivate your own account.";
    }
}

// Handle form submissions for adding a new user
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_user'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $department_id = $_POST['department_id'];
    $role_id = $_POST['role_id'];
    $location_id = $_POST['location_id'];
    $phone_number = $_POST['phone_number'];
    $job_title = $_POST['job_title'];

    if (registerUser($name, $email, $password, $department_id, $role_id, $location_id, $phone_number, $job_title)) {
        $message = "User successfully added!";
    } else {
        $message = "Failed to add user. Please check the provided information.";
    }
}

// Fetch departments, roles, and locations to populate dropdowns
$departments = $conn->query("SELECT id, name FROM departments ORDER BY name ASC");
$roles = $conn->query("SELECT id, name FROM roles ORDER BY name ASC");
$locations = $conn->query("SELECT id, name FROM locations ORDER BY name ASC");

// Fetch all users with their associated department, role, and location names
$users_sql = "SELECT u.id, u.name, u.email, u.status, d.name AS department_name, r.name AS role_name, l.name AS location_name
              FROM users u
              JOIN departments d ON u.department_id = d.id
              JOIN roles r ON u.role_id = r.id
              JOIN locations l ON u.location_id = l.id
              ORDER BY u.name ASC";
$users = $conn->query($users_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-active {
            background-color: #28a745;
            color: white;
        }
        
        .status-inactive {
            background-color: #6c757d;
            color: white;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .action-buttons .btn {
            margin-right: 5px;
            border-radius: 5px;
        }
        
        .user-info {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .form-container {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_invoices.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Manage Invoices</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_payments.php">
                    <i class="fas fa-money-check"></i>
                    <span>Manage Payments</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link active" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_spend_categories.php">
                    <i class="fas fa-tags"></i>
                    <span>Spend Categories</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_suppliers.php">
                    <i class="fas fa-truck"></i>
                    <span>Manage Suppliers</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Users</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Users Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-<?= strpos($message, 'successfully') !== false ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Statistics -->
            <?php
            $total_users = $users->num_rows;
            $active_count = 0;
            $inactive_count = 0;
            
            if ($users->num_rows > 0) {
                $users->data_seek(0);
                while($user = $users->fetch_assoc()) {
                    if ($user['status'] == 'active') $active_count++;
                    else $inactive_count++;
                }
                $users->data_seek(0);
            }
            ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary"><?php echo $total_users; ?></div>
                        <div class="stats-label">Total Users</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success"><?php echo $active_count; ?></div>
                        <div class="stats-label">Active Users</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-secondary"><?php echo $inactive_count; ?></div>
                        <div class="stats-label">Inactive Users</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <a href="#addUserForm" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i> Add New User
                        </a>
                    </div>
                </div>
            </div>

            <!-- Add New User Form -->
            <div class="dashboard-card" id="addUserForm">
                <div class="card-header">
                    <span><i class="fas fa-user-plus me-2"></i>Add New User</span>
                </div>
                <div class="card-body">
                    <form action="manage_users.php" method="post">
                        <input type="hidden" name="add_user" value="1">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">Full Name *</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email Address *</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="password" class="form-label">Password *</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="phone_number" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" id="phone_number" name="phone_number">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="job_title" class="form-label">Job Title</label>
                                <input type="text" class="form-control" id="job_title" name="job_title">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="department_id" class="form-label">Department *</label>
                                <select class="form-select" id="department_id" name="department_id" required>
                                    <?php while($dept = $departments->fetch_assoc()) { ?>
                                        <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['name']) ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="role_id" class="form-label">Role *</label>
                                <select class="form-select" id="role_id" name="role_id" required>
                                    <?php while($role = $roles->fetch_assoc()) { ?>
                                        <option value="<?= $role['id'] ?>"><?= htmlspecialchars($role['name']) ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="location_id" class="form-label">Location *</label>
                                <select class="form-select" id="location_id" name="location_id" required>
                                    <?php while($loc = $locations->fetch_assoc()) { ?>
                                        <option value="<?= $loc['id'] ?>"><?= htmlspecialchars($loc['name']) ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Add User
                        </button>
                    </form>
                </div>
            </div>

            <!-- Existing Users -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-users me-2"></i>Existing Users</span>
                    <span class="badge bg-light text-dark"><?php echo $total_users; ?> users</span>
                </div>
                <div class="card-body">
                    <?php if ($users->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Department</th>
                                    <th>Role</th>
                                    <th>Location</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($user = $users->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($user['name']); ?></strong>
                                    </td>
                                    <td>
                                        <a href="mailto:<?= htmlspecialchars($user['email']); ?>">
                                            <?= htmlspecialchars($user['email']); ?>
                                        </a>
                                    </td>
                                    <td><?= htmlspecialchars($user['department_name']); ?></td>
                                    <td><?= htmlspecialchars($user['role_name']); ?></td>
                                    <td><?= htmlspecialchars($user['location_name']); ?></td>
                                    <td>
                                        <span class="status-badge status-<?= $user['status']; ?>">
                                            <?= ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td class="action-buttons">
                                        <a href="edit_user.php?id=<?= $user['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <?php if ($user['status'] == 'active') { ?>
                                            <a href="manage_users.php?deactivate_id=<?= $user['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to deactivate this user?');">
                                                <i class="fas fa-user-slash"></i> Deactivate
                                            </a>
                                        <?php } else { ?>
                                            <a href="manage_users.php?activate_id=<?= $user['id']; ?>" class="btn btn-sm btn-outline-success" onclick="return confirm('Are you sure you want to activate this user?');">
                                                <i class="fas fa-user-check"></i> Activate
                                            </a>
                                        <?php } ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-users fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No Users Found</h4>
                        <p class="text-muted">No users have been added yet. Use the form above to add your first user.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>