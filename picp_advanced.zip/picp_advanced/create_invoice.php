<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and has the right role
if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: index.php");
    exit;
}

$message = '';
$po_details = null;
$po_items = [];
$gl_accounts = [];

$conn = connectDB();

// Fetch GL Accounts for dropdown
$sql_gl = "SELECT id, account_no, account_name FROM gl_accounts ORDER BY account_no ASC";
$gl_result = $conn->query($sql_gl);
if ($gl_result) {
    while ($row = $gl_result->fetch_assoc()) {
        $gl_accounts[] = $row;
    }
}

// Fetch PO details and items if PO ID is provided
if (isset($_GET['po_id'])) {
    $po_id = (int)$_GET['po_id'];
    
    // Fetch PO details
    $sql_po = "SELECT po.*, s.name as supplier_name 
               FROM purchase_orders po 
               JOIN suppliers s ON po.supplier_id = s.id 
               WHERE po.id = ?";
    $stmt_po = $conn->prepare($sql_po);
    $stmt_po->bind_param("i", $po_id);
    $stmt_po->execute();
    $po_result = $stmt_po->get_result();
    if ($po_result->num_rows > 0) {
        $po_details = $po_result->fetch_assoc();
    }
    $stmt_po->close();

    // Fetch PO items
    $sql_items = "SELECT id, item_description, quantity, unit_price FROM po_items WHERE purchase_order_id = ?";
    $stmt_items = $conn->prepare($sql_items);
    $stmt_items->bind_param("i", $po_id);
    $stmt_items->execute();
    $items_result = $stmt_items->get_result();
    if ($items_result->num_rows > 0) {
        while ($row = $items_result->fetch_assoc()) {
            $po_items[] = $row;
        }
    }
    $stmt_items->close();
}

// Handle form submission to create invoice
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'create') {
    $po_id = (int)$_POST['po_id'];
    $invoice_no = trim($_POST['invoice_no']);
    $invoice_date = $_POST['invoice_date'];
    $due_date = $_POST['due_date'];
    $supplier_id = (int)$_POST['supplier_id'];

    // Arrays for invoice items (validate first)
    $item_descriptions = $_POST['item_description'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    $unit_prices = $_POST['unit_price'] ?? [];
    $gl_account_ids = $_POST['gl_account_id'] ?? [];

    if (empty($item_descriptions) || empty($quantities) || empty($unit_prices) || empty($gl_account_ids)) {
        $message = '<div class="alert alert-danger" role="alert">Invoice items are missing.</div>';
    } else {
        $conn->begin_transaction();
        try {
            // Calculate total dynamically
            $total_amount = 0;
            foreach ($quantities as $key => $qty) {
                $total_amount += $qty * $unit_prices[$key];
            }

            // Insert invoice
            $sql_insert = "INSERT INTO invoices (invoice_no, purchase_order_id, supplier_id, invoice_date, due_date, amount, status) 
                           VALUES (?, ?, ?, ?, ?, ?, 'submitted')";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("siissd", $invoice_no, $po_id, $supplier_id, $invoice_date, $due_date, $total_amount);
            if (!$stmt_insert->execute()) {
                throw new Exception("Error creating invoice: " . $stmt_insert->error);
            }
            $invoice_id = $stmt_insert->insert_id;
            $stmt_insert->close();

            // Insert each invoice item
            $sql_items = "INSERT INTO invoice_items (invoice_id, item_description, quantity, unit_price, gl_account_id) 
                          VALUES (?, ?, ?, ?, ?)";
            $stmt_items = $conn->prepare($sql_items);
            foreach ($item_descriptions as $key => $desc) {
                $stmt_items->bind_param("isddi", $invoice_id, $desc, $quantities[$key], $unit_prices[$key], $gl_account_ids[$key]);
                if (!$stmt_items->execute()) {
                    throw new Exception("Error adding invoice item: " . $stmt_items->error);
                }
            }
            $stmt_items->close();

            // Update PO status
            $sql_update_po = "UPDATE purchase_orders SET status = 'invoiced' WHERE id = ?";
            $stmt_update_po = $conn->prepare($sql_update_po);
            $stmt_update_po->bind_param("i", $po_id);
            $stmt_update_po->execute();
            $stmt_update_po->close();

            $conn->commit();
            $message = '<div class="alert alert-success" role="alert">Invoice created successfully!</div>';
        } catch (Exception $e) {
            $conn->rollback();
            $message = '<div class="alert alert-danger" role="alert">Transaction failed: ' . $e->getMessage() . '</div>';
        }
    }
}
$conn->close();

// Get user role name for display
$user_role_id = $_SESSION['role_id'];
$role_name = getUserRoleName($user_role_id);
$_SESSION['role_name'] = $role_name;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Invoice | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .item-row {
            border-left: 4px solid var(--secondary-color);
            padding: 15px;
            margin-bottom: 15px;
            background-color: var(--light-bg);
            border-radius: 8px;
        }
        
        .total-display {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary-color);
            padding: 12px 20px;
            background-color: #eaecf4;
            border-radius: 8px;
        }
        
        .required-field::after {
            content: "*";
            color: var(--accent-color);
            margin-left: 4px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Create Invoice</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="dashboard-card mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h4 class="m-0"><i class="fas fa-file-invoice-dollar me-2"></i>Create New Invoice</h4>
                            <a href="dashboard.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                            </a>
                        </div>
                        <div class="card-body">
                            <?php echo $message; ?>
                            
                            <?php if ($po_details) { ?>
                            <div class="alert alert-info mb-4">
                                <h5 class="alert-heading"><i class="fas fa-info-circle me-2"></i>Creating Invoice for Purchase Order</h5>
                                <p class="mb-0">You are creating an invoice based on the selected purchase order. Please review all information before finalizing.</p>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="dashboard-card border-left-primary mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0"><i class="fas fa-file-purchase-order me-2"></i>Purchase Order Details</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <p><strong>PO Number:</strong><br> <?php echo htmlspecialchars($po_details['po_no']); ?></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <p><strong>Supplier:</strong><br> <?php echo htmlspecialchars($po_details['supplier_name']); ?></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <p><strong>Total Amount:</strong><br> $<?php 
                                                        $calculated_total = 0;
                                                        foreach ($po_items as $item) {
                                                            $calculated_total += $item['quantity'] * $item['unit_price'];
                                                        }
                                                        echo number_format($calculated_total, 2); 
                                                    ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <form action="create_invoice.php" method="post" id="invoiceForm">
                                <input type="hidden" name="action" value="create">
                                <input type="hidden" name="po_id" value="<?php echo htmlspecialchars($po_details['id']); ?>">
                                <input type="hidden" name="supplier_id" value="<?php echo htmlspecialchars($po_details['supplier_id']); ?>">

                                <div class="row mb-4">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="invoice_no" class="form-label required-field">Invoice Number</label>
                                            <input type="text" id="invoice_no" name="invoice_no" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="invoice_date" class="form-label required-field">Invoice Date</label>
                                            <input type="date" id="invoice_date" name="invoice_date" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="due_date" class="form-label required-field">Due Date</label>
                                            <input type="date" id="due_date" name="due_date" class="form-control" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="dashboard-card mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0"><i class="fas fa-list-alt me-2"></i>Invoice Items</h6>
                                    </div>
                                    <div class="card-body">
                                        <?php 
                                        $item_total = 0;
                                        foreach ($po_items as $key => $item) { 
                                            $item_total += $item['quantity'] * $item['unit_price'];
                                        ?>
                                            <div class="item-row mb-3">
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <p><strong>Item Description:</strong><br> <?php echo htmlspecialchars($item['item_description']); ?></p>
                                                        <input type="hidden" name="item_description[]" value="<?php echo htmlspecialchars($item['item_description']); ?>">
                                                    </div>
                                                    <div class="col-md-2">
                                                        <p><strong>Quantity:</strong><br> <?php echo htmlspecialchars($item['quantity']); ?></p>
                                                        <input type="hidden" name="quantity[]" value="<?php echo htmlspecialchars($item['quantity']); ?>">
                                                    </div>
                                                    <div class="col-md-2">
                                                        <p><strong>Unit Price:</strong><br> $<?php echo number_format($item['unit_price'], 2); ?></p>
                                                        <input type="hidden" name="unit_price[]" value="<?php echo htmlspecialchars($item['unit_price']); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="gl_account_id_<?php echo $key; ?>" class="form-label required-field">GL Account</label>
                                                            <select name="gl_account_id[]" id="gl_account_id_<?php echo $key; ?>" class="form-select" required>
                                                                <option value="">Select Account</option>
                                                                <?php foreach ($gl_accounts as $account) { ?>
                                                                    <option value="<?php echo htmlspecialchars($account['id']); ?>">
                                                                        <?php echo htmlspecialchars($account['account_no'] . ' - ' . $account['account_name']); ?>
                                                                    </option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                        
                                        <div class="row mt-4">
                                            <div class="col-md-12 text-end">
                                                <div class="total-display d-inline-block px-4 py-2">
                                                    Total: $<?php echo number_format($item_total, 2); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mt-4">
                                    <div class="col-md-12 text-end">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fas fa-check-circle me-1"></i> Finalize Invoice
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <?php } else { ?>
                                <div class="alert alert-warning" role="alert">
                                    <h4 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>No Purchase Order Selected</h4>
                                    <p>No valid Purchase Order found for invoice creation. Please select a PO from the View Purchase Orders page.</p>
                                    <hr>
                                    <a href="dashboard.php" class="btn btn-primary">Go to Dashboard</a>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script>
        // Set default dates
        document.addEventListener('DOMContentLoaded', function() {
            // Set invoice date to today
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, '0');
            const dd = String(today.getDate()).padStart(2, '0');
            const todayStr = `${yyyy}-${mm}-${dd}`;
            
            document.getElementById('invoice_date').value = todayStr;
            
            // Set due date to 30 days from now
            const dueDate = new Date();
            dueDate.setDate(today.getDate() + 30);
            const dueYYYY = dueDate.getFullYear();
            const dueMM = String(dueDate.getMonth() + 1).padStart(2, '0');
            const dueDD = String(dueDate.getDate()).padStart(2, '0');
            const dueStr = `${dueYYYY}-${dueMM}-${dueDD}`;
            
            document.getElementById('due_date').value = dueStr;
            
            // Form validation
            document.getElementById('invoiceForm').addEventListener('submit', function(e) {
                let valid = true;
                const glAccountSelects = document.querySelectorAll('select[name="gl_account_id[]"]');
                
                glAccountSelects.forEach(select => {
                    if (!select.value) {
                        valid = false;
                        select.classList.add('is-invalid');
                    } else {
                        select.classList.remove('is-invalid');
                    }
                });
                
                if (!valid) {
                    e.preventDefault();
                    alert('Please select a GL Account for all items.');
                }
            });
        });
    </script>
</body>
</html>