<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"]) || !isset($_GET['id']) || !isset($_GET['type'])) {
    header("location: inbox.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message_id = $_GET['id'];
$message_type = $_GET['type'];
$message = null;
$attachment = null;

$conn = connectDB();

try {
    if ($message_type == 'user') {
        // Fetch message from internal inbox
        $sql = "SELECT i.*, u.name AS sender_name
                FROM inbox i
                JOIN users u ON i.sender_id = u.id
                WHERE i.id = ? AND i.recipient_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Error preparing user view statement: " . $conn->error);
        $stmt->bind_param("ii", $message_id, $user_id);
    } elseif ($message_type == 'supplier') {
        // Fetch message from supplier inbox
        $sql = "SELECT si.*, s.name AS sender_name
                FROM supplier_inbox si
                JOIN suppliers s ON si.sender_supplier_id = s.id
                WHERE si.id = ? AND si.recipient_user_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Error preparing supplier view statement: " . $conn->error);
        $stmt->bind_param("ii", $message_id, $user_id);
    } else {
        throw new Exception("Invalid message type.");
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $message = $result->fetch_assoc();
        
        // Fetch attachment if available
        $sql_attach = "SELECT file_name, file_path FROM message_attachments WHERE message_id = ?";
        $stmt_attach = $conn->prepare($sql_attach);
        if (!$stmt_attach) throw new Exception("Error preparing attachment statement: " . $conn->error);
        $stmt_attach->bind_param("i", $message_id);
        $stmt_attach->execute();
        $result_attach = $stmt_attach->get_result();
        if ($result_attach && $result_attach->num_rows > 0) {
            $attachment = $result_attach->fetch_assoc();
        }
        $stmt_attach->close();
    }
    $stmt->close();
    
    // Mark message as read
    if ($message_type == 'user') {
        $sql_update = "UPDATE inbox SET status = 'read' WHERE id = ? AND recipient_id = ?";
    } elseif ($message_type == 'supplier') {
        $sql_update = "UPDATE supplier_inbox SET status = 'read' WHERE id = ? AND recipient_user_id = ?";
    }
    $stmt_update = $conn->prepare($sql_update);
    if (!$stmt_update) throw new Exception("Error preparing update statement: " . $conn->error);
    $stmt_update->bind_param("ii", $message_id, $user_id);
    $stmt_update->execute();
    $stmt_update->close();
    
} catch (Exception $e) {
    echo "Error viewing message: " . $e->getMessage();
    exit;
} finally {
    $conn->close();
}

if (!$message) {
    echo "Message not found or you don't have permission to view it.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Message | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .message-header {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .message-body {
            line-height: 1.6;
            font-size: 1.05rem;
        }
        
        .attachment-card {
            border-left: 4px solid var(--secondary-color);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">View Message</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Dashboard Content -->
        <div class="container-fluid">
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-envelope me-2"></i>Message Details
                </div>
                <div class="card-body">
                    <!-- Message Header -->
                    <div class="message-header mb-4">
                        <h3 class="mb-3"><?php echo htmlspecialchars($message['subject']); ?></h3>
                        <div class="row">
                            <div class="col-md-6">
                                <p class="mb-1"><strong>From:</strong> <?php echo htmlspecialchars($message['sender_name']); ?></p>
                                <p class="mb-1"><strong>Date:</strong> <?php echo date('F j, Y, g:i a', strtotime($message['sent_at'])); ?></p>
                            </div>
                            <div class="col-md-6 text-md-end">
                                <div class="btn-group mt-2 mt-md-0">
                                    <a href="inbox.php" class="btn btn-outline-primary">
                                        <i class="fas fa-arrow-left me-1"></i>Back to Inbox
                                    </a>
                                    <a href="compose_message.php?reply_to=<?php echo htmlspecialchars($message['id']); ?>&type=<?php echo htmlspecialchars($message_type); ?>" class="btn btn-primary">
                                        <i class="fas fa-reply me-1"></i>Reply
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Message Body -->
                    <div class="message-body mb-4">
                        <?php echo nl2br(htmlspecialchars($message['message_body'])); ?>
                    </div>

                    <!-- Attachment -->
                    <?php if ($attachment) { ?>
                    <div class="dashboard-card attachment-card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-paperclip me-2"></i>Attachment</h5>
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <p class="mb-0"><?php echo htmlspecialchars($attachment['file_name']); ?></p>
                                </div>
                                <div class="flex-shrink-0">
                                    <a href="<?php echo htmlspecialchars($attachment['file_path']); ?>" class="btn btn-success" download>
                                        <i class="fas fa-download me-1"></i>Download
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>