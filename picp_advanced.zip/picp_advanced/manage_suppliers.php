<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and has the right role (Admin)
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    header("location: index.php");
    exit;
}

$message = '';
$conn = connectDB();

// Handle form submission to add a new supplier
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'add') {
    $name = $_POST['name'];
    $contact_person = $_POST['contact_person'];
    $contact_email = $_POST['contact_email'];
    $contact_phone = $_POST['contact_phone'];
    $address = $_POST['address'];
    $tin = $_POST['tin'];

    $sql = "INSERT INTO suppliers (name, contact_person, contact_email, contact_phone, address, tin, status) VALUES (?, ?, ?, ?, ?, ?, 'active')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $name, $contact_person, $contact_email, $contact_phone, $address, $tin);

    if ($stmt->execute()) {
        $message = "Supplier added successfully!";
    } else {
        $message = "Error adding supplier: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch all suppliers to display them in a list
$sql_suppliers = "SELECT * FROM suppliers ORDER BY name ASC";
$suppliers_result = $conn->query($sql_suppliers);

$suppliers = [];
while ($row = $suppliers_result->fetch_assoc()) {
    $suppliers[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Suppliers | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-active {
            background-color: #28a745;
            color: white;
        }
        
        .status-inactive {
            background-color: #6c757d;
            color: white;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .action-buttons .btn {
            margin-right: 5px;
            border-radius: 5px;
        }
        
        .supplier-info {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .form-container {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_invoices.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Manage Invoices</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_payments.php">
                    <i class="fas fa-money-check"></i>
                    <span>Manage Payments</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_spend_categories.php">
                    <i class="fas fa-tags"></i>
                    <span>Spend Categories</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="manage_suppliers.php">
                    <i class="fas fa-truck"></i>
                    <span>Manage Suppliers</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Suppliers</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Suppliers Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Statistics -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary"><?php echo count($suppliers); ?></div>
                        <div class="stats-label">Total Suppliers</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success">
                            <?php 
                                $active_count = 0;
                                foreach ($suppliers as $supplier) {
                                    if ($supplier['status'] == 'active') $active_count++;
                                }
                                echo $active_count;
                            ?>
                        </div>
                        <div class="stats-label">Active Suppliers</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-secondary">
                            <?php echo count($suppliers) - $active_count; ?>
                        </div>
                        <div class="stats-label">Inactive Suppliers</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <a href="#addSupplierForm" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i> Add New Supplier
                        </a>
                    </div>
                </div>
            </div>

            <!-- Add New Supplier Form -->
            <div class="dashboard-card" id="addSupplierForm">
                <div class="card-header">
                    <span><i class="fas fa-plus-circle me-2"></i>Add New Supplier</span>
                </div>
                <div class="card-body">
                    <form action="manage_suppliers.php" method="post">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">Supplier Name *</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="contact_person" class="form-label">Contact Person</label>
                                <input type="text" class="form-control" id="contact_person" name="contact_person">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="contact_email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="contact_email" name="contact_email">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="contact_phone" class="form-label">Phone</label>
                                <input type="tel" class="form-control" id="contact_phone" name="contact_phone">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="address" class="form-label">Address</label>
                                <textarea class="form-control" id="address" name="address" rows="3"></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="tin" class="form-label">TIN (Tax Identification Number)</label>
                                <input type="text" class="form-control" id="tin" name="tin">
                                <div class="form-text">Required for official procurement processes</div>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Add Supplier
                        </button>
                    </form>
                </div>
            </div>

            <!-- Existing Suppliers -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-truck me-2"></i>Existing Suppliers</span>
                    <span class="badge bg-light text-dark"><?php echo count($suppliers); ?> suppliers</span>
                </div>
                <div class="card-body">
                    <?php if (count($suppliers) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Contact Person</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($suppliers as $supplier): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($supplier['name']); ?></strong>
                                        <?php if (!empty($supplier['tin'])): ?>
                                            <div class="supplier-info">TIN: <?php echo htmlspecialchars($supplier['tin']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($supplier['contact_person']); ?></td>
                                    <td>
                                        <?php if (!empty($supplier['contact_email'])): ?>
                                            <a href="mailto:<?php echo htmlspecialchars($supplier['contact_email']); ?>">
                                                <?php echo htmlspecialchars($supplier['contact_email']); ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">Not provided</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($supplier['contact_phone'])): ?>
                                            <a href="tel:<?php echo htmlspecialchars($supplier['contact_phone']); ?>">
                                                <?php echo htmlspecialchars($supplier['contact_phone']); ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">Not provided</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo $supplier['status']; ?>">
                                            <?php echo ucfirst($supplier['status']); ?>
                                        </span>
                                    </td>
                                    <td class="action-buttons">
                                        <a href="edit_supplier.php?id=<?php echo htmlspecialchars($supplier['id']); ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-truck fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No Suppliers Found</h4>
                        <p class="text-muted">No suppliers have been added yet. Use the form above to add your first supplier.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>