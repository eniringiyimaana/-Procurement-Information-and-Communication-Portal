<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: index.php");
    exit;
}

$message = '';
$conn = connectDB();

// Handle form submission to record a payment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'record_payment') {
    $invoice_id = $_POST['invoice_id'];
    $payment_date = $_POST['payment_date'];
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment_method'];
    $reference_no = $_POST['reference_no'];
    
    $conn->begin_transaction();
    try {
        // Step 1: Insert into payments table
        $sql_insert = "INSERT INTO payments (invoice_id, payment_date, amount, payment_method, reference_no) VALUES (?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("isdss", $invoice_id, $payment_date, $amount, $payment_method, $reference_no);
        if (!$stmt_insert->execute()) {
            throw new Exception("Error recording payment: " . $stmt_insert->error);
        }
        $stmt_insert->close();

        // Step 2: Update the invoice status to 'paid'
        $sql_update_invoice = "UPDATE invoices SET status = 'paid' WHERE id = ?";
        $stmt_update_invoice = $conn->prepare($sql_update_invoice);
        $stmt_update_invoice->bind_param("i", $invoice_id);
        if (!$stmt_update_invoice->execute()) {
            throw new Exception("Error updating invoice status: " . $stmt_update_invoice->error);
        }
        $stmt_update_invoice->close();
        
        $conn->commit();
        $message = "Payment for Invoice has been successfully recorded!";
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Transaction failed: " . $e->getMessage();
    }
}

// Fetch all invoices with a 'submitted' status
$sql = "SELECT i.*, po.po_no, s.name as supplier_name
        FROM invoices i
        JOIN purchase_orders po ON i.purchase_order_id = po.id
        JOIN suppliers s ON i.supplier_id = s.id
        WHERE i.status = 'submitted'
        ORDER BY i.invoice_date DESC";
$result = $conn->query($sql);

$invoices = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $invoices[] = $row;
    }
}
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Payments | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-submitted {
            background-color: #17a2b8;
            color: white;
        }
        
        .status-paid {
            background-color: #28a745;
            color: white;
        }
        
        .status-overdue {
            background-color: #dc3545;
            color: white;
        }
        
        .invoice-amount {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .payment-form {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 10px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_invoices.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Manage Invoices</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="manage_payments.php">
                    <i class="fas fa-money-check"></i>
                    <span>Manage Payments</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Payments</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Payments Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Payment Statistics -->
            <?php
            $total_invoices = count($invoices);
            $total_amount = 0;
            $overdue_count = 0;
            
            foreach ($invoices as $invoice) {
                $total_amount += $invoice['amount'];
                $due_date = new DateTime($invoice['due_date']);
                $today = new DateTime();
                if ($due_date < $today) {
                    $overdue_count++;
                }
            }
            ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary"><?php echo $total_invoices; ?></div>
                        <div class="stats-label">Pending Invoices</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success">$<?php echo number_format($total_amount, 2); ?></div>
                        <div class="stats-label">Total Amount Due</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-danger"><?php echo $overdue_count; ?></div>
                        <div class="stats-label">Overdue Invoices</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-info">
                            <i class="fas fa-money-check"></i>
                        </div>
                        <div class="stats-label">Payment Management</div>
                    </div>
                </div>
            </div>

            <!-- Invoices Ready for Payment -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-file-invoice-dollar me-2"></i>Invoices Ready for Payment</span>
                    <span class="badge bg-light text-dark"><?php echo $total_invoices; ?> invoices</span>
                </div>
                <div class="card-body">
                    <?php if (count($invoices) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Invoice No</th>
                                    <th>PO No</th>
                                    <th>Supplier</th>
                                    <th>Date</th>
                                    <th>Due Date</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($invoices as $invoice): 
                                    $due_date = new DateTime($invoice['due_date']);
                                    $today = new DateTime();
                                    $status_class = 'status-submitted';
                                    $status_text = 'Submitted';
                                    
                                    if ($due_date < $today) {
                                        $status_class = 'status-overdue';
                                        $status_text = 'Overdue';
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($invoice['invoice_no']); ?></strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($invoice['po_no']); ?></td>
                                    <td><?php echo htmlspecialchars($invoice['supplier_name']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($invoice['invoice_date'])); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($invoice['due_date'])); ?></td>
                                    <td class="invoice-amount">$<?php echo number_format($invoice['amount'], 2); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $status_class; ?>">
                                            <?php echo $status_text; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#paymentForm<?php echo $invoice['id']; ?>" aria-expanded="false" aria-controls="paymentForm<?php echo $invoice['id']; ?>">
                                            <i class="fas fa-money-bill-wave me-1"></i> Record Payment
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="8" class="p-0">
                                        <div class="collapse" id="paymentForm<?php echo $invoice['id']; ?>">
                                            <div class="payment-form">
                                                <form action="manage_payments.php" method="post">
                                                    <input type="hidden" name="action" value="record_payment">
                                                    <input type="hidden" name="invoice_id" value="<?php echo htmlspecialchars($invoice['id']); ?>">
                                                    <input type="hidden" name="amount" value="<?php echo htmlspecialchars($invoice['amount']); ?>">
                                                    
                                                    <div class="row">
                                                        <div class="col-md-3 mb-3">
                                                            <label for="payment_date" class="form-label">Payment Date</label>
                                                            <input type="date" class="form-control" name="payment_date" value="<?php echo date('Y-m-d'); ?>" required>
                                                        </div>
                                                        <div class="col-md-3 mb-3">
                                                            <label for="payment_method" class="form-label">Payment Method</label>
                                                            <select class="form-select" name="payment_method" required>
                                                                <option value="Bank Transfer">Bank Transfer</option>
                                                                <option value="Check">Check</option>
                                                                <option value="Credit Card">Credit Card</option>
                                                                <option value="Cash">Cash</option>
                                                                <option value="Other">Other</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 mb-3">
                                                            <label for="reference_no" class="form-label">Reference Number</label>
                                                            <input type="text" class="form-control" name="reference_no" placeholder="Check/Ref #">
                                                        </div>
                                                        <div class="col-md-3 mb-3 d-flex align-items-end">
                                                            <button type="submit" class="btn btn-success w-100" onclick="return confirm('Are you sure you want to record this payment?');">
                                                                <i class="fas fa-check-circle me-1"></i> Confirm Payment
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-check-circle fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No Pending Payments</h4>
                        <p class="text-muted">All invoices have been processed. Check back later for new invoices.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>