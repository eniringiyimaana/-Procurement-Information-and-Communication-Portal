<?php
session_start();
require_once 'users.php'; // For database connection

// Check if the user is logged in and is a Procurement Officer
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 2) {
    header("location: index.php");
    exit;
}

$user_role_id = $_SESSION['role_id'];
$role_name = getUserRoleName($user_role_id);
$_SESSION['role_name'] = $role_name;

$contracts = [];
$conn = connectDB();

// Fetch all contracts and join with RFQs and Suppliers to get details
$sql_contracts = "SELECT c.id, c.status, c.contract_file, r.rfq_no, s.name AS supplier_name, c.created_at
                  FROM contracts c
                  JOIN rfqs r ON c.rfq_id = r.id
                  JOIN supplier_proposals sp ON c.proposal_id = sp.id
                  JOIN suppliers s ON sp.supplier_id = s.id
                  ORDER BY c.created_at DESC";

$result_contracts = $conn->query($sql_contracts);

if ($result_contracts) {
    while ($row = $result_contracts->fetch_assoc()) {
        $contracts[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Contracts | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .status-badge {
            font-size: 0.75rem;
            padding: 0.35em 0.65em;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
        
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .stats-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_po.php">
                    <i class="fas fa-file-invoice"></i>
                    <span>Create Purchase Order</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_purchase_orders.php">
                    <i class="fas fa-tasks"></i>
                    <span>Manage Purchase Orders</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="view_contracts.php">
                    <i class="fas fa-file-contract"></i>
                    <span>View Contracts</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_invoices.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Manage Invoices</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Contract Management</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Contracts Content -->
        <div class="container-fluid">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 text-primary">Contract Management</h1>
                    <p class="text-muted mb-0">View and manage all contracts</p>
                </div>
            </div>
            
            <!-- Contracts Table -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-file-contract me-2"></i>All Contracts</span>
                    <span class="badge bg-light text-dark"><?php echo count($contracts); ?> Contracts</span>
                </div>
                <div class="card-body p-0">
                    <?php if (count($contracts) > 0) { ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Contract ID</th>
                                        <th>RFQ No.</th>
                                        <th>Supplier</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($contracts as $contract) { 
                                        $statusClass = '';
                                        switch ($contract['status']) {
                                            case 'signed':
                                                $statusClass = 'bg-success';
                                                break;
                                            case 'pending':
                                                $statusClass = 'bg-warning';
                                                break;
                                            case 'draft':
                                                $statusClass = 'bg-secondary';
                                                break;
                                            default:
                                                $statusClass = 'bg-info';
                                        }
                                    ?>
                                        <tr>
                                            <td class="fw-bold">#<?php echo htmlspecialchars($contract['id']); ?></td>
                                            <td><?php echo htmlspecialchars($contract['rfq_no']); ?></td>
                                            <td><?php echo htmlspecialchars($contract['supplier_name']); ?></td>
                                            <td>
                                                <span class="badge <?php echo $statusClass; ?> status-badge">
                                                    <?php echo ucfirst(htmlspecialchars($contract['status'])); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M j, Y', strtotime($contract['created_at'])); ?></td>
                                            <td>
                                                <?php if (!empty($contract['contract_file'])) { ?>
                                                    <a href="<?php echo htmlspecialchars($contract['contract_file']); ?>" 
                                                       target="_blank" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-eye me-1"></i>View Contract
                                                    </a>
                                                <?php } else { ?>
                                                    <span class="text-muted">No file uploaded</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    <?php } else { ?>
                        <div class="empty-state">
                            <i class="fas fa-file-contract"></i>
                            <h4>No Contracts Found</h4>
                            <p>There are no contracts in the system yet.</p>
                        </div>
                    <?php } ?>
                </div>
            </div>
            
            <!-- Statistics -->
            <div class="row mt-4">
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number"><?php echo count($contracts); ?></div>
                        <div class="stats-label">Total Contracts</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number">
                            <?php 
                                $signedCount = 0;
                                foreach ($contracts as $contract) {
                                    if ($contract['status'] === 'signed') {
                                        $signedCount++;
                                    }
                                }
                                echo $signedCount;
                            ?>
                        </div>
                        <div class="stats-label">Signed Contracts</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number">
                            <?php 
                                $pendingCount = 0;
                                foreach ($contracts as $contract) {
                                    if ($contract['status'] === 'pending') {
                                        $pendingCount++;
                                    }
                                }
                                echo $pendingCount;
                            ?>
                        </div>
                        <div class="stats-label">Pending Contracts</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number">
                            <?php 
                                $withFilesCount = 0;
                                foreach ($contracts as $contract) {
                                    if (!empty($contract['contract_file'])) {
                                        $withFilesCount++;
                                    }
                                }
                                echo $withFilesCount;
                            ?>
                        </div>
                        <div class="stats-label">Contracts with Files</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>