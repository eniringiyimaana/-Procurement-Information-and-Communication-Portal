<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: index.php");
    exit;
}

$message = '';
$invoice_details = null;
$invoice_items = [];

$conn = connectDB();

// Handle payment form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'pay') {
    $invoice_id = $_POST['invoice_id'];
    $payment_amount = $_POST['payment_amount'];
    $payment_method = $_POST['payment_method'];
    $reference_no = $_POST['reference_no'];

    $conn->begin_transaction();
    try {
        // Update the invoice status to 'paid'
        $sql_update_invoice = "UPDATE invoices SET status = 'paid' WHERE id = ?";
        $stmt_update_invoice = $conn->prepare($sql_update_invoice);
        $stmt_update_invoice->bind_param("i", $invoice_id);
        if (!$stmt_update_invoice->execute()) {
            throw new Exception("Error updating invoice status: " . $stmt_update_invoice->error);
        }
        $stmt_update_invoice->close();

        // Insert a new payment record
        $sql_insert_payment = "INSERT INTO payments (invoice_id, amount, payment_method, reference_no) VALUES (?, ?, ?, ?)";
        $stmt_insert_payment = $conn->prepare($sql_insert_payment);
        $stmt_insert_payment->bind_param("idss", $invoice_id, $payment_amount, $payment_method, $reference_no);
        if (!$stmt_insert_payment->execute()) {
            throw new Exception("Error recording payment: " . $stmt_insert_payment->error);
        }
        $stmt_insert_payment->close();

        $conn->commit();
        $message = "Invoice #{$invoice_id} successfully marked as paid and payment recorded.";

    } catch (Exception $e) {
        $conn->rollback();
        $message = "Transaction failed: " . $e->getMessage();
    }
}

// Fetch invoice details and its items if an ID is provided in the URL
if (isset($_GET['invoice_id'])) {
    $invoice_id = $_GET['invoice_id'];

    // Fetch invoice details
    $sql_invoice = "SELECT i.*, po.po_no, s.name as supplier_name
                    FROM invoices i
                    JOIN purchase_orders po ON i.purchase_order_id = po.id
                    JOIN suppliers s ON i.supplier_id = s.id
                    WHERE i.id = ?";
    $stmt_invoice = $conn->prepare($sql_invoice);
    $stmt_invoice->bind_param("i", $invoice_id);
    $stmt_invoice->execute();
    $invoice_result = $stmt_invoice->get_result();
    if ($invoice_result->num_rows > 0) {
        $invoice_details = $invoice_result->fetch_assoc();
    }
    $stmt_invoice->close();

    // Fetch invoice items and their associated GL Accounts
    $sql_items = "SELECT ii.*, gl.account_no, gl.account_name
                  FROM invoice_items ii
                  JOIN gl_accounts gl ON ii.gl_account_id = gl.id
                  WHERE ii.invoice_id = ?";
    $stmt_items = $conn->prepare($sql_items);
    $stmt_items->bind_param("i", $invoice_id);
    $stmt_items->execute();
    $items_result = $stmt_items->get_result();
    if ($items_result->num_rows > 0) {
        while ($row = $items_result->fetch_assoc()) {
            $invoice_items[] = $row;
        }
    }
    $stmt_items->close();

}
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Invoice | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .invoice-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .status-badge {
            padding: 8px 15px;
            border-radius: 30px;
            font-weight: 600;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-paid {
            background-color: #d4edda;
            color: #155724;
        }
        
        .invoice-details {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .payment-form {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2) { ?>
            <li class="nav-item">
                <a class="nav-link active" href="manage_invoices.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Manage Invoices</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">View Invoice</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Dashboard Content -->
        <div class="container-fluid">
            <?php if ($message): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo $message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            
            <?php if ($invoice_details) { ?>
            <!-- Invoice Header -->
            <div class="invoice-header mb-4">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h2 class="mb-1">Invoice #<?php echo htmlspecialchars($invoice_details['invoice_no']); ?></h2>
                        <p class="mb-0">From: <?php echo htmlspecialchars($invoice_details['supplier_name']); ?></p>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <span class="status-badge status-<?php echo $invoice_details['status']; ?>">
                            <?php echo ucfirst(htmlspecialchars($invoice_details['status'])); ?>
                        </span>
                        <p class="mb-0 mt-2">PO: <?php echo htmlspecialchars($invoice_details['po_no']); ?></p>
                    </div>
                </div>
            </div>

            <!-- Invoice Details -->
            <div class="row">
                <div class="col-md-8">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-receipt me-2"></i>Invoice Items
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Item Description</th>
                                            <th>Quantity</th>
                                            <th>Unit Price</th>
                                            <th>GL Account</th>
                                            <th class="text-end">Line Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $subtotal = 0;
                                        foreach ($invoice_items as $item) { 
                                            $line_total = $item['quantity'] * $item['unit_price'];
                                            $subtotal += $line_total;
                                        ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['item_description']); ?></td>
                                                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                                <td>$<?php echo number_format($item['unit_price'], 2); ?></td>
                                                <td><?php echo htmlspecialchars($item['account_no'] . ' - ' . $item['account_name']); ?></td>
                                                <td class="text-end">$<?php echo number_format($line_total, 2); ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="4" class="text-end"><strong>Subtotal:</strong></td>
                                            <td class="text-end"><strong>$<?php echo number_format($subtotal, 2); ?></strong></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-info-circle me-2"></i>Invoice Details
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <strong>Invoice Date:</strong><br>
                                <?php echo htmlspecialchars($invoice_details['invoice_date']); ?>
                            </div>
                            <div class="mb-3">
                                <strong>Due Date:</strong><br>
                                <?php echo htmlspecialchars($invoice_details['due_date']); ?>
                            </div>
                            <div class="mb-3">
                                <strong>Total Amount:</strong><br>
                                <h4 class="text-primary">$<?php echo number_format($invoice_details['amount'], 2); ?></h4>
                            </div>
                            <div>
                                <strong>Status:</strong><br>
                                <span class="status-badge status-<?php echo $invoice_details['status']; ?>">
                                    <?php echo ucfirst(htmlspecialchars($invoice_details['status'])); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <?php if ($invoice_details['status'] != 'paid') { ?>
                    <div class="dashboard-card mt-4 payment-form">
                        <div class="card-header">
                            <i class="fas fa-credit-card me-2"></i>Record Payment
                        </div>
                        <div class="card-body">
                            <form action="view_invoice.php?invoice_id=<?php echo htmlspecialchars($invoice_details['id']); ?>" method="post">
                                <input type="hidden" name="action" value="pay">
                                <input type="hidden" name="invoice_id" value="<?php echo htmlspecialchars($invoice_details['id']); ?>">
                                <input type="hidden" name="payment_amount" value="<?php echo htmlspecialchars($invoice_details['amount']); ?>">

                                <div class="mb-3">
                                    <label for="payment_method" class="form-label">Payment Method</label>
                                    <select class="form-select" id="payment_method" name="payment_method" required>
                                        <option value="">Select Payment Method</option>
                                        <option value="Bank Transfer">Bank Transfer</option>
                                        <option value="Credit Card">Credit Card</option>
                                        <option value="Check">Check</option>
                                        <option value="Cash">Cash</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="reference_no" class="form-label">Reference Number</label>
                                    <input type="text" class="form-control" id="reference_no" name="reference_no" required>
                                </div>

                                <div class="d-grid">
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-check-circle me-2"></i>Mark as Paid
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php } else { ?>
                    <div class="alert alert-success mt-4" role="alert">
                        <i class="fas fa-check-circle me-2"></i>This invoice has already been paid.
                    </div>
                    <?php } ?>
                </div>
            </div>
            
            <?php } else { ?>
            <div class="alert alert-warning" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>No invoice found with the provided ID.
            </div>
            <?php } ?>

            <div class="mt-4">
                <a href="manage_invoices.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left me-2"></i>Back to Manage Invoices
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>