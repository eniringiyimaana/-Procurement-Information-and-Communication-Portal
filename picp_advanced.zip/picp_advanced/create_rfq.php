<?php
session_start();
require_once 'users.php';

// Establish a database connection
$conn = connectDB();

if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 2) {
    header("location: dashboard.php");
    exit;
}

// Get user role name for display
$user_role_id = $_SESSION['role_id'];
$role_name = getUserRoleName($user_role_id);
$_SESSION['role_name'] = $role_name;

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_rfq'])) {
    $requisition_id = $_POST['requisition_id'];
    $title = $_POST['title'];
    $due_date = $_POST['due_date'];
    $invited_suppliers = $_POST['invited_suppliers'] ?? [];
    $rfq_no = 'RFQ-' . date('Ymd-') . uniqid();
    $created_by = $_SESSION['user_id'];

    $conn->begin_transaction();

    try {
        // 1. Insert the new RFQ into the rfqs table
        $sql_rfq = "INSERT INTO rfqs (rfq_no, requisition_id, title, due_date, created_by, status) VALUES (?, ?, ?, ?, ?, 'published')";
        $stmt_rfq = $conn->prepare($sql_rfq);
        if (!$stmt_rfq) {
            throw new Exception("RFQ insert failed: " . $conn->error);
        }
        $stmt_rfq->bind_param("sisss", $rfq_no, $requisition_id, $title, $due_date, $created_by);
        $stmt_rfq->execute();
        $rfq_id = $conn->insert_id;
        $stmt_rfq->close();

        // 2. Copy items from requisition_items to rfq_items
        $sql_copy_items = "
            INSERT INTO rfq_items (rfq_id, requisition_item_id, quantity, estimated_cost, item_description, unit_of_measure)
            SELECT ?, ri.id, ri.quantity, ri.estimated_cost, i.item_description, i.unit_of_measure
            FROM requisition_items ri
            JOIN items i ON ri.item_id = i.id
            WHERE ri.requisition_id = ?
        ";
        $stmt_copy = $conn->prepare($sql_copy_items);
        if (!$stmt_copy) {
             throw new Exception("Item copy failed: " . $conn->error);
        }
        $stmt_copy->bind_param("ii", $rfq_id, $requisition_id);
        $stmt_copy->execute();
        $stmt_copy->close();

        // 3. Insert invitations for each supplier
        $sql_invite = "INSERT INTO rfq_invites (rfq_id, supplier_id, token, status) VALUES (?, ?, ?, 'pending')";
        $stmt_invite = $conn->prepare($sql_invite);
        if (!$stmt_invite) {
            throw new Exception("Invite insert failed: " . $conn->error);
        }
        foreach ($invited_suppliers as $supplier_id) {
            $token = bin2hex(random_bytes(32)); // Generate a unique token
            $stmt_invite->bind_param("iis", $rfq_id, $supplier_id, $token);
            $stmt_invite->execute();
        }
        $stmt_invite->close();

        // Commit the transaction
        $conn->commit();
        $message = '<div class="alert alert-success" role="alert">RFQ ' . htmlspecialchars($rfq_no) . ' created successfully!</div>';

    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        $message = '<div class="alert alert-danger" role="alert">Error creating RFQ: ' . $e->getMessage() . '</div>';
    }
}

// Fetch approved requisitions
$sql_requisitions = "SELECT id, requisition_no, title FROM requisitions WHERE status = 'approved'";
$requisitions_result = $conn->query($sql_requisitions);
$requisition_options = "";
if ($requisitions_result->num_rows > 0) {
    while ($row = $requisitions_result->fetch_assoc()) {
        $requisition_options .= "<option value='{$row['id']}'>" . htmlspecialchars($row['requisition_no']) . " - " . htmlspecialchars($row['title']) . "</option>";
    }
} else {
    $requisition_options = "<option value=''>No approved requisitions available</option>";
}

// Fetch all active suppliers
$suppliers_result = $conn->query("SELECT id, name FROM suppliers WHERE status = 'active' ORDER BY name ASC");
$suppliers_checkboxes = "";
while ($row = $suppliers_result->fetch_assoc()) {
    $suppliers_checkboxes .= "<div class='form-check mb-2'><input class='form-check-input' type='checkbox' id='supplier_{$row['id']}' name='invited_suppliers[]' value='{$row['id']}'>\r\n    <label class='form-check-label' for='supplier_{$row['id']}'>" . htmlspecialchars($row['name']) . "</label></div>";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New RFQ | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .required-field::after {
            content: "*";
            color: var(--accent-color);
            margin-left: 4px;
        }
        
        .supplier-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            max-height: 300px;
            overflow-y: auto;
            padding: 10px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .supplier-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 2) { ?>
            <li class="nav-item">
                <a class="nav-link active" href="create_rfq.php">
                    <i class="fas fa-file-contract"></i>
                    <span>Create RFQ</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Create New RFQ</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="dashboard-card mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h4 class="m-0"><i class="fas fa-file-contract me-2"></i>Create New RFQ</h4>
                            <a href="dashboard.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                            </a>
                        </div>
                        <div class="card-body">
                            <?php echo $message; ?>
                            
                            <div class="alert alert-info mb-4">
                                <h5 class="alert-heading"><i class="fas fa-info-circle me-2"></i>RFQ Creation</h5>
                                <p class="mb-0">Create a new Request for Quotation (RFQ) based on an approved requisition. Select suppliers to invite and set a due date for responses.</p>
                            </div>

                            <form method="post" action="create_rfq.php" id="rfqForm">
                                <div class="dashboard-card mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0"><i class="fas fa-file-alt me-2"></i>RFQ Details</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="requisition_id" class="form-label required-field">Select Requisition</label>
                                                    <select name="requisition_id" class="form-select" required>
                                                        <?php echo $requisition_options; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="due_date" class="form-label required-field">Due Date</label>
                                                    <input type="date" name="due_date" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group mb-3">
                                                    <label for="title" class="form-label required-field">RFQ Title</label>
                                                    <input type="text" name="title" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="dashboard-card mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0"><i class="fas fa-truck me-2"></i>Invite Suppliers</h6>
                                    </div>
                                    <div class="card-body">
                                        <p class="text-muted mb-3">Select suppliers to invite to this RFQ:</p>
                                        <div class="supplier-grid">
                                            <?php echo $suppliers_checkboxes; ?>
                                        </div>
                                        <div class="form-check mt-3">
                                            <input class="form-check-input" type="checkbox" id="selectAllSuppliers">
                                            <label class="form-check-label" for="selectAllSuppliers">
                                                Select All Suppliers
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mt-4">
                                    <div class="col-md-12 text-end">
                                        <button type="submit" name="create_rfq" class="btn btn-primary btn-lg">
                                            <i class="fas fa-paper-plane me-1"></i> Create RFQ
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set default due date to 14 days from now
            const dueDate = new Date();
            dueDate.setDate(dueDate.getDate() + 14);
            const dueYYYY = dueDate.getFullYear();
            const dueMM = String(dueDate.getMonth() + 1).padStart(2, '0');
            const dueDD = String(dueDate.getDate()).padStart(2, '0');
            const dueStr = `${dueYYYY}-${dueMM}-${dueDD}`;
            
            document.querySelector('input[name="due_date"]').value = dueStr;
            
            // Select all suppliers functionality
            document.getElementById('selectAllSuppliers').addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('input[name="invited_suppliers[]"]');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
            });
            
            // Form validation
            document.getElementById('rfqForm').addEventListener('submit', function(e) {
                let valid = true;
                const requiredFields = this.querySelectorAll('[required]');
                
                requiredFields.forEach(field => {
                    if (!field.value) {
                        valid = false;
                        field.classList.add('is-invalid');
                    } else {
                        field.classList.remove('is-invalid');
                    }
                });
                
                // Check if at least one supplier is selected
                const supplierCheckboxes = document.querySelectorAll('input[name="invited_suppliers[]"]:checked');
                if (supplierCheckboxes.length === 0) {
                    valid = false;
                    alert('Please select at least one supplier to invite.');
                }
                
                if (!valid) {
                    e.preventDefault();
                    alert('Please fill in all required fields.');
                }
            });
        });
    </script>
</body>
</html>