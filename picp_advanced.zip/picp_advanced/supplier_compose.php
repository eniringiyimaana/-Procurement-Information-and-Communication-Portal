<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["supplier_logged_in"]) || !$_SESSION["supplier_logged_in"]) {
    header("location: supplier_login.php");
    exit;
}

$supplier_id = $_SESSION['supplier_id'];
$message = '';
$conn = connectDB();
$rfq_no_prefill = $_GET['rfq_no'] ?? '';

// Base directory for uploads
$upload_base_dir = 'uploads/';
if (!is_dir($upload_base_dir)) {
    mkdir($upload_base_dir, 0777, true);
}

// Fetch all procurement officers to be recipients
$procurement_officers = [];
$sql_users = "SELECT id, name FROM users WHERE role_id = 2";
$result_users = $conn->query($sql_users);
if ($result_users) {
    while ($row = $result_users->fetch_assoc()) {
        $procurement_officers[] = $row;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['action_type'])) {
        $message = "Error: Submission type not specified.";
        $conn->close();
        exit;
    }

    $action_type = $_POST['action_type'];
    $conn->begin_transaction();

    try {
        if ($action_type === 'general_message') {
            $recipient_id = $_POST['recipient_id'] ?? null;
            $subject = $_POST['subject'] ?? '';
            $message_body = $_POST['message_body'] ?? '';

            if (!$recipient_id) {
                throw new Exception("Recipient is required for a general message.");
            }

            $sql = "INSERT INTO supplier_inbox (sender_supplier_id, recipient_user_id, subject, message_body) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Error preparing message statement: " . $conn->error);
            $stmt->bind_param("iiss", $supplier_id, $recipient_id, $subject, $message_body);
            if (!$stmt->execute()) throw new Exception("Failed to send message: " . $stmt->error);
            $message_id = $stmt->insert_id;
            $stmt->close();

            if (isset($_FILES['document']) && $_FILES['document']['error'] == 0) {
                $file_name = $_FILES['document']['name'];
                $file_tmp_name = $_FILES['document']['tmp_name'];
                $new_file_name = uniqid() . '_' . $file_name;
                $file_path = $upload_base_dir . 'message_attachments/' . $new_file_name;
                if (!is_dir(dirname($file_path))) mkdir(dirname($file_path), 0777, true);

                if (move_uploaded_file($file_tmp_name, $file_path)) {
                    $sql_attach = "INSERT INTO message_attachments (message_id, file_name, file_path) VALUES (?, ?, ?)";
                    $stmt_attach = $conn->prepare($sql_attach);
                    if (!$stmt_attach) throw new Exception("Error preparing attachment statement: " . $conn->error);
                    $stmt_attach->bind_param("iss", $message_id, $file_name, $file_path);
                    if (!$stmt_attach->execute()) throw new Exception("Failed to save attachment: " . $stmt_attach->error);
                    $stmt_attach->close();
                } else {
                    throw new Exception("Failed to move uploaded file.");
                }
            }
            $message = "Message sent successfully!";

        } elseif ($action_type === 'proposal') {
            if (empty($_POST['rfq_no']) || empty($_POST['amount']) || empty($_FILES['document']['name'])) {
                throw new Exception("RFQ number, amount, and document are required for proposal submission.");
            }
            $rfq_no = $_POST['rfq_no'];
            $amount = $_POST['amount'];
            $submission_date = date('Y-m-d H:i:s');

            // Find the RFQ ID from the RFQ number
            $sql_find_rfq_id = "SELECT id FROM rfqs WHERE rfq_no = ?";
            $stmt_find_rfq = $conn->prepare($sql_find_rfq_id);
            if (!$stmt_find_rfq) throw new Exception("Error preparing RFQ lookup statement: " . $conn->error);
            $stmt_find_rfq->bind_param("s", $rfq_no);
            $stmt_find_rfq->execute();
            $result_find_rfq = $stmt_find_rfq->get_result();
            if ($result_find_rfq->num_rows === 0) {
                throw new Exception("The RFQ number you entered does not exist.");
            }
            $rfq_id = $result_find_rfq->fetch_assoc()['id'];
            $stmt_find_rfq->close();

            $file_name = $_FILES['document']['name'];
            $file_tmp_name = $_FILES['document']['tmp_name'];
            $new_file_name = uniqid('prop_') . '_' . $file_name;
            $target_dir = $upload_base_dir . 'proposals/';
            if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

            $file_path = $target_dir . $new_file_name;
            if (!move_uploaded_file($file_tmp_name, $file_path)) {
                throw new Exception("Error uploading proposal file.");
            }

            // Corrected SQL query to use `proposal_file` and `amount`
            $sql = "INSERT INTO supplier_proposals (rfq_id, supplier_id, proposal_file, amount, submitted_at) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Error preparing statement: " . $conn->error);
            // Corrected bind_param string: i=int, i=int, s=string, d=decimal, s=string
            $stmt->bind_param("iisds", $rfq_id, $supplier_id, $file_path, $amount, $submission_date);
            if (!$stmt->execute()) throw new Exception("Failed to save proposal: " . $stmt->error);
            $stmt->close();

            $message = "Proposal for RFQ #$rfq_no submitted successfully!";

        } elseif ($action_type === 'contract') {
            if (empty($_POST['contract_id']) || empty($_FILES['document']['name'])) {
                throw new Exception("Contract ID and document are required for contract upload.");
            }
            $contract_id = $_POST['contract_id'];

            $file_name = $_FILES['document']['name'];
            $file_tmp_name = $_FILES['document']['tmp_name'];
            $new_file_name = uniqid('contract_') . '_' . $file_name;
            $target_dir = $upload_base_dir . 'contracts/';
            if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
            $file_path = $target_dir . $new_file_name;

            if (!move_uploaded_file($file_tmp_name, $file_path)) {
                throw new Exception("Error uploading contract file.");
            }

            $sql = "UPDATE contracts SET contract_file = ?, status = 'signed' WHERE id = ?";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Error preparing statement: " . $conn->error);
            $stmt->bind_param("si", $file_path, $contract_id);
            if (!$stmt->execute()) throw new Exception("Failed to upload contract: " . $stmt->error);
            $stmt->close();

            $message = "Contract #$contract_id signed and uploaded successfully!";

        } else {
            throw new Exception("Invalid submission type.");
        }

        $conn->commit();

    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error: " . $e->getMessage();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Submission Portal | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .form-section {
            display: none;
            padding: 20px;
            border-left: 4px solid var(--secondary-color);
            background-color: rgba(52, 152, 219, 0.05);
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .active-section {
            display: block;
        }
        
        .nav-tabs .nav-link {
            color: var(--primary-color);
            font-weight: 500;
            padding: 12px 20px;
            border: none;
            border-bottom: 3px solid transparent;
        }
        
        .nav-tabs .nav-link.active {
            color: var(--secondary-color);
            background: transparent;
            border-bottom: 3px solid var(--secondary-color);
        }
        
        .nav-tabs .nav-link:hover {
            border-color: transparent;
            color: var(--secondary-color);
        }
        
        .file-upload-container {
            border: 2px dashed #dee2e6;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s;
            background-color: #f8f9fa;
        }
        
        .file-upload-container:hover {
            border-color: var(--secondary-color);
            background-color: rgba(52, 152, 219, 0.05);
        }
        
        .file-upload-icon {
            font-size: 3rem;
            color: #6c757d;
            margin-bottom: 10px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
        
        .required-field::after {
            content: " *";
            color: var(--accent-color);
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h3 text-primary">Supplier Submission Portal</h1>
                    <a href="supplier_inbox.php" class="btn btn-outline-primary">
                        <i class="fas fa-inbox me-2"></i>Back to Inbox
                    </a>
                </div>
                
                <!-- Alert Message -->
                <?php if (!empty($message)): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-paper-plane me-2"></i>New Submission
                    </div>
                    
                    <div class="card-body">
                        <!-- Submission Type Tabs -->
                        <ul class="nav nav-tabs mb-4" id="submissionTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="message-tab" data-bs-toggle="tab" data-bs-target="#message" type="button" role="tab">
                                    <i class="fas fa-envelope me-2"></i>General Message
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="proposal-tab" data-bs-toggle="tab" data-bs-target="#proposal" type="button" role="tab">
                                    <i class="fas fa-file-alt me-2"></i>Submit Proposal
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contract-tab" data-bs-toggle="tab" data-bs-target="#contract" type="button" role="tab">
                                    <i class="fas fa-file-contract me-2"></i>Upload Contract
                                </button>
                            </li>
                        </ul>
                        
                        <form action="supplier_compose.php" method="post" enctype="multipart/form-data">
                            <input type="hidden" id="action_type" name="action_type" value="general_message">
                            
                            <div class="tab-content" id="submissionTabContent">
                                <!-- General Message Tab -->
                                <div class="tab-pane fade show active" id="message" role="tabpanel">
                                    <div class="mb-3">
                                        <label for="recipient_id" class="form-label required-field">Recipient</label>
                                        <select class="form-select" id="recipient_id" name="recipient_id" required>
                                            <option value="">Select a procurement officer</option>
                                            <?php foreach ($procurement_officers as $user) { ?>
                                                <option value="<?php echo htmlspecialchars($user['id']); ?>">
                                                    <?php echo htmlspecialchars($user['name']); ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="subject" class="form-label required-field">Subject</label>
                                        <input type="text" class="form-control" id="subject" name="subject" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="message_body" class="form-label required-field">Message</label>
                                        <textarea class="form-control" id="message_body" name="message_body" rows="6" required></textarea>
                                    </div>
                                </div>
                                
                                <!-- Proposal Tab -->
                                <div class="tab-pane fade" id="proposal" role="tabpanel">
                                    <div class="mb-3">
                                        <label for="rfq_no" class="form-label required-field">RFQ Number</label>
                                        <input type="text" class="form-control" id="rfq_no" name="rfq_no" 
                                               value="<?php echo htmlspecialchars($rfq_no_prefill); ?>" 
                                               placeholder="Enter RFQ number">
                                        <div class="form-text">Please enter the RFQ number you're responding to</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="amount" class="form-label required-field">Proposal Amount ($)</label>
                                        <input type="number" class="form-control" id="amount" name="amount" 
                                               step="0.01" min="0" placeholder="0.00">
                                    </div>
                                </div>
                                
                                <!-- Contract Tab -->
                                <div class="tab-pane fade" id="contract" role="tabpanel">
                                    <div class="mb-3">
                                        <label for="contract_id" class="form-label required-field">Contract ID</label>
                                        <input type="text" class="form-control" id="contract_id" name="contract_id" 
                                               placeholder="Enter contract ID">
                                        <div class="form-text">Please enter the contract ID you're signing</div>
                                    </div>
                                </div>
                                
                                <!-- File Upload Section -->
                                <div class="mb-4">
                                    <label class="form-label required-field">Document Attachment</label>
                                    <div class="file-upload-container" id="fileUploadContainer">
                                        <i class="fas fa-cloud-upload-alt file-upload-icon"></i>
                                        <h5>Drag & drop your file here</h5>
                                        <p class="text-muted">or</p>
                                        <input type="file" class="form-control d-none" id="document" name="document">
                                        <button type="button" class="btn btn-outline-primary" onclick="document.getElementById('document').click()">
                                            <i class="fas fa-file-upload me-2"></i>Browse Files
                                        </button>
                                        <div id="fileName" class="mt-3 text-success fw-bold"></div>
                                    </div>
                                    <div class="form-text">Required for proposals and contracts, optional for messages</div>
                                </div>
                                
                                <!-- Submit Button -->
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary btn-lg">
                                        <i class="fas fa-paper-plane me-2"></i>Submit
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        // Handle tab changes
        const submissionTabs = document.querySelectorAll('#submissionTabs .nav-link');
        const actionTypeInput = document.getElementById('action_type');
        const fileInput = document.getElementById('document');
        const fileNameDisplay = document.getElementById('fileName');
        const fileUploadContainer = document.getElementById('fileUploadContainer');
        
        // Update action type based on selected tab
        submissionTabs.forEach(tab => {
            tab.addEventListener('shown.bs.tab', event => {
                const target = event.target.getAttribute('data-bs-target');
                if (target === '#message') {
                    actionTypeInput.value = 'general_message';
                    fileInput.required = false;
                } else if (target === '#proposal') {
                    actionTypeInput.value = 'proposal';
                    fileInput.required = true;
                } else if (target === '#contract') {
                    actionTypeInput.value = 'contract';
                    fileInput.required = true;
                }
            });
        });
        
        // Handle file input changes
        fileInput.addEventListener('change', function() {
            if (this.files.length > 0) {
                fileNameDisplay.textContent = this.files[0].name;
                fileUploadContainer.style.borderColor = '#28a745';
                fileUploadContainer.style.backgroundColor = 'rgba(40, 167, 69, 0.05)';
            } else {
                fileNameDisplay.textContent = '';
                fileUploadContainer.style.borderColor = '#dee2e6';
                fileUploadContainer.style.backgroundColor = '#f8f9fa';
            }
        });
        
        // Drag and drop functionality
        fileUploadContainer.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.style.borderColor = var('--secondary-color');
            this.style.backgroundColor = 'rgba(52, 152, 219, 0.1)';
        });
        
        fileUploadContainer.addEventListener('dragleave', function() {
            this.style.borderColor = '#dee2e6';
            this.style.backgroundColor = '#f8f9fa';
        });
        
        fileUploadContainer.addEventListener('drop', function(e) {
            e.preventDefault();
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                fileNameDisplay.textContent = e.dataTransfer.files[0].name;
                this.style.borderColor = '#28a745';
                this.style.backgroundColor = 'rgba(40, 167, 69, 0.05)';
                
                // Trigger change event for validation
                const event = new Event('change');
                fileInput.dispatchEvent(event);
            }
        });
        
        // Pre-fill RFQ number if provided in URL
        <?php if (!empty($rfq_no_prefill)): ?>
        document.addEventListener('DOMContentLoaded', function() {
            // Switch to proposal tab if RFQ number is pre-filled
            const proposalTab = new bootstrap.Tab(document.getElementById('proposal-tab'));
            proposalTab.show();
        });
        <?php endif; ?>
    </script>
</body>
</html>