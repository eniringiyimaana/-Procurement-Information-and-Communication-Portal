<?php
session_start();
require_once 'users.php';

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$error = '';
$requisition = null;
$requisition_items = [];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid CSRF token. Please try again.";
    } else {
        $requisition_id = filter_input(INPUT_POST, 'requisition_id', FILTER_SANITIZE_NUMBER_INT);
        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
        $justification = filter_input(INPUT_POST, 'justification', FILTER_SANITIZE_STRING);
        $total_amount = filter_input(INPUT_POST, 'total_amount', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $department_id = filter_input(INPUT_POST, 'department_id', FILTER_SANITIZE_NUMBER_INT);

        // Validate inputs
        if (empty($title) || empty($justification) || empty($total_amount) || empty($department_id)) {
            $error = "All fields are required.";
        } else {
            $conn = connectDB();

            // Check if user owns this requisition
            $sql_check = "SELECT id FROM requisitions WHERE id = ? AND requested_by = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("ii", $requisition_id, $_SESSION['user_id']);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            
            if ($result_check->num_rows > 0) {
                // Update the main requisition table
                $sql = "UPDATE requisitions SET title = ?, justification = ?, department_id = ?, total_amount = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssidi", $title, $justification, $department_id, $total_amount, $requisition_id);
                
                if ($stmt->execute()) {
                    // First, delete old items to prevent duplicates
                    $sql_delete_items = "DELETE FROM requisition_items WHERE requisition_id = ?";
                    $stmt_delete_items = $conn->prepare($sql_delete_items);
                    $stmt_delete_items->bind_param("i", $requisition_id);
                    $stmt_delete_items->execute();
                    $stmt_delete_items->close();

                    // Then, insert the new/updated items
                    $item_descriptions = $_POST['item_description'];
                    $quantities = $_POST['quantity'];
                    $unit_measures = $_POST['unit_of_measure'];
                    $estimated_costs = $_POST['estimated_cost'];
                    
                    $sql_insert_items = "INSERT INTO requisition_items (requisition_id, item_description, quantity, unit_of_measure, estimated_cost) VALUES (?, ?, ?, ?, ?)";
                    $stmt_insert_items = $conn->prepare($sql_insert_items);
                    
                    $items_added = 0;
                    for ($i = 0; $i < count($item_descriptions); $i++) {
                        // Skip empty items
                        if (!empty(trim($item_descriptions[$i]))) {
                            $stmt_insert_items->bind_param("isssd", $requisition_id, 
                                filter_var($item_descriptions[$i], FILTER_SANITIZE_STRING),
                                filter_var($quantities[$i], FILTER_SANITIZE_NUMBER_INT),
                                filter_var($unit_measures[$i], FILTER_SANITIZE_STRING),
                                filter_var($estimated_costs[$i], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION)
                            );
                            $stmt_insert_items->execute();
                            $items_added++;
                        }
                    }
                    $stmt_insert_items->close();
                    
                    if ($items_added > 0) {
                        $message = "Requisition updated successfully!";
                    } else {
                        $error = "Requisition updated but no items were added. Please add at least one item.";
                    }
                } else {
                    $error = "Error updating requisition: " . $conn->error;
                }
                $stmt->close();
            } else {
                $error = "You don't have permission to edit this requisition.";
            }
            $stmt_check->close();
            $conn->close();
        }
    }
} else if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    // Get requisition ID from URL
    $requisition_id = $_GET['id'];
    $conn = connectDB();

    // Fetch the main requisition data
    $sql_requisition = "SELECT * FROM requisitions WHERE id = ? AND requested_by = ?";
    $stmt_requisition = $conn->prepare($sql_requisition);
    $stmt_requisition->bind_param("ii", $requisition_id, $_SESSION['user_id']);
    $stmt_requisition->execute();
    $result_requisition = $stmt_requisition->get_result();

    if ($result_requisition->num_rows > 0) {
        $requisition = $result_requisition->fetch_assoc();
        $stmt_requisition->close();

        // Fetch the requisition items
        $sql_items = "SELECT * FROM requisition_items WHERE requisition_id = ?";
        $stmt_items = $conn->prepare($sql_items);
        $stmt_items->bind_param("i", $requisition_id);
        $stmt_items->execute();
        $result_items = $stmt_items->get_result();

        while ($row = $result_items->fetch_assoc()) {
            $requisition_items[] = $row;
        }
        $stmt_items->close();
    } else {
        $error = "Requisition not found or you do not have permission to edit it.";
    }
    $conn->close();
} else {
    $error = "Invalid request.";
}

// Fetch departments for the dropdown list
$conn = connectDB();
$departments_result = $conn->query("SELECT id, name FROM departments");
$departments = [];
while($row = $departments_result->fetch_assoc()) {
    $departments[] = $row;
}
$conn->close();

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = isset($_SESSION['role_name']) ? $_SESSION['role_name'] : getUserRoleName($user_role_id);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Requisition | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        .item-row {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid var(--secondary-color);
        }
        
        .btn-remove-item {
            margin-top: 32px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Edit Requisition</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($requisition): ?>
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-edit me-2"></i>Edit Requisition
                </div>
                <div class="card-body">
                    <form action="edit_requisition.php" method="post" id="requisitionForm">
                        <input type="hidden" name="requisition_id" value="<?php echo htmlspecialchars($requisition['id']); ?>">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        
                        <div class="row mb-4">
                            <div class="col-md-8">
                                <h4 class="mb-3">Requisition Details</h4>
                                
                                <div class="mb-3">
                                    <label for="title" class="form-label">Title</label>
                                    <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($requisition['title']); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="justification" class="form-label">Justification</label>
                                    <textarea class="form-control" id="justification" name="justification" rows="4" required><?php echo htmlspecialchars($requisition['justification']); ?></textarea>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="total_amount" class="form-label">Estimated Total Amount</label>
                                        <div class="input-group">
                                            <span class="input-group-text">$</span>
                                            <input type="number" class="form-control" id="total_amount" name="total_amount" step="0.01" value="<?php echo htmlspecialchars($requisition['total_amount']); ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="department_id" class="form-label">Requesting Department</label>
                                        <select class="form-select" id="department_id" name="department_id" required>
                                            <?php foreach ($departments as $department): ?>
                                                <option value="<?php echo $department['id']; ?>" <?php echo ($department['id'] == $requisition['department_id']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($department['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="card bg-light">
                                    <div class="card-header bg-secondary text-white">
                                        <i class="fas fa-info-circle me-1"></i>Requisition Information
                                    </div>
                                    <div class="card-body">
                                        <p><strong>Status:</strong> 
                                            <span class="badge bg-<?php 
                                                switch($requisition['status']) {
                                                    case 'approved': echo 'success'; break;
                                                    case 'rejected': echo 'danger'; break;
                                                    case 'pending': echo 'warning'; break;
                                                    default: echo 'secondary';
                                                }
                                            ?>">
                                                <?php echo htmlspecialchars(ucfirst($requisition['status'])); ?>
                                            </span>
                                        </p>
                                        <p><strong>Created:</strong> <?php echo date('M j, Y', strtotime($requisition['created_at'])); ?></p>
                                        <p><strong>Last Updated:</strong> <?php echo date('M j, Y', strtotime($requisition['updated_at'])); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4>Requisition Items</h4>
                            <button type="button" class="btn btn-primary" id="addItemBtn">
                                <i class="fas fa-plus me-1"></i>Add Item
                            </button>
                        </div>
                        
                        <div id="items-container">
                            <?php if (count($requisition_items) > 0): ?>
                                <?php foreach ($requisition_items as $index => $item): ?>
                                <div class="item-row">
                                    <div class="row">
                                        <div class="col-md-5 mb-3">
                                            <label for="item_description_<?php echo $index; ?>" class="form-label">Item Description</label>
                                            <input type="text" class="form-control" name="item_description[]" value="<?php echo htmlspecialchars($item['item_description']); ?>" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label for="quantity_<?php echo $index; ?>" class="form-label">Quantity</label>
                                            <input type="number" class="form-control" name="quantity[]" value="<?php echo htmlspecialchars($item['quantity']); ?>" min="1" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label for="unit_of_measure_<?php echo $index; ?>" class="form-label">Unit of Measure</label>
                                            <input type="text" class="form-control" name="unit_of_measure[]" value="<?php echo htmlspecialchars($item['unit_of_measure']); ?>" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label for="estimated_cost_<?php echo $index; ?>" class="form-label">Estimated Cost</label>
                                            <div class="input-group">
                                                <span class="input-group-text">$</span>
                                                <input type="number" class="form-control" name="estimated_cost[]" step="0.01" value="<?php echo htmlspecialchars($item['estimated_cost']); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-1 mb-3">
                                            <label class="form-label d-block">&nbsp;</label>
                                            <button type="button" class="btn btn-danger btn-remove-item" onclick="removeItemRow(this)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    No items added to this requisition yet. Please add at least one item.
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between mt-4">
                            <a href="view_my_requisitions.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-1"></i>Back to My Requisitions
                            </a>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-save me-1"></i>Update Requisition
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <?php echo htmlspecialchars($error ? $error : "Requisition not found."); ?>
                </div>
                <div class="text-center mt-3">
                    <a href="view_my_requisitions.php" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-1"></i>Back to My Requisitions
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        let itemCount = <?php echo count($requisition_items); ?>;
        
        document.getElementById('addItemBtn').addEventListener('click', function() {
            const container = document.getElementById('items-container');
            
            // Remove the alert if it exists
            const alert = container.querySelector('.alert');
            if (alert) {
                alert.remove();
            }
            
            const newItemRow = document.createElement('div');
            newItemRow.className = 'item-row';
            newItemRow.innerHTML = `
                <div class="row">
                    <div class="col-md-5 mb-3">
                        <label class="form-label">Item Description</label>
                        <input type="text" class="form-control" name="item_description[]" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Quantity</label>
                        <input type="number" class="form-control" name="quantity[]" min="1" value="1" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Unit of Measure</label>
                        <input type="text" class="form-control" name="unit_of_measure[]" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Estimated Cost</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" class="form-control" name="estimated_cost[]" step="0.01" required>
                        </div>
                    </div>
                    <div class="col-md-1 mb-3">
                        <label class="form-label d-block">&nbsp;</label>
                        <button type="button" class="btn btn-danger btn-remove-item" onclick="removeItemRow(this)">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            
            container.appendChild(newItemRow);
            itemCount++;
        });
        
        function removeItemRow(button) {
            if (itemCount > 1) {
                const itemRow = button.closest('.item-row');
                itemRow.remove();
                itemCount--;
            } else {
                alert('A requisition must have at least one item.');
            }
        }
        
        // Calculate total amount automatically when item costs change
        document.addEventListener('input', function(e) {
            if (e.target.name === 'estimated_cost[]' || e.target.name === 'quantity[]') {
                calculateTotalAmount();
            }
        });
        
        function calculateTotalAmount() {
            let total = 0;
            const costs = document.querySelectorAll('input[name="estimated_cost[]"]');
            const quantities = document.querySelectorAll('input[name="quantity[]"]');
            
            for (let i = 0; i < costs.length; i++) {
                const cost = parseFloat(costs[i].value) || 0;
                const quantity = parseFloat(quantities[i].value) || 0;
                total += cost * quantity;
            }
            
            document.getElementById('total_amount').value = total.toFixed(2);
        }
    </script>
</body>
</html>