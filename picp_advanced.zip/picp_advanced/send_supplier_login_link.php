<?php
session_start();
require_once 'users.php';

// Check if user is logged in and has appropriate permissions
if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: index.php");
    exit;
}

$conn = connectDB();
$message = '';
$message_type = '';
$links_to_send = [];

try {
    // Fetch all pending RFQ invites
    $sql = "
        SELECT ri.id AS invite_id, ri.rfq_id, ri.supplier_id, ri.token, ri.status, ri.created_at,
               r.rfq_no, r.title AS rfq_title, r.deadline,
               s.name AS supplier_name, s.contact_email, s.contact_person
        FROM rfq_invites ri
        JOIN rfqs r ON ri.rfq_id = r.id
        JOIN suppliers s ON ri.supplier_id = s.id
        WHERE ri.status = 'pending'
        ORDER BY r.id, s.name
    ";

    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $invite_id = $row['invite_id'];
            $rfq_id = $row['rfq_id'];
            $supplier_id = $row['supplier_id'];
            $token = $row['token'];

            // Generate token if empty
            if (empty($token)) {
                $token = bin2hex(random_bytes(32));
                $stmt = $conn->prepare("UPDATE rfq_invites SET token = ? WHERE id = ?");
                $stmt->bind_param("si", $token, $invite_id);
                $stmt->execute();
                $stmt->close();
            }

            $login_link = "http://localhost/picp_advanced/supplier_login.php?token=" . urlencode($token);

            // Group by RFQ
            if (!isset($links_to_send[$rfq_id])) {
                $links_to_send[$rfq_id] = [
                    'rfq_no' => $row['rfq_no'],
                    'title' => $row['rfq_title'],
                    'deadline' => $row['deadline'],
                    'suppliers' => []
                ];
            }

            $links_to_send[$rfq_id]['suppliers'][] = [
                'supplier_name' => $row['supplier_name'],
                'contact_person' => $row['contact_person'],
                'email' => $row['contact_email'],
                'login_link' => $login_link,
                'invite_id' => $invite_id,
                'created_at' => $row['created_at']
            ];
        }
    } else {
        $message = "No pending RFQ invitations found.";
        $message_type = "info";
    }

} catch (Exception $e) {
    $message = "Error: " . $e->getMessage();
    $message_type = "danger";
} finally {
    $conn->close();
}

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = $_SESSION['role_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Login Links | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .section-title {
            border-left: 4px solid var(--secondary-color);
            padding-left: 10px;
            margin: 25px 0 15px;
            font-weight: 600;
        }
        
        .rfq-card {
            border-left: 4px solid var(--secondary-color);
            margin-bottom: 25px;
        }
        
        .supplier-card {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #f8f9fa;
        }
        
        .login-link {
            background-color: #e9ecef;
            padding: 10px;
            border-radius: 5px;
            font-family: monospace;
            word-break: break-all;
        }
        
        .copy-btn {
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .copy-btn:hover {
            transform: scale(1.05);
        }
        
        .status-badge {
            font-size: 0.8rem;
            padding: 4px 10px;
            border-radius: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_rfqs.php">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Manage RFQs</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_suppliers.php">
                    <i class="fas fa-truck"></i>
                    <span>Manage Suppliers</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="send_supplier_login_link.php">
                    <i class="fas fa-link"></i>
                    <span>Supplier Links</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0"><i class="fas fa-link me-2"></i>Supplier Login Links</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Content -->
        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                    <i class="fas <?php echo $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> me-2"></i>
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-paper-plane me-2"></i>Send Supplier Login Links
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Copy the unique links below and send them to the respective suppliers. These links remain valid until the RFQ deadline or until manually revoked.
                    </div>
                    
                    <?php if (!empty($links_to_send)): ?>
                        <?php foreach ($links_to_send as $rfq_id => $rfq): ?>
                            <div class="rfq-card p-4 mb-4 bg-white rounded shadow-sm">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h4 class="text-primary"><?php echo htmlspecialchars($rfq['rfq_no']); ?></h4>
                                        <h5><?php echo htmlspecialchars($rfq['title']); ?></h5>
                                        <?php if (!empty($rfq['deadline'])): ?>
                                            <p class="text-muted">
                                                <i class="fas fa-clock me-1"></i>
                                                Deadline: <?php echo date('M j, Y', strtotime($rfq['deadline'])); ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                    <span class="status-badge bg-warning text-dark">Pending Response</span>
                                </div>
                                
                                <div class="row">
                                    <?php foreach ($rfq['suppliers'] as $supplier): ?>
                                        <div class="col-md-6 mb-3">
                                            <div class="supplier-card">
                                                <div class="d-flex justify-content-between align-items-start mb-2">
                                                    <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($supplier['supplier_name']); ?></h6>
                                                    <small class="text-muted">
                                                        <?php echo date('M j, Y', strtotime($supplier['created_at'])); ?>
                                                    </small>
                                                </div>
                                                
                                                <?php if (!empty($supplier['contact_person'])): ?>
                                                    <p class="mb-1"><i class="fas fa-user me-1"></i> <?php echo htmlspecialchars($supplier['contact_person']); ?></p>
                                                <?php endif; ?>
                                                
                                                <p class="mb-2"><i class="fas fa-envelope me-1"></i> <?php echo htmlspecialchars($supplier['email']); ?></p>
                                                
                                                <div class="mb-3">
                                                    <label class="form-label small text-muted mb-1">Secure Login Link:</label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control login-link" value="<?php echo htmlspecialchars($supplier['login_link']); ?>" readonly id="link-<?php echo $supplier['invite_id']; ?>">
                                                        <button class="btn btn-outline-secondary copy-btn" type="button" data-link="link-<?php echo $supplier['invite_id']; ?>">
                                                            <i class="fas fa-copy"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                                
                                                <div class="d-flex gap-2">
                                                    <a href="mailto:<?php echo htmlspecialchars($supplier['email']); ?>?subject=RFQ%20Login%20Link&body=Dear%20Supplier,%0A%0APlease%20use%20this%20link%20to%20access%20our%20RFQ%20system:%0A%0A<?php echo urlencode($supplier['login_link']); ?>%0A%0ARegards,%0AProcurement%20Team" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-envelope me-1"></i> Send Email
                                                    </a>
                                                    <button class="btn btn-sm btn-outline-secondary copy-btn" data-link="link-<?php echo $supplier['invite_id']; ?>">
                                                        <i class="fas fa-copy me-1"></i> Copy Link
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <h4 class="text-muted">No Pending Invitations</h4>
                            <p class="text-muted">There are no pending RFQ invitations requiring login links.</p>
                            <a href="manage_rfq.php" class="btn btn-primary">
                                <i class="fas fa-clipboard-list me-1"></i> Manage RFQs
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Copy to clipboard functionality
            document.querySelectorAll('.copy-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const linkId = this.getAttribute('data-link');
                    const linkInput = document.getElementById(linkId);
                    
                    linkInput.select();
                    linkInput.setSelectionRange(0, 99999); // For mobile devices
                    
                    try {
                        navigator.clipboard.writeText(linkInput.value).then(() => {
                            // Show temporary feedback
                            const originalHtml = this.innerHTML;
                            this.innerHTML = '<i class="fas fa-check me-1"></i> Copied!';
                            this.classList.add('btn-success');
                            this.classList.remove('btn-outline-secondary');
                            
                            setTimeout(() => {
                                this.innerHTML = originalHtml;
                                this.classList.remove('btn-success');
                                this.classList.add('btn-outline-secondary');
                            }, 2000);
                        });
                    } catch (err) {
                        // Fallback for browsers that don't support clipboard API
                        document.execCommand('copy');
                        
                        // Show temporary feedback
                        const originalHtml = this.innerHTML;
                        this.innerHTML = '<i class="fas fa-check me-1"></i> Copied!';
                        this.classList.add('btn-success');
                        this.classList.remove('btn-outline-secondary');
                        
                        setTimeout(() => {
                            this.innerHTML = originalHtml;
                            this.classList.remove('btn-success');
                            this.classList.add('btn-outline-secondary');
                        }, 2000);
                    }
                });
            });
            
            // Auto-select text when clicking on input
            document.querySelectorAll('.login-link').forEach(input => {
                input.addEventListener('click', function() {
                    this.select();
                });
            });
        });
    </script>
</body>
</html>