<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and is an Admin
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    header("location: index.php");
    exit;
}

$message = '';
$conn = connectDB();

// Handle form submission to add a new GL account
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'add') {
    $account_no = $_POST['account_no'];
    $account_name = $_POST['account_name'];
    $account_type = $_POST['account_type'];

    $sql = "INSERT INTO gl_accounts (account_no, account_name, account_type) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $account_no, $account_name, $account_type);

    if ($stmt->execute()) {
        $message = "GL Account added successfully!";
    } else {
        $message = "Error adding GL Account: " . $stmt->error;
    }
    $stmt->close();
}

// Handle deletion of a GL account
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $account_id = $_GET['id'];
    $sql = "DELETE FROM gl_accounts WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $account_id);
    if ($stmt->execute()) {
        $message = "GL Account deleted successfully!";
    } else {
        $message = "Error deleting GL Account: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch all existing GL accounts
$gl_accounts = [];
$sql = "SELECT * FROM gl_accounts ORDER BY account_no ASC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $gl_accounts[] = $row;
    }
}
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage GL Accounts | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .account-type-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .type-asset {
            background-color: #28a745;
            color: white;
        }
        
        .type-liability {
            background-color: #dc3545;
            color: white;
        }
        
        .type-equity {
            background-color: #6f42c1;
            color: white;
        }
        
        .type-revenue {
            background-color: #20c997;
            color: white;
        }
        
        .type-expense {
            background-color: #fd7e14;
            color: white;
        }
        
        .action-btn {
            padding: 5px 10px;
            border-radius: 4px;
            transition: all 0.2s;
        }
        
        .action-btn:hover {
            background-color: #f8f9fa;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_departments.php">
                    <i class="fas fa-building"></i>
                    <span>Manage Departments</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="manage_gl_accounts.php">
                    <i class="fas fa-chart-line"></i>
                    <span>Manage GL Accounts</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_budgets.php">
                    <i class="fas fa-wallet"></i>
                    <span>Manage Budgets</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage General Ledger Accounts</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- GL Accounts Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Quick Stats -->
            <?php
            $account_types = ['Asset', 'Liability', 'Equity', 'Revenue', 'Expense'];
            $account_counts = array_fill_keys($account_types, 0);
            
            foreach ($gl_accounts as $account) {
                if (isset($account_counts[$account['account_type']])) {
                    $account_counts[$account['account_type']]++;
                }
            }
            ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary"><?php echo count($gl_accounts); ?></div>
                        <div class="stats-label">Total GL Accounts</div>
                    </div>
                </div>
                <?php foreach ($account_types as $type): ?>
                <div class="col-md-2">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number"><?php echo $account_counts[$type]; ?></div>
                        <div class="stats-label"><?php echo $type; ?> Accounts</div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Add New GL Account Form -->
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-plus-circle me-2"></i>Add New GL Account
                </div>
                <div class="card-body">
                    <form action="manage_gl_accounts.php" method="post">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="account_no" class="form-label">Account No</label>
                                <input type="number" class="form-control" id="account_no" name="account_no" required>
                            </div>
                            <div class="col-md-5 mb-3">
                                <label for="account_name" class="form-label">Account Name</label>
                                <input type="text" class="form-control" id="account_name" name="account_name" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="account_type" class="form-label">Account Type</label>
                                <select class="form-select" id="account_type" name="account_type" required>
                                    <option value="Asset">Asset</option>
                                    <option value="Liability">Liability</option>
                                    <option value="Equity">Equity</option>
                                    <option value="Revenue">Revenue</option>
                                    <option value="Expense">Expense</option>
                                </select>
                            </div>
                            <div class="col-md-1 mb-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-plus me-1"></i> Add
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Existing GL Accounts -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-list me-2"></i>Existing GL Accounts</span>
                    <span class="badge bg-light text-dark"><?php echo count($gl_accounts); ?> accounts</span>
                </div>
                <div class="card-body">
                    <?php if (count($gl_accounts) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Account No</th>
                                    <th>Account Name</th>
                                    <th>Account Type</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($gl_accounts as $account): 
                                    $type_class = 'type-' . strtolower($account['account_type']);
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($account['account_no']); ?></strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($account['account_name']); ?></td>
                                    <td>
                                        <span class="account-type-badge <?php echo $type_class; ?>">
                                            <?php echo htmlspecialchars($account['account_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="manage_gl_accounts.php?action=delete&id=<?php echo htmlspecialchars($account['id']); ?>" 
                                           class="btn btn-sm btn-outline-danger" 
                                           onclick="return confirm('Are you sure you want to delete this account?');">
                                            <i class="fas fa-trash me-1"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-chart-line fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No GL Accounts Found</h4>
                        <p class="text-muted">Use the form above to add your first GL account.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>