<?php
session_start();
require_once 'users.php'; // Reuse the database connection

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

// Check if the user is an admin or has the right role to approve (e.g., role_id = 1)
if ($_SESSION['role_id'] != 1) {
    echo "You do not have permission to access this page.";
    exit;
}

$message = '';
// Handle approval/rejection submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $requisition_id = $_POST['requisition_id'];
    $decision = $_POST['decision'];
    $comment = $_POST['comment'];
    $approver_id = $_SESSION['user_id'];

    $conn = connectDB();

    // Begin a transaction to ensure both tables are updated correctly
    $conn->begin_transaction();

    try {
        // Update the requisition status
        $status = ($decision == 'approved') ? 'approved' : 'rejected';
        $sql_update_req = "UPDATE requisitions SET status = ? WHERE id = ?";
        $stmt_update_req = $conn->prepare($sql_update_req);
        $stmt_update_req->bind_param("si", $status, $requisition_id);
        $stmt_update_req->execute();
        $stmt_update_req->close();

        // Insert into the approvals table
        $sql_insert_approval = "INSERT INTO approvals (object_type, object_id, approver_id, decision, comment, decided_at) VALUES ('requisition', ?, ?, ?, ?, NOW())";
        $stmt_insert_approval = $conn->prepare($sql_insert_approval);
        $stmt_insert_approval->bind_param("iiss", $requisition_id, $approver_id, $decision, $comment);
        $stmt_insert_approval->execute();
        $stmt_insert_approval->close();
        
        $conn->commit();
        $message = "Requisition ID " . $requisition_id . " has been " . $status . "!";
        
        // Redirect to prevent form resubmission
        header("location: manage_approvals.php?message=" . urlencode($message));
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error processing approval: " . $e->getMessage();
    } finally {
        $conn->close();
    }
}

// Check for a message in the URL
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

$conn = connectDB();

// Fetch requisitions that are pending approval
$sql = "SELECT r.*, u.name as requested_by_name, d.name as department_name FROM requisitions r
        JOIN users u ON r.requested_by = u.id
        JOIN departments d ON r.department_id = d.id
        WHERE r.status = 'submitted' OR r.status = 'pending_approval'
        ORDER BY r.created_at ASC";
$result = $conn->query($sql);

$requisitions = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $requisitions[] = $row;
    }
}
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Approvals | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .requisition-card {
            border-left: 4px solid var(--secondary-color);
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
        }
        
        .status-pending {
            background-color: #ffc107;
            color: black;
        }
        
        .status-submitted {
            background-color: #17a2b8;
            color: white;
        }
        
        .status-approved {
            background-color: #28a745;
            color: white;
        }
        
        .status-rejected {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-approve {
            background-color: #28a745;
            border-color: #28a745;
        }
        
        .btn-reject {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        
        .btn-create-po {
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
        
        .decision-form {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link active" href="manage_approvals.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Requisition Approvals</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Approval Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Page Header -->
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-tasks me-2"></i>Pending Requisition Approvals
                </div>
                <div class="card-body">
                    <p class="mb-0">This is your inbox for procurement requisitions requiring your approval.</p>
                </div>
            </div>

            <!-- Requisitions List -->
            <?php if (count($requisitions) > 0): ?>
                <?php foreach ($requisitions as $requisition): 
                    $status_class = 'status-' . $requisition['status'];
                ?>
                <div class="dashboard-card requisition-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h4>Requisition #<?php echo htmlspecialchars($requisition['id']); ?>: <?php echo htmlspecialchars($requisition['title']); ?></h4>
                                <span class="status-badge <?php echo $status_class; ?>">
                                    <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $requisition['status']))); ?>
                                </span>
                            </div>
                            <div class="text-muted">
                                <small>Submitted: <?php echo date('M j, Y g:i A', strtotime($requisition['created_at'])); ?></small>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <p><strong>Requested by:</strong> <?php echo htmlspecialchars($requisition['requested_by_name']); ?></p>
                                <p><strong>Department:</strong> <?php echo htmlspecialchars($requisition['department_name']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Priority:</strong> <?php echo htmlspecialchars(ucfirst($requisition['priority'])); ?></p>
                                <p><strong>Total Amount:</strong> $<?php echo number_format($requisition['total_amount'], 2); ?></p>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Justification:</strong>
                            <p class="mt-1"><?php echo nl2br(htmlspecialchars($requisition['justification'])); ?></p>
                        </div>
                        
                        <?php if ($requisition['status'] == 'submitted' || $requisition['status'] == 'pending_approval'): ?>
                        <div class="decision-form">
                            <form action="manage_approvals.php" method="post">
                                <input type="hidden" name="requisition_id" value="<?php echo htmlspecialchars($requisition['id']); ?>">
                                
                                <div class="mb-3">
                                    <label class="form-label"><strong>Decision:</strong></label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="decision" id="approve_<?php echo $requisition['id']; ?>" value="approved" required>
                                        <label class="form-check-label text-success" for="approve_<?php echo $requisition['id']; ?>">
                                            <i class="fas fa-check-circle me-1"></i>Approve
                                        </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="decision" id="reject_<?php echo $requisition['id']; ?>" value="rejected">
                                        <label class="form-check-label text-danger" for="reject_<?php echo $requisition['id']; ?>">
                                            <i class="fas fa-times-circle me-1"></i>Reject
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="comment_<?php echo $requisition['id']; ?>" class="form-label">Comment:</label>
                                    <textarea class="form-control" name="comment" id="comment_<?php echo $requisition['id']; ?>" rows="3" placeholder="Add your comments here..."></textarea>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-1"></i> Submit Decision
                                </button>
                            </form>
                        </div>
                        <?php elseif ($requisition['status'] == 'approved'): ?>
                        <div class="mt-3">
                            <a href="create_po.php?requisition_id=<?php echo htmlspecialchars($requisition['id']); ?>" class="btn btn-create-po text-white">
                                <i class="fas fa-file-invoice-dollar me-1"></i> Create Purchase Order
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
            <div class="dashboard-card">
                <div class="card-body text-center py-5">
                    <i class="fas fa-check-circle fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No Pending Approvals</h4>
                    <p class="text-muted">All requisitions have been processed. Check back later for new requests.</p>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>