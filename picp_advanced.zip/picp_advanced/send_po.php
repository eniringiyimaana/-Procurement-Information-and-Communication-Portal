<?php
session_start();
require_once 'users.php';

// Check user login
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

// Get PO ID
$po_id = isset($_GET['po_id']) ? (int)$_GET['po_id'] : 0;
if ($po_id <= 0) {
    die("Purchase Order ID is required.");
}

$conn = connectDB();

// Fetch PO and supplier details
$sql_po = "
    SELECT po.*, s.name AS supplier_name, s.email AS supplier_email, 
           s.contact_person, s.phone, s.address AS supplier_address,
           r.requisition_no, r.title AS requisition_title,
           u.name AS prepared_by
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.supplier_id = s.id
    LEFT JOIN requisitions r ON po.requisition_id = r.id
    LEFT JOIN users u ON po.created_by = u.id
    WHERE po.id = ?
";
$stmt = $conn->prepare($sql_po);
if (!$stmt) die("Prepare failed: ".$conn->error);
$stmt->bind_param("i", $po_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) die("Purchase Order not found.");
$po = $result->fetch_assoc();
$stmt->close();

// Fetch PO items
$sql_items = "SELECT * FROM po_items WHERE purchase_order_id = ?";
$stmt_items = $conn->prepare($sql_items);
$stmt_items->bind_param("i", $po_id);
$stmt_items->execute();
$items_result = $stmt_items->get_result();
$po_items = [];
while ($row = $items_result->fetch_assoc()) {
    $po_items[] = $row;
}
$stmt_items->close();
$conn->close();

$message = '';
$message_type = '';
$email_sent = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send_po'])) {
    // Include TCPDF library
    require_once '../libs/tcpdf/tcpdf.php';

    // Create PDF
    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);

    // Title
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, "PURCHASE ORDER", 0, 1, 'C');
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, "PO Number: ".$po['po_no'], 0, 1, 'C');
    $pdf->Ln(5);

    // Company and Supplier Info
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(95, 10, 'FROM:', 0, 0);
    $pdf->Cell(95, 10, 'TO:', 0, 1);
    $pdf->SetFont('helvetica', '', 11);
    
    $pdf->Cell(95, 6, 'Your Company Name', 0, 0);
    $pdf->Cell(95, 6, $po['supplier_name'], 0, 1);
    
    $pdf->Cell(95, 6, '123 Business Avenue', 0, 0);
    if (!empty($po['supplier_address'])) {
        $pdf->Cell(95, 6, $po['supplier_address'], 0, 1);
    } else {
        $pdf->Cell(95, 6, '', 0, 1);
    }
    
    $pdf->Cell(95, 6, 'City, State 12345', 0, 0);
    if (!empty($po['contact_person'])) {
        $pdf->Cell(95, 6, 'Attn: ' . $po['contact_person'], 0, 1);
    } else {
        $pdf->Cell(95, 6, '', 0, 1);
    }
    
    $pdf->Cell(95, 6, 'Phone: (123) 456-7890', 0, 0);
    if (!empty($po['phone'])) {
        $pdf->Cell(95, 6, 'Phone: ' . $po['phone'], 0, 1);
    } else {
        $pdf->Cell(95, 6, '', 0, 1);
    }
    
    $pdf->Cell(95, 6, 'Email: procurement@yourcompany.com', 0, 0);
    $pdf->Cell(95, 6, 'Email: ' . $po['supplier_email'], 0, 1);
    
    $pdf->Ln(10);

    // PO Details
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(40, 10, 'PO Date:', 0, 0);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->Cell(50, 10, date('M j, Y', strtotime($po['created_at'])), 0, 0);
    
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(40, 10, 'Requisition:', 0, 0);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->Cell(0, 10, $po['requisition_no'], 0, 1);
    
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(40, 10, 'Prepared By:', 0, 0);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->Cell(50, 10, $po['prepared_by'], 0, 0);
    
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(40, 10, 'Total Amount:', 0, 0);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->Cell(0, 10, '$' . number_format($po['total_amount'], 2), 0, 1);
    
    $pdf->Ln(10);

    // Table header
    $pdf->SetFont('helvetica', 'B', 12);
    $html = '<table border="1" cellpadding="5" style="border-collapse: collapse;">
    <tr style="background-color: #f2f2f2;">
    <th width="10%">#</th>
    <th width="45%">Description</th>
    <th width="15%">Quantity</th>
    <th width="15%">Unit Price</th>
    <th width="15%">Total</th>
    </tr>';

    $subtotal = 0;
    foreach ($po_items as $i => $item) {
        $item_total = $item['quantity'] * $item['unit_price'];
        $subtotal += $item_total;
        
        $html .= '<tr>
        <td>'.($i+1).'</td>
        <td>'.htmlspecialchars($item['item_description']).'</td>
        <td>'.$item['quantity'].'</td>
        <td>$'.number_format($item['unit_price'],2).'</td>
        <td>$'.number_format($item_total,2).'</td>
        </tr>';
    }

    // Total row
    $html .= '<tr style="background-color: #f2f2f2; font-weight: bold;">
        <td colspan="4" align="right">Total:</td>
        <td>$'.number_format($subtotal,2).'</td>
    </tr>';

    $html .= '</table>';
    $pdf->writeHTML($html, true, false, true, false, '');
    
    $pdf->Ln(10);
    
    // Terms and conditions
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'Terms and Conditions:', 0, 1);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->MultiCell(0, 8, "1. Delivery must be made within 30 days of order confirmation.\n2. All goods must meet the quality standards specified.\n3. Payment will be made within 30 days of satisfactory delivery.\n4. Any variations to this order must be approved in writing.");

    // Save PDF to a temporary file
    $pdf_file = sys_get_temp_dir() . "/PO_".$po['po_no'].".pdf";
    $pdf->Output($pdf_file, 'F');

    // Send email with attachment
    $to = $po['supplier_email'];
    $subject = "Purchase Order " . $po['po_no'] . " - " . $po['supplier_name'];
    $message_body = "
    <html>
    <body>
        <p>Dear " . $po['supplier_name'] . ",</p>
        
        <p>Please find attached Purchase Order <strong>" . $po['po_no'] . "</strong> for your reference and processing.</p>
        
        <p><strong>PO Details:</strong></p>
        <ul>
            <li>PO Number: " . $po['po_no'] . "</li>
            <li>Requisition: " . $po['requisition_no'] . " - " . $po['requisition_title'] . "</li>
            <li>Total Amount: $" . number_format($po['total_amount'], 2) . "</li>
            <li>Prepared By: " . $po['prepared_by'] . "</li>
        </ul>
        
        <p>Please acknowledge receipt of this purchase order and confirm the delivery timeline.</p>
        
        <p>Regards,<br>
        Procurement Team<br>
        Your Company Name</p>
    </body>
    </html>
    ";

    // Use PHPMailer for better email handling
    require '../libs/PHPMailer/PHPMailerAutoload.php';
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host = 'localhost';  // Specify your SMTP server
    $mail->SMTPAuth = false;
    $mail->SMTPAutoTLS = false;
    $mail->Port = 25;
    
    $mail->setFrom('procurement@yourcompany.com', 'Procurement Team');
    $mail->addAddress($to, $po['supplier_name']);
    if (!empty($po['contact_person'])) {
        $mail->addCC($po['supplier_email'], $po['contact_person']);
    }
    $mail->Subject = $subject;
    $mail->isHTML(true);
    $mail->Body = $message_body;
    $mail->addAttachment($pdf_file, 'PO_' . $po['po_no'] . '.pdf');

    if($mail->send()){
        $message = "Purchase Order successfully sent to " . $po['supplier_name'] . " (" . $po['supplier_email'] . ")";
        $message_type = "success";
        $email_sent = true;
        
        // Update PO status to sent
        $conn = connectDB();
        $sql_update = "UPDATE purchase_orders SET status = 'sent' WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("i", $po_id);
        $stmt_update->execute();
        $stmt_update->close();
        $conn->close();
    } else {
        $message = "Failed to send PO. Mailer Error: " . $mail->ErrorInfo;
        $message_type = "danger";
    }

    // Delete temp file
    unlink($pdf_file);
}

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = $_SESSION['role_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Purchase Order | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .section-title {
            border-left: 4px solid var(--secondary-color);
            padding-left: 10px;
            margin: 25px 0 15px;
            font-weight: 600;
        }
        
        .status-badge {
            font-size: 0.9rem;
            padding: 5px 15px;
            border-radius: 20px;
        }
        
        .info-card {
            background-color: #e9ecef;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .email-preview {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin-top: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_purchase_orders.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Purchase Orders</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="#">
                    <i class="fas fa-paper-plane"></i>
                    <span>Send PO</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="receive_goods.php">
                    <i class="fas fa-truck-loading"></i>
                    <span>Receive Goods</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0"><i class="fas fa-paper-plane me-2"></i>Send Purchase Order</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Content -->
        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                    <i class="fas <?php echo $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> me-2"></i>
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="section-title">Send Purchase Order to Supplier</h4>
                <a href="view_purchase_orders.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Purchase Orders
                </a>
            </div>
    
            <!-- PO Information Card -->
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-file-invoice-dollar me-2"></i>Purchase Order Details
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-card">
                                <h6 class="fw-bold">PO Information</h6>
                                <p class="mb-1"><strong>PO Number:</strong> <?= htmlspecialchars($po['po_no']); ?></p>
                                <p class="mb-1"><strong>Status:</strong> 
                                    <span class="status-badge 
                                        <?= $po['status'] == 'approved' ? 'bg-success' : 
                                          ($po['status'] == 'pending' ? 'bg-warning text-dark' : 
                                          ($po['status'] == 'sent' ? 'bg-info' : 'bg-secondary')); ?>">
                                        <?= ucfirst($po['status']); ?>
                                    </span>
                                </p>
                                <p class="mb-1"><strong>Requisition:</strong> <?= htmlspecialchars($po['requisition_no']); ?></p>
                                <p class="mb-1"><strong>Title:</strong> <?= htmlspecialchars($po['requisition_title']); ?></p>
                                <p class="mb-0"><strong>Total Amount:</strong> $<?= number_format($po['total_amount'], 2); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-card">
                                <h6 class="fw-bold">Supplier Information</h6>
                                <p class="mb-1"><strong>Name:</strong> <?= htmlspecialchars($po['supplier_name']); ?></p>
                                <?php if (!empty($po['contact_person'])): ?>
                                <p class="mb-1"><strong>Contact:</strong> <?= htmlspecialchars($po['contact_person']); ?></p>
                                <?php endif; ?>
                                <?php if (!empty($po['phone'])): ?>
                                <p class="mb-1"><strong>Phone:</strong> <?= htmlspecialchars($po['phone']); ?></p>
                                <?php endif; ?>
                                <p class="mb-1"><strong>Email:</strong> <?= htmlspecialchars($po['supplier_email']); ?></p>
                                <?php if (!empty($po['supplier_address'])): ?>
                                <p class="mb-0"><strong>Address:</strong> <?= htmlspecialchars($po['supplier_address']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Items Table -->
                    <h6 class="fw-bold mt-4">Items Ordered</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Description</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $subtotal = 0;
                                foreach ($po_items as $index => $item) { 
                                    $item_total = $item['quantity'] * $item['unit_price'];
                                    $subtotal += $item_total;
                                ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td>
                                        <td><?= htmlspecialchars($item['item_description']) ?></td>
                                        <td><?= htmlspecialchars($item['quantity']) ?></td>
                                        <td>$<?= number_format($item['unit_price'], 2) ?></td>
                                        <td>$<?= number_format($item_total, 2) ?></td>
                                    </tr>
                                <?php } ?>
                                <tr class="table-primary fw-bold">
                                    <td colspan="4" class="text-end">Total:</td>
                                    <td>$<?= number_format($subtotal, 2) ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Email Preview -->
                    <div class="email-preview mt-4">
                        <h6 class="fw-bold">Email Preview</h6>
                        <p><strong>To:</strong> <?= htmlspecialchars($po['supplier_email']); ?></p>
                        <p><strong>Subject:</strong> Purchase Order <?= htmlspecialchars($po['po_no']); ?> - <?= htmlspecialchars($po['supplier_name']); ?></p>
                        <div class="border p-3 bg-white">
                            <p>Dear <?= htmlspecialchars($po['supplier_name']); ?>,</p>
                            <p>Please find attached Purchase Order <strong><?= htmlspecialchars($po['po_no']); ?></strong> for your reference and processing.</p>
                            <p>Please acknowledge receipt of this purchase order and confirm the delivery timeline.</p>
                            <p>Regards,<br>
                            Procurement Team<br>
                            Your Company Name</p>
                        </div>
                    </div>
                    
                    <!-- Send Button -->
                    <?php if (!$email_sent): ?>
                    <form action="send_po.php?po_id=<?= $po_id ?>" method="post" class="mt-4">
                        <div class="d-grid">
                            <button type="submit" name="send_po" class="btn btn-success btn-lg">
                                <i class="fas fa-paper-plane me-2"></i> Send Purchase Order to Supplier
                            </button>
                        </div>
                    </form>
                    <?php else: ?>
                    <div class="d-grid mt-4">
                        <a href="view_purchase_orders.php" class="btn btn-primary">
                            <i class="fas fa-list me-2"></i> Return to Purchase Orders
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>