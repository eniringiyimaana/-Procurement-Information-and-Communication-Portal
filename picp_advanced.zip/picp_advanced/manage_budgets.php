<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and is an Admin
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    header("location: index.php");
    exit;
}

$message = '';
$conn = connectDB();

// Handle form submission to add/update a budget
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $department_id = $_POST['department_id'];
    $fiscal_year = $_POST['fiscal_year'];
    $allocated_amount = $_POST['allocated_amount'];

    // Check if a budget for this department and fiscal year already exists
    $sql_check = "SELECT id FROM budgets WHERE department_id = ? AND fiscal_year = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("is", $department_id, $fiscal_year);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    $stmt_check->close();

    if ($result_check->num_rows > 0) {
        // Budget exists, update it
        $sql = "UPDATE budgets SET allocated_amount = ? WHERE department_id = ? AND fiscal_year = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("dis", $allocated_amount, $department_id, $fiscal_year);
        if ($stmt->execute()) {
            $message = "Budget updated successfully!";
        } else {
            $message = "Error updating budget: " . $stmt->error;
        }
        $stmt->close();
    } else {
        // Budget does not exist, insert a new one
        $sql = "INSERT INTO budgets (department_id, fiscal_year, allocated_amount) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isd", $department_id, $fiscal_year, $allocated_amount);
        if ($stmt->execute()) {
            $message = "Budget added successfully!";
        } else {
            $message = "Error adding budget: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Fetch all budgets with department names
$budgets = [];
$sql_budgets = "SELECT b.*, d.name AS department_name FROM budgets b JOIN departments d ON b.department_id = d.id ORDER BY b.fiscal_year DESC, d.name ASC";
$result_budgets = $conn->query($sql_budgets);
if ($result_budgets) {
    while ($row = $result_budgets->fetch_assoc()) {
        $budgets[] = $row;
    }
}

// Fetch all departments for the form dropdown
$departments = [];
$sql_departments = "SELECT id, name FROM departments ORDER BY name ASC";
$result_departments = $conn->query($sql_departments);
if ($result_departments) {
    while ($row = $result_departments->fetch_assoc()) {
        $departments[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Budgets | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .budget-positive {
            color: #28a745;
            font-weight: 600;
        }
        
        .budget-negative {
            color: #dc3545;
            font-weight: 600;
        }
        
        .progress {
            height: 8px;
            margin-bottom: 5px;
        }
        
        .progress-bar-overbudget {
            background-color: #dc3545;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="manage_budgets.php">
                    <i class="fas fa-wallet"></i>
                    <span>Manage Budgets</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Department Budgets</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Budget Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Add/Update Budget Form -->
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-plus-circle me-2"></i>Add/Update Budget
                </div>
                <div class="card-body">
                    <form action="manage_budgets.php" method="post">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="department_id" class="form-label">Department</label>
                                <select class="form-select" name="department_id" id="department_id" required>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept['id']); ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="fiscal_year" class="form-label">Fiscal Year</label>
                                <input type="number" class="form-control" id="fiscal_year" name="fiscal_year" min="2000" max="2100" value="<?php echo date("Y"); ?>" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="allocated_amount" class="form-label">Allocated Amount ($)</label>
                                <input type="number" class="form-control" id="allocated_amount" name="allocated_amount" step="0.01" min="0" required>
                            </div>
                            <div class="col-md-2 mb-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-save me-1"></i> Save Budget
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Current Budgets -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-wallet me-2"></i>Current Budgets</span>
                    <span class="badge bg-light text-dark"><?php echo count($budgets); ?> budget entries</span>
                </div>
                <div class="card-body">
                    <?php if (count($budgets) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Department</th>
                                    <th>Fiscal Year</th>
                                    <th>Allocated Budget</th>
                                    <th>Committed Spend</th>
                                    <th>Actual Spent</th>
                                    <th>Remaining Budget</th>
                                    <th>Utilization</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($budgets as $budget): 
                                    $remaining = $budget['allocated_amount'] - $budget['spent_amount'] - $budget['committed_amount'];
                                    $utilization_percent = $budget['allocated_amount'] > 0 ? 
                                        (($budget['spent_amount'] + $budget['committed_amount']) / $budget['allocated_amount']) * 100 : 0;
                                    $remaining_class = $remaining < 0 ? 'budget-negative' : 'budget-positive';
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($budget['department_name']); ?></td>
                                    <td><?php echo htmlspecialchars($budget['fiscal_year']); ?></td>
                                    <td>$<?php echo number_format($budget['allocated_amount'], 2); ?></td>
                                    <td>$<?php echo number_format($budget['committed_amount'], 2); ?></td>
                                    <td>$<?php echo number_format($budget['spent_amount'], 2); ?></td>
                                    <td class="<?php echo $remaining_class; ?>">$<?php echo number_format($remaining, 2); ?></td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar <?php echo $utilization_percent > 100 ? 'progress-bar-overbudget' : ''; ?>" 
                                                 role="progressbar" 
                                                 style="width: <?php echo min($utilization_percent, 100); ?>%;"
                                                 aria-valuenow="<?php echo $utilization_percent; ?>" 
                                                 aria-valuemin="0" 
                                                 aria-valuemax="100">
                                            </div>
                                        </div>
                                        <small><?php echo number_format($utilization_percent, 1); ?>%</small>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-wallet fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No Budgets Configured</h4>
                        <p class="text-muted">Use the form above to add your first budget allocation.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>