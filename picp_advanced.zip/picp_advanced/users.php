<?php
// Database connection function
function connectDB() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "picp_advanced"; // Change this to your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Function to get the role name from the database based on the role ID
function getUserRoleName($role_id) {
    $conn = connectDB();
    $sql = "SELECT name FROM roles WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $role_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $role_name = null;
    if ($row = $result->fetch_assoc()) {
        $role_name = $row['name'];
    }
    $stmt->close();
    $conn->close();
    return $role_name;
}

// Function to register a new user
function registerUser($name, $email, $password, $department_id, $role_id, $location_id, $phone_number, $job_title) {
    $conn = connectDB();
    
    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // CORRECTED: The SQL query now uses 'password_hash' instead of 'password'
    $sql = "INSERT INTO users (name, email, password_hash, department_id, role_id, location_id, phone_number, job_title) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sssiisss", $name, $email, $hashed_password, $department_id, $role_id, $location_id, $phone_number, $job_title);
        $success = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $success;
    } else {
        // Handle SQL prepare error
        error_log("Failed to prepare statement: " . $conn->error);
        $conn->close();
        return false;
    }
}
?>