<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and has the right role (e.g., Admin or Finance)
if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: index.php");
    exit;
}

$conn = connectDB();

// Calculate total invoice amount
$sql_invoices = "SELECT SUM(amount) as total_invoices FROM invoices";
$result_invoices = $conn->query($sql_invoices);
$total_invoices = $result_invoices->fetch_assoc()['total_invoices'] ?? 0;

// Calculate total payments amount
$sql_payments = "SELECT SUM(amount) as total_payments FROM payments";
$result_payments = $conn->query($sql_payments);
$total_payments = $result_payments->fetch_assoc()['total_payments'] ?? 0;

$outstanding_balance = $total_invoices - $total_payments;

// Fetch a list of invoices with their status and payment details
$sql_report = "SELECT i.invoice_no, i.amount as invoice_amount, i.status, i.due_date, po.po_no, s.name as supplier_name, p.amount as payment_amount, p.payment_date
               FROM invoices i
               JOIN purchase_orders po ON i.purchase_order_id = po.id
               JOIN suppliers s ON i.supplier_id = s.id
               LEFT JOIN payments p ON i.id = p.invoice_id
               ORDER BY i.due_date ASC";
$result_report = $conn->query($sql_report);

$invoices_report = [];
if ($result_report && $result_report->num_rows > 0) {
    while ($row = $result_report->fetch_assoc()) {
        $invoices_report[] = $row;
    }
}
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice Report | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
        }
        
        .status-paid {
            background-color: #28a745;
            color: white;
        }
        
        .status-pending {
            background-color: #ffc107;
            color: black;
        }
        
        .status-overdue {
            background-color: #dc3545;
            color: white;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .financial-summary {
            border-left: 4px solid var(--secondary-color);
            padding-left: 15px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2) { ?>
            <li class="nav-item">
                <a class="nav-link active" href="invoice_report.php">
                    <i class="fas fa-chart-line"></i>
                    <span>Financial Reports</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Invoice & Payment Report</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Report Content -->
        <div class="container-fluid">
            <!-- Financial Summary Cards -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary">$<?php echo number_format($total_invoices, 2); ?></div>
                        <div class="stats-label">Total Invoiced</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success">$<?php echo number_format($total_payments, 2); ?></div>
                        <div class="stats-label">Total Paid</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number <?php echo $outstanding_balance > 0 ? 'text-danger' : 'text-success'; ?>">
                            $<?php echo number_format($outstanding_balance, 2); ?>
                        </div>
                        <div class="stats-label">Outstanding Balance</div>
                    </div>
                </div>
            </div>

            <!-- Detailed Invoice Report -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-file-invoice-dollar me-2"></i>Detailed Invoice Status</span>
                    <span class="badge bg-light text-dark"><?php echo count($invoices_report); ?> records</span>
                </div>
                <div class="card-body">
                    <?php if (count($invoices_report) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Invoice No</th>
                                    <th>PO No</th>
                                    <th>Supplier</th>
                                    <th>Amount</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                    <th>Payment Amount</th>
                                    <th>Payment Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($invoices_report as $report): 
                                    $due_date = new DateTime($report['due_date']);
                                    $today = new DateTime();
                                    $status_class = '';
                                    
                                    if ($report['status'] === 'paid') {
                                        $status_class = 'status-paid';
                                    } else if ($due_date < $today) {
                                        $status_class = 'status-overdue';
                                    } else {
                                        $status_class = 'status-pending';
                                    }
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($report['invoice_no']); ?></td>
                                    <td><?php echo htmlspecialchars($report['po_no']); ?></td>
                                    <td><?php echo htmlspecialchars($report['supplier_name']); ?></td>
                                    <td>$<?php echo number_format($report['invoice_amount'], 2); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($report['due_date'])); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $status_class; ?>">
                                            <?php 
                                            if ($report['status'] === 'paid') {
                                                echo 'Paid';
                                            } else if ($due_date < $today) {
                                                echo 'Overdue';
                                            } else {
                                                echo 'Pending';
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td>$<?php echo number_format($report['payment_amount'] ?? 0, 2); ?></td>
                                    <td><?php echo !empty($report['payment_date']) ? date('M j, Y', strtotime($report['payment_date'])) : 'N/A'; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-file-invoice fa-3x text-muted mb-3"></i>
                        <p class="text-muted">No financial data to display yet.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>