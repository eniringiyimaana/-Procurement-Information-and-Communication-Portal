<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

// Get PO ID from URL
$po_id = isset($_GET['po_id']) ? (int)$_GET['po_id'] : 0;
if ($po_id <= 0) {
    die("Invalid Purchase Order ID.");
}

$conn = connectDB();

// Fetch PO details
// Fetch PO details
$sql_po = "
    SELECT po.id, po.po_no, po.total_amount, po.status, po.created_at,
           r.requisition_no, r.title AS requisition_title,
           s.name AS supplier_name
    FROM purchase_orders po
    LEFT JOIN requisitions r ON po.requisition_id = r.id
    LEFT JOIN suppliers s ON po.supplier_id = s.id
    WHERE po.id = ?
";

$stmt = $conn->prepare($sql_po);
if (!$stmt) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}

$stmt->bind_param("i", $po_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Purchase Order not found.");
}

$po = $result->fetch_assoc();
$stmt->close();

// Fetch PO items
$sql_items = "SELECT * FROM po_items WHERE purchase_order_id = ?";
$stmt_items = $conn->prepare($sql_items);
if (!$stmt_items) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}
$stmt_items->bind_param("i", $po_id);
$stmt_items->execute();
$items_result = $stmt_items->get_result();
$po_items = [];
while ($row = $items_result->fetch_assoc()) {
    $po_items[] = $row;
}
$stmt_items->close();
$conn->close();

// Format dates
$created_date = date('F j, Y', strtotime($po['created_at']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Order <?= htmlspecialchars($po['po_no']) ?> | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @media print {
            body * {
                visibility: hidden;
            }
            .print-section, .print-section * {
                visibility: visible;
            }
            .print-section {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }
            .no-print {
                display: none !important;
            }
            .watermark {
                display: block !important;
            }
        }
        
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .print-container {
            background: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            border-radius: 10px;
            margin: 20px auto;
            max-width: 210mm;
            padding: 30px;
            position: relative;
        }
        
        .po-header {
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .company-logo {
            max-width: 180px;
            margin-bottom: 15px;
        }
        
        .po-title {
            color: #2c3e50;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .po-number {
            color: #6c757d;
            font-size: 1.1rem;
        }
        
        .section-title {
            border-left: 4px solid #2c3e50;
            padding-left: 10px;
            margin: 25px 0 15px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .signature-area {
            margin-top: 50px;
            border-top: 1px dashed #ccc;
            padding-top: 20px;
        }
        
        .signature-line {
            border-top: 1px solid #000;
            width: 70%;
            margin: 40px 0 5px;
        }
        
        .terms-container {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin-top: 20px;
            font-size: 0.9rem;
        }
        
        .watermark {
            position: absolute;
            opacity: 0.05;
            font-size: 8rem;
            font-weight: bold;
            color: #2c3e50;
            transform: rotate(-45deg);
            z-index: -1;
            top: 30%;
            left: 10%;
            white-space: nowrap;
            display: none;
        }
        
        .footer {
            font-size: 0.8rem;
            color: #6c757d;
            text-align: center;
            margin-top: 40px;
        }
        
        .status-badge {
            font-size: 0.9rem;
            padding: 5px 15px;
            border-radius: 20px;
        }
        
        .table th {
            background-color: #2c3e50;
            color: white;
        }
        
        .total-row {
            font-weight: bold;
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <div class="container py-4 no-print">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-primary"><i class="fas fa-file-purchase-order me-2"></i>Purchase Order Details</h2>
            <div>
                <button class="btn btn-outline-secondary me-2" onclick="window.history.back()">
                    <i class="fas fa-arrow-left me-1"></i> Back
                </button>
                <button class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print me-1"></i> Print PO
                </button>
            </div>
        </div>
        
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i> This view is optimized for printing. Click the print button to generate a physical copy.
        </div>
    </div>

    <div class="print-container print-section">
        <!-- Watermark -->
        <div class="watermark">PURCHASE ORDER</div>
        
        <!-- Header Section -->
        <div class="po-header text-center">
            <!-- In a real implementation, you would use your company logo here -->
            <div class="company-logo-placeholder bg-primary text-white d-inline-block p-3 rounded">
                <h4 class="mb-0">YOUR COMPANY</h4>
            </div>
            <h1 class="po-title mt-3">PURCHASE ORDER</h1>
            <p class="po-number">PO No: <?= htmlspecialchars($po['po_no']); ?></p>
            <p class="mb-0">Date: <?= $created_date; ?></p>
        </div>
        
        <!-- Parties Section -->
        <div class="row">
            <div class="col-md-6">
                <h4 class="section-title">From</h4>
                <p>
                    <strong>Your Company Name</strong><br>
                    123 Business Avenue<br>
                    City, State 12345<br>
                    Phone: (123) 456-7890<br>
                    Email: procurement@yourcompany.com
                </p>
                <p><strong>Department:</strong> <?= htmlspecialchars($po['department_name'] ?? 'N/A'); ?></p>
            </div>
            <div class="col-md-6">
                <h4 class="section-title">To</h4>
                <p>
                    <strong><?= htmlspecialchars($po['supplier_name']); ?></strong><br>
                    <?= !empty($po['supplier_address']) ? htmlspecialchars($po['supplier_address']) . '<br>' : ''; ?>
                    Contact: <?= !empty($po['contact_person']) ? htmlspecialchars($po['contact_person']) : 'N/A'; ?><br>
                    Phone: <?= !empty($po['phone']) ? htmlspecialchars($po['phone']) : 'N/A'; ?><br>
                    Email: <?= !empty($po['email']) ? htmlspecialchars($po['email']) : 'N/A'; ?>
                </p>
            </div>
        </div>
        
        <!-- PO Details -->
        <h4 class="section-title">Order Details</h4>
        <div class="table-responsive">
            <table class="table table-bordered">
                <tr>
                    <th width="20%">Requisition Reference</th>
                    <td><?= htmlspecialchars($po['requisition_no'] ?? 'N/A'); ?></td>
                </tr>
                <tr>
                    <th>Requisition Title</th>
                    <td><?= htmlspecialchars($po['requisition_title'] ?? 'N/A'); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <span class="status-badge 
                            <?= $po['status'] == 'approved' ? 'bg-success' : 
                              ($po['status'] == 'pending' ? 'bg-warning text-dark' : 
                              ($po['status'] == 'rejected' ? 'bg-danger' : 'bg-secondary')); ?>">
                            <?= ucfirst($po['status']); ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th>Prepared By</th>
                    <td><?= htmlspecialchars($po['prepared_by'] ?? 'N/A'); ?></td>
                </tr>
            </table>
        </div>
        
        <!-- Items Table -->
        <h4 class="section-title">Items Ordered</h4>
        <?php if (!empty($po_items)) { ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th width="5%">#</th>
                            <th width="45%">Description</th>
                            <th width="15%">Quantity</th>
                            <th width="15%">Unit Price</th>
                            <th width="20%">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $subtotal = 0;
                        foreach ($po_items as $index => $item) { 
                            $item_total = $item['quantity'] * $item['unit_price'];
                            $subtotal += $item_total;
                        ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($item['item_description']) ?></td>
                                <td><?= htmlspecialchars($item['quantity']) ?></td>
                                <td>$<?= number_format($item['unit_price'], 2) ?></td>
                                <td>$<?= number_format($item_total, 2) ?></td>
                            </tr>
                        <?php } ?>
                        <tr class="total-row">
                            <td colspan="4" class="text-end"><strong>Total Amount:</strong></td>
                            <td><strong>$<?= number_format($subtotal, 2) ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php } else { ?>
            <div class="alert alert-warning">
                No items found for this Purchase Order.
            </div>
        <?php } ?>
        
        <!-- Terms and Conditions -->
        <h4 class="section-title">Terms & Conditions</h4>
        <div class="terms-container">
            <ol>
                <li>Goods must be delivered within 30 days of order confirmation unless otherwise specified.</li>
                <li>All goods must meet the quality standards specified in the requisition.</li>
                <li>Payment will be made within 30 days of satisfactory delivery and invoice receipt.</li>
                <li>Any variations to this order must be approved in writing by the purchasing department.</li>
                <li>This order is subject to the terms and conditions of our standard purchase agreement.</li>
            </ol>
        </div>
        
        <!-- Signatures -->
        <div class="row signature-area">
            <div class="col-md-6">
                <p><strong>For The Supplier:</strong></p>
                <div class="signature-line"></div>
                <p>Authorized Signature</p>
                <p>Name: ________________________</p>
                <p>Title: ________________________</p>
                <p>Date: ________________________</p>
            </div>
            <div class="col-md-6">
                <p><strong>For The Company:</strong></p>
                <div class="signature-line"></div>
                <p>Authorized Signature</p>
                <p>Name: ________________________</p>
                <p>Title: ________________________</p>
                <p>Date: ________________________</p>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <p>Purchase Order <?= htmlspecialchars($po['po_no']); ?> | Generated on <?= date('F j, Y'); ?> | <?= $_SESSION["username"]; ?></p>
        </div>
    </div>

    <!-- Print Control Buttons (visible only when printing) -->
    <div class="container mt-3 no-print">
        <div class="d-flex justify-content-center">
            <button class="btn btn-success me-2" onclick="window.print()">
                <i class="fas fa-print me-1"></i> Print Purchase Order
            </button>
            <button class="btn btn-secondary" onclick="window.history.back()">
                <i class="fas fa-arrow-left me-1"></i> Back to Previous Page
            </button>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>