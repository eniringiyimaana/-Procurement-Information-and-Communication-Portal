<?php
// supplier_inbox.php
session_start();
require_once 'users.php'; // For database connection and other shared functions

// Check if the supplier is logged in
if (!isset($_SESSION["supplier_id"])) {
    header("location: supplier_login.php");
    exit;
}

$conn = connectDB();

// Fetch supplier information
$supplier_id = $_SESSION['supplier_id'];
$supplier_name = $_SESSION['supplier_name'];

// Fetch open RFQ invitations for the logged-in supplier with 'sent' status
// This is the updated SQL query to fix the issue
$sql_rfq_invites = "
    SELECT
        r.rfq_no,
        r.title,
        r.due_date,
        ri.status AS invite_status
    FROM rfq_invites ri
    JOIN rfqs r ON ri.rfq_id = r.id
    WHERE ri.supplier_id = ? AND ri.status = 'sent'
";

$stmt_rfq = $conn->prepare($sql_rfq_invites);

// Check if the prepare() statement was successful
if ($stmt_rfq === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt_rfq->bind_param("i", $supplier_id);
$stmt_rfq->execute();
$rfq_result = $stmt_rfq->get_result();
$open_rfq_invitations = $rfq_result->fetch_all(MYSQLI_ASSOC);
$stmt_rfq->close();

// Fetch messages (placeholder for future functionality)
$your_messages = []; // This will be populated with messages from the database later

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Inbox & Dashboard | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .stats-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
        
        .urgent {
            border-left: 4px solid var(--accent-color);
        }
        
        .nav-tabs .nav-link {
            color: var(--primary-color);
            font-weight: 500;
        }
        
        .nav-tabs .nav-link.active {
            color: var(--secondary-color);
            border-bottom: 3px solid var(--secondary-color);
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 text-primary">Supplier Portal</h1>
                <p class="text-muted mb-0">Welcome, <?php echo htmlspecialchars($supplier_name); ?>!</p>
            </div>
            <div>
                <a href="compose_message.php" class="btn btn-primary me-2">
                    <i class="fas fa-plus-circle me-1"></i>New Message
                </a>
                <a href="logout.php" class="btn btn-outline-secondary">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
        
        <!-- Stats Overview -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="dashboard-card stats-card">
                    <div class="stats-number"><?php echo count($open_rfq_invitations); ?></div>
                    <div class="stats-label">Open RFQ Invitations</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-card stats-card">
                    <div class="stats-number">0</div>
                    <div class="stats-label">Unread Messages</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-card stats-card">
                    <div class="stats-number">0</div>
                    <div class="stats-label">Pending Actions</div>
                </div>
            </div>
        </div>
        
        <!-- Content Tabs -->
        <ul class="nav nav-tabs mb-3" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="rfq-tab" data-bs-toggle="tab" data-bs-target="#rfq" type="button" role="tab">
                    <i class="fas fa-file-invoice-dollar me-2"></i>RFQ Invitations
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="messages-tab" data-bs-toggle="tab" data-bs-target="#messages" type="button" role="tab">
                    <i class="fas fa-inbox me-2"></i>Messages
                </button>
            </li>
        </ul>
        
        <div class="tab-content" id="myTabContent">
            <!-- RFQ Invitations Tab -->
            <div class="tab-pane fade show active" id="rfq" role="tabpanel">
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-file-invoice-dollar me-2"></i>Open RFQ Invitations
                    </div>
                    <div class="card-body">
                        <?php if (!empty($open_rfq_invitations)) { ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>RFQ No</th>
                                            <th>Title</th>
                                            <th>Due Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($open_rfq_invitations as $rfq) { 
                                            $due_date = new DateTime($rfq['due_date']);
                                            $today = new DateTime();
                                            $is_urgent = $due_date->diff($today)->days <= 3;
                                        ?>
                                            <tr class="<?php echo $is_urgent ? 'table-warning' : ''; ?>">
                                                <td><?php echo htmlspecialchars($rfq['rfq_no']); ?></td>
                                                <td><?php echo htmlspecialchars($rfq['title']); ?></td>
                                                <td><?php echo htmlspecialchars($rfq['due_date']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $is_urgent ? 'warning' : 'success'; ?>">
                                                        <?php echo $is_urgent ? 'Urgent' : 'Open'; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="view_rfq.php?rfq_no=<?php echo urlencode($rfq['rfq_no']); ?>" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-eye me-1"></i>View RFQ
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php } else { ?>
                            <div class="text-center py-5">
                                <i class="fas fa-file-invoice-dollar fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No open RFQ invitations</h5>
                                <p class="text-muted">You don't have any open RFQ invitations at this time.</p>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            
            <!-- Messages Tab -->
            <div class="tab-pane fade" id="messages" role="tabpanel">
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-inbox me-2"></i>Your Messages
                    </div>
                    <div class="card-body">
                        <?php if (!empty($your_messages)) { ?>
                            <!-- Message content would go here when implemented -->
                        <?php } else { ?>
                            <div class="text-center py-5">
                                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Your inbox is empty</h5>
                                <p class="text-muted">You don't have any messages at this time.</p>
                                <a href="compose_message.php" class="btn btn-primary">
                                    <i class="fas fa-plus-circle me-2"></i>Compose New Message
                                </a>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>