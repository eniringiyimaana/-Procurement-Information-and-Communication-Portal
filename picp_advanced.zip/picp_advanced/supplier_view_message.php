<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["supplier_logged_in"]) || !$_SESSION["supplier_logged_in"] || !isset($_GET['id'])) {
    header("location: supplier_inbox.php");
    exit;
}

$supplier_id = $_SESSION['supplier_id'];
$message_id = $_GET['id'];
$message = null;
$attachment = null;

$conn = connectDB();

try {
    // Mark the message as read
    $sql_update = "UPDATE supplier_inbox SET status = 'read' WHERE id = ? AND recipient_supplier_id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ii", $message_id, $supplier_id);
    $stmt_update->execute();
    $stmt_update->close();

    // Fetch the message details
    $sql_fetch = "SELECT si.*, u.name AS sender_name
                  FROM supplier_inbox si
                  LEFT JOIN users u ON si.sender_user_id = u.id
                  WHERE si.id = ? AND si.recipient_supplier_id = ?";
    $stmt_fetch = $conn->prepare($sql_fetch);
    $stmt_fetch->bind_param("ii", $message_id, $supplier_id);
    $stmt_fetch->execute();
    $result = $stmt_fetch->get_result();

    if ($result && $result->num_rows > 0) {
        $message = $result->fetch_assoc();
    }
    $stmt_fetch->close();
    
    // Fetch attachment details for the message
    $sql_attach = "SELECT file_name, file_path FROM message_attachments WHERE message_id = ?";
    $stmt_attach = $conn->prepare($sql_attach);
    $stmt_attach->bind_param("i", $message_id);
    $stmt_attach->execute();
    $result_attach = $stmt_attach->get_result();
    if ($result_attach && $result_attach->num_rows > 0) {
        $attachment = $result_attach->fetch_assoc();
    }
    $stmt_attach->close();
    
} catch (Exception $e) {
    echo "Error viewing message: " . $e->getMessage();
    exit;
} finally {
    $conn->close();
}

if (!$message) {
    echo "Message not found or you don't have permission to view it.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Message | Supplier Portal</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .message-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        
        .message-header {
            background: var(--primary-color);
            color: white;
            padding: 20px;
            border-radius: 10px 10px 0 0;
        }
        
        .message-body {
            padding: 25px;
            line-height: 1.6;
        }
        
        .message-content {
            background-color: var(--light-bg);
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            white-space: pre-wrap;
        }
        
        .attachment-card {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            background-color: #f8f9fa;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
        
        .back-link {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }
        
        .back-link:hover {
            color: #1a252f;
            text-decoration: underline;
        }
        
        .metadata-item {
            display: flex;
            margin-bottom: 10px;
        }
        
        .metadata-icon {
            width: 20px;
            margin-right: 10px;
            color: var(--secondary-color);
        }
        
        .metadata-content {
            flex: 1;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <!-- Back button -->
                <div class="mb-4">
                    <a href="supplier_inbox.php" class="back-link">
                        <i class="fas fa-arrow-left me-2"></i>Back to Inbox
                    </a>
                </div>
                
                <!-- Message Container -->
                <div class="message-container">
                    <!-- Message Header -->
                    <div class="message-header">
                        <h2 class="mb-2"><?php echo htmlspecialchars($message['subject']); ?></h2>
                        <div class="d-flex flex-wrap text-light">
                            <div class="me-4">
                                <i class="fas fa-user me-1"></i>
                                <strong>From:</strong> <?php echo htmlspecialchars($message['sender_name']); ?>
                            </div>
                            <div>
                                <i class="fas fa-calendar me-1"></i>
                                <strong>Date:</strong> <?php echo htmlspecialchars($message['sent_at']); ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Message Body -->
                    <div class="message-body">
                        <!-- Message Metadata -->
                        <div class="mb-4">
                            <div class="metadata-item">
                                <div class="metadata-icon">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="metadata-content">
                                    <strong>Sender:</strong> <?php echo htmlspecialchars($message['sender_name']); ?>
                                </div>
                            </div>
                            
                            <div class="metadata-item">
                                <div class="metadata-icon">
                                    <i class="fas fa-calendar"></i>
                                </div>
                                <div class="metadata-content">
                                    <strong>Date Received:</strong> <?php echo htmlspecialchars($message['sent_at']); ?>
                                </div>
                            </div>
                            
                            <div class="metadata-item">
                                <div class="metadata-icon">
                                    <i class="fas fa-tag"></i>
                                </div>
                                <div class="metadata-content">
                                    <strong>Status:</strong> 
                                    <span class="badge bg-success">Read</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Message Content -->
                        <h5 class="mb-3">Message:</h5>
                        <div class="message-content">
                            <?php echo nl2br(htmlspecialchars($message['message_body'])); ?>
                        </div>
                        
                        <!-- Attachment -->
                        <?php if ($attachment) { ?>
                        <div class="attachment-card">
                            <h5 class="mb-3"><i class="fas fa-paperclip me-2"></i>Attachment</h5>
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <p class="mb-1"><?php echo htmlspecialchars($attachment['file_name']); ?></p>
                                    <small class="text-muted">Click to download</small>
                                </div>
                                <div>
                                    <a href="<?php echo htmlspecialchars($attachment['file_path']); ?>" download 
                                       class="btn btn-outline-primary">
                                        <i class="fas fa-download me-1"></i>Download
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                        
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2 mt-4">
                            <a href="supplier_compose.php?reply_to=<?php echo htmlspecialchars($message['id']); ?>" 
                               class="btn btn-primary">
                                <i class="fas fa-reply me-1"></i>Reply
                            </a>
                            <a href="supplier_inbox.php" class="btn btn-outline-secondary">
                                <i class="fas fa-inbox me-1"></i>Back to Inbox
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>