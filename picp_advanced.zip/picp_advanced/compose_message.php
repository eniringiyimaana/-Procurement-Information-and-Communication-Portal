<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

$message = '';
$message_type = '';
$users = [];
$suppliers = [];
$conn = connectDB();

// Directory where files will be uploaded
$upload_dir = 'uploads/message_attachments/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Fetch all internal users to populate the recipient dropdown
$sql_users = "SELECT id, name FROM users WHERE id != ?";
$stmt_users = $conn->prepare($sql_users);
$stmt_users->bind_param("i", $_SESSION['user_id']);
$stmt_users->execute();
$result_users = $stmt_users->get_result();
while ($row = $result_users->fetch_assoc()) {
    $users[] = $row;
}
$stmt_users->close();

// Fetch all suppliers to populate the recipient dropdown
$sql_suppliers = "SELECT id, name FROM suppliers";
$result_suppliers = $conn->query($sql_suppliers);
while ($row = $result_suppliers->fetch_assoc()) {
    $suppliers[] = $row;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recipient_info = explode('_', $_POST['recipient']);
    $recipient_type = $recipient_info[0];
    $recipient_id = $recipient_info[1];
    $subject = $_POST['subject'];
    $message_body = $_POST['message_body'];
    $sender_id = $_SESSION['user_id'];
    $sent_at = date('Y-m-d H:i:s');
    
    $conn->begin_transaction();

    try {
        if ($recipient_type == 'user') {
            $sql = "INSERT INTO inbox (sender_id, recipient_id, subject, message_body, sent_at) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Error preparing user message statement: " . $conn->error);
            $stmt->bind_param("iisss", $sender_id, $recipient_id, $subject, $message_body, $sent_at);
            $stmt->execute();
            $message_id = $stmt->insert_id;
            $stmt->close();
        } elseif ($recipient_type == 'supplier') {
            $sql = "INSERT INTO supplier_inbox (sender_user_id, recipient_supplier_id, subject, message_body, sent_at) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Error preparing supplier message statement: " . $conn->error);
            $stmt->bind_param("iisss", $sender_id, $recipient_id, $subject, $message_body, $sent_at);
            $stmt->execute();
            $message_id = $stmt->insert_id;
            $stmt->close();
        } else {
            throw new Exception("Invalid recipient type.");
        }
        
        // Handle file upload
        if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
            $file_name = $_FILES['attachment']['name'];
            $file_tmp_name = $_FILES['attachment']['tmp_name'];
            $new_file_name = uniqid() . '_' . $file_name;
            $file_path = $upload_dir . $new_file_name;

            if (move_uploaded_file($file_tmp_name, $file_path)) {
                $sql_attach = "INSERT INTO message_attachments (message_id, file_name, file_path) VALUES (?, ?, ?)";
                $stmt_attach = $conn->prepare($sql_attach);
                if (!$stmt_attach) throw new Exception("Attachment insert failed: " . $conn->error);
                $stmt_attach->bind_param("iss", $message_id, $file_name, $file_path);
                $stmt_attach->execute();
                $stmt_attach->close();
            } else {
                throw new Exception("Failed to move uploaded file.");
            }
        }

        $conn->commit();
        $message = "Message sent successfully!";
        $message_type = 'success';

    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error sending message: " . $e->getMessage();
        $message_type = 'danger';
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compose Message | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --light-bg: #f8f9fa;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
        
        .breadcrumb {
            background-color: transparent;
            padding: 0;
        }
        
        .file-upload {
            border: 2px dashed #dee2e6;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s;
        }
        
        .file-upload:hover {
            border-color: var(--secondary-color);
            background-color: var(--light-bg);
        }
        
        .recipient-select {
            height: 200px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="compose_message.php">
                    <i class="fas fa-edit"></i>
                    <span>Compose Message</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Compose Message</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php"><i class="fas fa-home me-1"></i>Dashboard</a></li>
                <li class="breadcrumb-item"><a href="inbox.php">Inbox</a></li>
                <li class="breadcrumb-item active" aria-current="page">Compose Message</li>
            </ol>
        </nav>

        <!-- Content -->
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-envelope me-2"></i>New Message
                        </div>
                        <div class="card-body">
                            <?php if ($message): ?>
                                <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                                    <?php echo htmlspecialchars($message); ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>

                            <form action="compose_message.php" method="post" enctype="multipart/form-data">
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="recipient" class="form-label fw-bold">To <span class="text-danger">*</span></label>
                                            <select id="recipient" name="recipient" class="form-select recipient-select" required>
                                                <optgroup label="Internal Staff">
                                                    <?php foreach ($users as $user) { ?>
                                                        <option value="user_<?php echo htmlspecialchars($user['id']); ?>">
                                                            <?php echo htmlspecialchars($user['name']); ?> (Staff)
                                                        </option>
                                                    <?php } ?>
                                                </optgroup>
                                                <optgroup label="Suppliers">
                                                    <?php foreach ($suppliers as $supplier) { ?>
                                                        <option value="supplier_<?php echo htmlspecialchars($supplier['id']); ?>">
                                                            <?php echo htmlspecialchars($supplier['name']); ?> (Supplier)
                                                        </option>
                                                    <?php } ?>
                                                </optgroup>
                                            </select>
                                            <div class="form-text">Select the recipient from staff or suppliers</div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="subject" class="form-label fw-bold">Subject <span class="text-danger">*</span></label>
                                            <input type="text" id="subject" name="subject" class="form-control" placeholder="Enter message subject" required>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label fw-bold">Attachment</label>
                                            <div class="file-upload">
                                                <i class="fas fa-cloud-upload-alt fs-1 text-muted mb-2"></i>
                                                <p class="text-muted mb-2">Drag & drop your file here or click to browse</p>
                                                <input type="file" id="attachment" name="attachment" class="form-control">
                                                <div class="form-text">Max file size: 10MB</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <label for="message_body" class="form-label fw-bold">Message <span class="text-danger">*</span></label>
                                    <textarea id="message_body" name="message_body" class="form-control" rows="8" placeholder="Type your message here..." required></textarea>
                                </div>

                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <a href="inbox.php" class="btn btn-secondary me-md-2">
                                        <i class="fas fa-times me-1"></i> Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-paper-plane me-1"></i> Send Message
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Quick Tips Card -->
                    <div class="dashboard-card mt-4">
                        <div class="card-header">
                            <i class="fas fa-lightbulb me-2"></i>Message Tips
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Best Practices</h6>
                                    <ul class="mb-0">
                                        <li>Use clear and concise subject lines</li>
                                        <li>Be specific about your requirements</li>
                                        <li>Include relevant reference numbers</li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h6>Attachment Guidelines</h6>
                                    <ul class="mb-0">
                                        <li>Supported formats: PDF, DOC, DOCX, XLS, XLSX</li>
                                        <li>Maximum file size: 10MB per attachment</li>
                                        <li>Use descriptive file names</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        // Enhance file input with better UX
        document.getElementById('attachment').addEventListener('change', function(e) {
            const fileName = e.target.files[0]?.name;
            if (fileName) {
                document.querySelector('.file-upload p').textContent = 'Selected file: ' + fileName;
            }
        });

        // Drag and drop functionality
        const fileUpload = document.querySelector('.file-upload');
        const fileInput = document.getElementById('attachment');

        fileUpload.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.style.borderColor = '#3498db';
            this.style.backgroundColor = '#f8f9fa';
        });

        fileUpload.addEventListener('dragleave', function(e) {
            e.preventDefault();
            this.style.borderColor = '#dee2e6';
            this.style.backgroundColor = 'transparent';
        });

        fileUpload.addEventListener('drop', function(e) {
            e.preventDefault();
            this.style.borderColor = '#dee2e6';
            this.style.backgroundColor = 'transparent';
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                document.querySelector('.file-upload p').textContent = 'Selected file: ' + e.dataTransfer.files[0].name;
            }
        });

        // Click on file upload area to trigger file input
        fileUpload.addEventListener('click', function() {
            fileInput.click();
        });
    </script>
</body>
</html>