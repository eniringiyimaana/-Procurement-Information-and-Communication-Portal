<?php
session_start();
require_once 'users.php'; // Reuse the database connection

// Check if the user is logged in and has the right role (e.g., Admin)
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    header("location: index.php");
    exit;
}

$message = '';
$conn = connectDB();

// Handle form submission to add a new item
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'add') {
    $item_description = $_POST['item_description'];
    $spend_category_id = $_POST['spend_category_id'];
    $unit_of_measure = $_POST['unit_of_measure'];
    $current_stock = $_POST['current_stock'];

    $sql = "INSERT INTO items (item_description, spend_category_id, unit_of_measure, current_stock) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sisi", $item_description, $spend_category_id, $unit_of_measure, $current_stock);

    if ($stmt->execute()) {
        $message = "Item added successfully!";
    } else {
        $message = "Error adding item: " . $stmt->error;
    }
    $stmt->close();
}

// Handle deletion of an item
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $item_id = $_GET['id'];
    $sql = "DELETE FROM items WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $item_id);
    if ($stmt->execute()) {
        $message = "Item deleted successfully!";
    } else {
        $message = "Error deleting item: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch spend categories to populate the dropdown
$spend_categories = [];
$sql_categories = "SELECT id, name FROM spend_categories ORDER BY name ASC";
$categories_result = $conn->query($sql_categories);
if ($categories_result) {
    while ($row = $categories_result->fetch_assoc()) {
        $spend_categories[] = $row;
    }
}

// Fetch all items from the database
$items = [];
$sql = "SELECT i.*, sc.name as category_name
        FROM items i
        JOIN spend_categories sc ON i.spend_category_id = sc.id
        ORDER BY i.created_at DESC";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
}
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Inventory Items | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .stock-indicator {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .stock-low {
            background-color: #dc3545;
            color: white;
        }
        
        .stock-medium {
            background-color: #ffc107;
            color: black;
        }
        
        .stock-high {
            background-color: #28a745;
            color: white;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .action-btn {
            padding: 5px 10px;
            border-radius: 4px;
            transition: all 0.2s;
        }
        
        .action-btn:hover {
            background-color: #f8f9fa;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_departments.php">
                    <i class="fas fa-building"></i>
                    <span>Manage Departments</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="manage_items.php">
                    <i class="fas fa-boxes"></i>
                    <span>Manage Inventory</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_budgets.php">
                    <i class="fas fa-wallet"></i>
                    <span>Manage Budgets</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Inventory Items</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Inventory Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Inventory Statistics -->
            <?php
            $total_items = count($items);
            $low_stock_count = 0;
            $categories_count = count($spend_categories);
            
            foreach ($items as $item) {
                if ($item['current_stock'] < 10) {
                    $low_stock_count++;
                }
            }
            ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary"><?php echo $total_items; ?></div>
                        <div class="stats-label">Total Items</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success"><?php echo $categories_count; ?></div>
                        <div class="stats-label">Categories</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-warning"><?php echo $low_stock_count; ?></div>
                        <div class="stats-label">Low Stock Items</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-info">
                            <i class="fas fa-boxes"></i>
                        </div>
                        <div class="stats-label">Inventory Management</div>
                    </div>
                </div>
            </div>

            <!-- Add New Item Form -->
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-plus-circle me-2"></i>Add New Inventory Item
                </div>
                <div class="card-body">
                    <form action="manage_items.php" method="post">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="item_description" class="form-label">Item Description</label>
                                <input type="text" class="form-control" id="item_description" name="item_description" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="spend_category_id" class="form-label">Spend Category</label>
                                <select class="form-select" id="spend_category_id" name="spend_category_id" required>
                                    <option value="">--Select Category--</option>
                                    <?php foreach ($spend_categories as $category): ?>
                                        <option value="<?php echo htmlspecialchars($category['id']); ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label for="unit_of_measure" class="form-label">Unit of Measure</label>
                                <input type="text" class="form-control" id="unit_of_measure" name="unit_of_measure" required>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label for="current_stock" class="form-label">Current Stock</label>
                                <input type="number" class="form-control" id="current_stock" name="current_stock" value="0" min="0" required>
                            </div>
                            <div class="col-md-1 mb-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-plus me-1"></i> Add
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Existing Items -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-boxes me-2"></i>Inventory Items</span>
                    <span class="badge bg-light text-dark"><?php echo $total_items; ?> items</span>
                </div>
                <div class="card-body">
                    <p class="text-muted">Use this page to add and manage items in your inventory.</p>
                    
                    <?php if (count($items) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Item Description</th>
                                    <th>Category</th>
                                    <th>Unit of Measure</th>
                                    <th>Current Stock</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): 
                                    $stock_class = '';
                                    if ($item['current_stock'] < 10) {
                                        $stock_class = 'stock-low';
                                    } elseif ($item['current_stock'] < 50) {
                                        $stock_class = 'stock-medium';
                                    } else {
                                        $stock_class = 'stock-high';
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <i class="fas fa-box text-muted me-2"></i>
                                        <?php echo htmlspecialchars($item['item_description']); ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($item['category_name']); ?></td>
                                    <td><?php echo htmlspecialchars($item['unit_of_measure']); ?></td>
                                    <td>
                                        <span class="stock-indicator <?php echo $stock_class; ?>">
                                            <?php echo htmlspecialchars($item['current_stock']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($item['created_at'])); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="edit_item.php?id=<?php echo htmlspecialchars($item['id']); ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit me-1"></i> Edit
                                            </a>
                                            <a href="manage_items.php?action=delete&id=<?php echo htmlspecialchars($item['id']); ?>" 
                                               class="btn btn-sm btn-outline-danger" 
                                               onclick="return confirm('Are you sure you want to delete this item?');">
                                                <i class="fas fa-trash me-1"></i> Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-boxes fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No Inventory Items</h4>
                        <p class="text-muted">No items found. Add one using the form above.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>