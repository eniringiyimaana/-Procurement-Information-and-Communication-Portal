<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: dashboard.php");
    exit;
}

$conn = connectDB();
$message = '';

// Fetch all contracts
$sql = "
    SELECT c.id, c.contract_no, c.contract_file, c.award_date, c.total_value, c.status,
           r.rfq_no, r.title AS rfq_title,
           s.name AS supplier_name
    FROM contracts c
    JOIN rfqs r ON c.rfq_id = r.id
    JOIN suppliers s ON c.supplier_id = s.id
    ORDER BY c.award_date DESC
";
$result = $conn->query($sql);

// Fetch signed contracts
$sql_signed = "
    SELECT c.id, c.contract_no, c.contract_file, c.award_date, c.total_value, c.status,
           r.rfq_no, r.title AS rfq_title,
           s.name AS supplier_name
    FROM contracts c
    JOIN rfqs r ON c.rfq_id = r.id
    JOIN suppliers s ON c.supplier_id = s.id
    WHERE c.contract_file IS NOT NULL
    ORDER BY c.award_date DESC
";
$result_signed = $conn->query($sql_signed);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contracts | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
        }
        
        .status-active {
            background-color: #28a745;
            color: white;
        }
        
        .status-draft {
            background-color: #6c757d;
            color: white;
        }
        
        .status-expired {
            background-color: #dc3545;
            color: white;
        }
        
        .status-pending {
            background-color: #ffc107;
            color: black;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .contract-value {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .nav-tabs .nav-link {
            color: #495057;
            font-weight: 500;
        }
        
        .nav-tabs .nav-link.active {
            color: var(--primary-color);
            font-weight: 600;
            border-bottom: 3px solid var(--primary-color);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2) { ?>
            <li class="nav-item">
                <a class="nav-link active" href="manage_contracts.php">
                    <i class="fas fa-file-contract"></i>
                    <span>Manage Contracts</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Contracts</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Contracts Content -->
        <div class="container-fluid">
            <!-- Tabs Navigation -->
            <ul class="nav nav-tabs mb-4" id="contractsTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="all-contracts-tab" data-bs-toggle="tab" data-bs-target="#all-contracts" type="button" role="tab" aria-controls="all-contracts" aria-selected="true">
                        All Contracts
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="signed-contracts-tab" data-bs-toggle="tab" data-bs-target="#signed-contracts" type="button" role="tab" aria-controls="signed-contracts" aria-selected="false">
                        Signed Contracts
                    </button>
                </li>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content" id="contractsTabContent">
                <!-- All Contracts Tab -->
                <div class="tab-pane fade show active" id="all-contracts" role="tabpanel" aria-labelledby="all-contracts-tab">
                    <div class="dashboard-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-file-contract me-2"></i>All Contracts</span>
                            <span class="badge bg-light text-dark">
                                <?php echo ($result && $result->num_rows > 0) ? $result->num_rows : '0'; ?> contracts
                            </span>
                        </div>
                        <div class="card-body">
                            <?php if ($result && $result->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Contract No</th>
                                            <th>RFQ Title</th>
                                            <th>Supplier</th>
                                            <th>Total Value</th>
                                            <th>Award Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $result->fetch_assoc()): 
                                            $status_class = 'status-' . $row['status'];
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['contract_no']); ?></td>
                                            <td><?php echo htmlspecialchars($row['rfq_title']); ?></td>
                                            <td><?php echo htmlspecialchars($row['supplier_name']); ?></td>
                                            <td class="contract-value">$<?php echo number_format($row['total_value'], 2); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($row['award_date'])); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $status_class; ?>">
                                                    <?php echo htmlspecialchars(ucfirst($row['status'])); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($row['contract_file']): ?>
                                                    <a href="<?php echo htmlspecialchars($row['contract_file']); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                                        <i class="fas fa-eye me-1"></i> View
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-file-contract fa-3x text-muted mb-3"></i>
                                <h4 class="text-muted">No Contracts Found</h4>
                                <p class="text-muted">No contracts have been created yet.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Signed Contracts Tab -->
                <div class="tab-pane fade" id="signed-contracts" role="tabpanel" aria-labelledby="signed-contracts-tab">
                    <div class="dashboard-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-file-signature me-2"></i>Signed Contracts</span>
                            <span class="badge bg-light text-dark">
                                <?php echo ($result_signed && $result_signed->num_rows > 0) ? $result_signed->num_rows : '0'; ?> signed contracts
                            </span>
                        </div>
                        <div class="card-body">
                            <?php if ($result_signed && $result_signed->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Contract No</th>
                                            <th>RFQ Title</th>
                                            <th>Supplier</th>
                                            <th>Total Value</th>
                                            <th>Award Date</th>
                                            <th>Status</th>
                                            <th>Signed Contract</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $result_signed->fetch_assoc()): 
                                            $status_class = 'status-' . $row['status'];
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['contract_no']); ?></td>
                                            <td><?php echo htmlspecialchars($row['rfq_title']); ?></td>
                                            <td><?php echo htmlspecialchars($row['supplier_name']); ?></td>
                                            <td class="contract-value">$<?php echo number_format($row['total_value'], 2); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($row['award_date'])); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $status_class; ?>">
                                                    <?php echo htmlspecialchars(ucfirst($row['status'])); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="<?php echo htmlspecialchars($row['contract_file']); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-download me-1"></i> Download
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-file-signature fa-3x text-muted mb-3"></i>
                                <h4 class="text-muted">No Signed Contracts</h4>
                                <p class="text-muted">No signed contracts have been uploaded yet.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>