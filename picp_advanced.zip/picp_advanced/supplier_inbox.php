<?php
session_start();
require_once 'users.php';

// Check if a supplier is logged in via a token
if (!isset($_SESSION["supplier_logged_in"]) || !$_SESSION["supplier_logged_in"]) {
    header("location: supplier_login.php");
    exit;
}

$supplier_id = $_SESSION['supplier_id'];
$inbox_messages = [];
$rfq_invites = [];

$conn = connectDB();

// Fetch all messages where the logged-in supplier is the recipient
$sql_messages = "SELECT si.*, u.name AS sender_name
                 FROM supplier_inbox si
                 LEFT JOIN users u ON si.sender_user_id = u.id
                 WHERE si.recipient_supplier_id = ?
                 ORDER BY si.sent_at DESC";
$stmt_messages = $conn->prepare($sql_messages);
$stmt_messages->bind_param("i", $supplier_id);
$stmt_messages->execute();
$result_messages = $stmt_messages->get_result();
while ($row = $result_messages->fetch_assoc()) {
    $inbox_messages[] = $row;
}
$stmt_messages->close();

// Fetch all RFQ invites for the logged-in supplier
$sql_invites = "SELECT r.id, r.rfq_no, r.title, r.due_date, r.status
                FROM rfq_invites ri
                JOIN rfqs r ON ri.rfq_id = r.id
                WHERE ri.supplier_id = ? AND ri.status = 'sent' AND r.status = 'open'
                ORDER BY r.due_date ASC";
$stmt_invites = $conn->prepare($sql_invites);
$stmt_invites->bind_param("i", $supplier_id);
$stmt_invites->execute();
$result_invites = $stmt_invites->get_result();
while ($row = $result_invites->fetch_assoc()) {
    $rfq_invites[] = $row;
}
$stmt_invites->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Inbox | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .nav-tabs .nav-link {
            color: var(--primary-color);
            font-weight: 500;
            padding: 12px 20px;
            border: none;
            border-bottom: 3px solid transparent;
        }
        
        .nav-tabs .nav-link.active {
            color: var(--secondary-color);
            background: transparent;
            border-bottom: 3px solid var(--secondary-color);
        }
        
        .nav-tabs .nav-link:hover {
            border-color: transparent;
            color: var(--secondary-color);
        }
        
        .message-item {
            border-left: 4px solid transparent;
            transition: all 0.3s;
        }
        
        .message-item:hover {
            background-color: #f8f9fa;
            border-left-color: var(--secondary-color);
        }
        
        .message-item.unread {
            background-color: rgba(52, 152, 219, 0.05);
            font-weight: 500;
        }
        
        .message-item.unread .message-subject {
            color: var(--primary-color);
        }
        
        .badge-unread {
            background-color: var(--secondary-color);
        }
        
        .rfq-item {
            border-left: 4px solid var(--primary-color);
            transition: all 0.3s;
        }
        
        .rfq-item.urgent {
            border-left-color: var(--accent-color);
        }
        
        .rfq-item:hover {
            transform: translateX(5px);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
        
        .status-badge {
            font-size: 0.75rem;
            padding: 0.35em 0.65em;
        }
        
        .message-preview {
            color: #6c757d;
            font-size: 0.9rem;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="h3 text-primary mb-0">Supplier Portal</h1>
                        <p class="text-muted">Welcome, <?php echo htmlspecialchars($_SESSION['supplier_name']); ?>!</p>
                    </div>
                    <div>
                        <a href="supplier_compose.php" class="btn btn-primary">
                            <i class="fas fa-plus-circle me-2"></i>New Message
                        </a>
                        <a href="supplier_logout.php" class="btn btn-outline-secondary">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </div>
                </div>
                
                <!-- Stats Overview -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="dashboard-card text-center p-3">
                            <div class="text-primary mb-2">
                                <i class="fas fa-envelope-open-text fa-2x"></i>
                            </div>
                            <h3 class="mb-0"><?php echo count($inbox_messages); ?></h3>
                            <p class="text-muted mb-0">Total Messages</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-card text-center p-3">
                            <div class="text-primary mb-2">
                                <i class="fas fa-file-invoice-dollar fa-2x"></i>
                            </div>
                            <h3 class="mb-0"><?php echo count($rfq_invites); ?></h3>
                            <p class="text-muted mb-0">Open RFQs</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-card text-center p-3">
                            <div class="text-primary mb-2">
                                <i class="fas fa-calendar-check fa-2x"></i>
                            </div>
                            <h3 class="mb-0"><?php 
                                $urgent_rfqs = 0;
                                foreach ($rfq_invites as $rfq) {
                                    $due_date = new DateTime($rfq['due_date']);
                                    $today = new DateTime();
                                    if ($due_date->diff($today)->days <= 3) {
                                        $urgent_rfqs++;
                                    }
                                }
                                echo $urgent_rfqs;
                            ?></h3>
                            <p class="text-muted mb-0">Urgent RFQs</p>
                        </div>
                    </div>
                </div>
                
                <!-- Content Tabs -->
                <ul class="nav nav-tabs mb-4" id="inboxTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="rfq-tab" data-bs-toggle="tab" data-bs-target="#rfq" type="button" role="tab">
                            <i class="fas fa-file-invoice-dollar me-2"></i>RFQ Invitations
                            <?php if (count($rfq_invites) > 0): ?>
                            <span class="badge bg-primary rounded-pill ms-1"><?php echo count($rfq_invites); ?></span>
                            <?php endif; ?>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="messages-tab" data-bs-toggle="tab" data-bs-target="#messages" type="button" role="tab">
                            <i class="fas fa-inbox me-2"></i>Messages
                            <?php 
                            $unread_count = 0;
                            foreach ($inbox_messages as $msg) {
                                if ($msg['status'] === 'unread') {
                                    $unread_count++;
                                }
                            }
                            if ($unread_count > 0): ?>
                            <span class="badge badge-unread rounded-pill ms-1"><?php echo $unread_count; ?></span>
                            <?php endif; ?>
                        </button>
                    </li>
                </ul>
                
                <div class="tab-content" id="inboxTabContent">
                    <!-- RFQ Invitations Tab -->
                    <div class="tab-pane fade show active" id="rfq" role="tabpanel">
                        <div class="dashboard-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span><i class="fas fa-file-invoice-dollar me-2"></i>Open RFQ Invitations</span>
                                <span class="badge bg-primary"><?php echo count($rfq_invites); ?> Open</span>
                            </div>
                            <div class="card-body p-0">
                                <?php if (count($rfq_invites) > 0) { ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($rfq_invites as $rfq) { 
                                            $due_date = new DateTime($rfq['due_date']);
                                            $today = new DateTime();
                                            $days_remaining = $due_date->diff($today)->days;
                                            $is_urgent = $days_remaining <= 3;
                                        ?>
                                            <div class="list-group-item rfq-item <?php echo $is_urgent ? 'urgent' : ''; ?>">
                                                <div class="d-flex justify-content-between align-items-start">
                                                    <div class="flex-grow-1">
                                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                                            <h5 class="mb-0"><?php echo htmlspecialchars($rfq['title']); ?></h5>
                                                            <span class="badge <?php echo $is_urgent ? 'bg-danger' : 'bg-secondary'; ?> status-badge">
                                                                <?php echo $is_urgent ? 'Urgent' : $days_remaining . ' days left'; ?>
                                                            </span>
                                                        </div>
                                                        <p class="text-muted mb-1">RFQ #: <?php echo htmlspecialchars($rfq['rfq_no']); ?></p>
                                                        <p class="text-muted mb-2">Due: <?php echo htmlspecialchars($rfq['due_date']); ?></p>
                                                    </div>
                                                    <div class="ms-3">
                                                        <a href="supplier_compose.php?rfq_no=<?php echo urlencode($rfq['rfq_no']); ?>" 
                                                           class="btn btn-sm btn-primary">
                                                            <i class="fas fa-paper-plane me-1"></i>Submit Proposal
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                <?php } else { ?>
                                    <div class="text-center py-5">
                                        <i class="fas fa-file-invoice-dollar fa-3x text-muted mb-3"></i>
                                        <h5 class="text-muted">No open RFQ invitations</h5>
                                        <p class="text-muted">You don't have any open RFQ invitations at this time.</p>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Messages Tab -->
                    <div class="tab-pane fade" id="messages" role="tabpanel">
                        <div class="dashboard-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span><i class="fas fa-inbox me-2"></i>Your Messages</span>
                                <?php if ($unread_count > 0): ?>
                                <span class="badge badge-unread"><?php echo $unread_count; ?> Unread</span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body p-0">
                                <?php if (count($inbox_messages) > 0) { ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($inbox_messages as $msg) { 
                                            $is_unread = $msg['status'] === 'unread';
                                            $message_preview = strip_tags($msg['message_body']);
                                            if (strlen($message_preview) > 120) {
                                                $message_preview = substr($message_preview, 0, 120) . '...';
                                            }
                                        ?>
                                            <a href="supplier_view_message.php?id=<?php echo htmlspecialchars($msg['id']); ?>" 
                                               class="list-group-item list-group-item-action message-item <?php echo $is_unread ? 'unread' : ''; ?>">
                                                <div class="d-flex justify-content-between align-items-start">
                                                    <div class="flex-grow-1">
                                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                                            <h6 class="mb-0 message-subject"><?php echo htmlspecialchars($msg['subject']); ?></h6>
                                                            <small class="text-muted"><?php echo htmlspecialchars($msg['sent_at']); ?></small>
                                                        </div>
                                                        <p class="mb-1 text-muted">From: <?php echo htmlspecialchars($msg['sender_name']); ?></p>
                                                        <p class="mb-0 message-preview"><?php echo htmlspecialchars($message_preview); ?></p>
                                                    </div>
                                                    <?php if ($is_unread): ?>
                                                    <span class="badge badge-unread ms-2">New</span>
                                                    <?php endif; ?>
                                                </div>
                                            </a>
                                        <?php } ?>
                                    </div>
                                <?php } else { ?>
                                    <div class="text-center py-5">
                                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                        <h5 class="text-muted">Your inbox is empty</h5>
                                        <p class="text-muted">You don't have any messages at this time.</p>
                                        <a href="supplier_compose.php" class="btn btn-primary">
                                            <i class="fas fa-plus-circle me-2"></i>Compose New Message
                                        </a>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        // Activate the first tab by default
        const firstTab = new bootstrap.Tab(document.getElementById('rfq-tab'));
        firstTab.show();
        
        // Switch to messages tab if there are unread messages
        <?php if ($unread_count > 0): ?>
        document.addEventListener('DOMContentLoaded', function() {
            // Show a subtle notification about unread messages
            const messagesTab = document.getElementById('messages-tab');
            messagesTab.classList.add('pulse-notification');
            
            setTimeout(function() {
                messagesTab.classList.remove('pulse-notification');
            }, 3000);
        });
        <?php endif; ?>
    </script>
</body>
</html>