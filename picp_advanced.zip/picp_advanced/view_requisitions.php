<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and has the right role
if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: index.php");
    exit;
}

$message = '';
$requisitions = [];

// Fetch all requisitions with user and department names
$conn = connectDB();
$sql = "SELECT r.*, u.name as user_name, d.name as department_name
        FROM requisitions r
        JOIN users u ON r.requested_by = u.id
        JOIN departments d ON r.department_id = d.id
        ORDER BY r.created_at DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $requisitions[] = $row;
    }
}
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View All Requisitions | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .status-pending_approval {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-submitted {
            background-color: #cce5ff;
            color: #004085;
        }
        
        .status-approved {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-rejected {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .status-draft {
            background-color: #e2e3e5;
            color: #383d41;
        }
        
        .action-buttons .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="view_requisitions.php">
                    <i class="fas fa-clipboard-list"></i>
                    <span>All Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">All Requisitions</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Dashboard Content -->
        <div class="container-fluid">
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-clipboard-list me-2"></i>All Procurement Requisitions
                </div>
                <div class="card-body">
                    <p class="text-muted">This page lists all procurement requisitions in the system. Use the actions below to manage them.</p>
                    
                    <?php if (count($requisitions) > 0) { ?>
                        <div class="table-responsive">
                            <table id="requisitionsTable" class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Req No</th>
                                        <th>Title</th>
                                        <th>Requested By</th>
                                        <th>Department</th>
                                        <th>Total Amount</th>
                                        <th>Status</th>
                                        <th>Submitted On</th>
                                        <th class="text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($requisitions as $requisition) { 
                                        // Determine status class
                                        $statusClass = 'status-' . strtolower($requisition['status']);
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($requisition['requisition_no']); ?></td>
                                            <td><?php echo htmlspecialchars($requisition['title']); ?></td>
                                            <td><?php echo htmlspecialchars($requisition['user_name']); ?></td>
                                            <td><?php echo htmlspecialchars($requisition['department_name']); ?></td>
                                            <td>$<?php echo number_format($requisition['total_amount'], 2); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $statusClass; ?>">
                                                    <?php echo ucfirst(str_replace('_', ' ', $requisition['status'])); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M j, Y', strtotime($requisition['created_at'])); ?></td>
                                            <td class="text-center action-buttons">
                                                <a href="view_requisition.php?id=<?php echo htmlspecialchars($requisition['id']); ?>" class="btn btn-sm btn-info" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                
                                                <?php if ($requisition['status'] == 'submitted' || $requisition['status'] == 'pending_approval') { ?>
                                                    <a href="manage_approvals.php?id=<?php echo htmlspecialchars($requisition['id']); ?>" class="btn btn-sm btn-warning" title="Review & Approve">
                                                        <i class="fas fa-check-circle"></i>
                                                    </a>
                                                <?php } elseif ($requisition['status'] == 'approved') { ?>
                                                    <a href="create_po.php?requisition_id=<?php echo htmlspecialchars($requisition['id']); ?>" class="btn btn-sm btn-success" title="Create Purchase Order">
                                                        <i class="fas fa-file-invoice"></i>
                                                    </a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    <?php } else { ?>
                        <div class="text-center py-5">
                            <i class="fas fa-clipboard-list fa-4x text-muted mb-3"></i>
                            <h4 class="text-muted">No Requisitions Found</h4>
                            <p class="text-muted">No requisitions have been submitted yet.</p>
                        </div>
                    <?php } ?>
                </div>
            </div>
            
            <div class="mt-3">
                <a href="dashboard.php" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <!-- jQuery and DataTables -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function() {
            $('#requisitionsTable').DataTable({
                pageLength: 10,
                responsive: true,
                ordering: true,
                searching: true,
                language: {
                    search: "Search requisitions:",
                    lengthMenu: "Show _MENU_ requisitions per page",
                    info: "Showing _START_ to _END_ of _TOTAL_ requisitions",
                    infoEmpty: "No requisitions available",
                    infoFiltered: "(filtered from _MAX_ total requisitions)",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                },
                columnDefs: [
                    { orderable: false, targets: [7] } // Disable sorting on Actions column
                ]
            });
        });
    </script>
</body>
</html>