<?php
session_start();
require_once 'users.php'; // For database connection

// Check if the user is a Procurement Officer AND the proposal ID is set
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 2 || !isset($_GET['proposal_id'])) {
    header("location: index.php");
    exit;
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$proposal_id = $_GET['proposal_id'];
$conn = connectDB();
$message = '';
$error = '';
$proposal_data = null;
$rfq_data = null;
$supplier_data = null;

// Fetch proposal details for display
try {
    $sql_get_proposal_data = "
        SELECT sp.*, r.rfq_no, r.title as rfq_title, r.id as rfq_id,
               s.name as supplier_name, s.contact_person, s.contact_email, s.contact_phone,
               req.title as requisition_title
        FROM supplier_proposals sp
        JOIN rfqs r ON sp.rfq_id = r.id
        JOIN suppliers s ON sp.supplier_id = s.id
        JOIN requisitions req ON r.requisition_id = req.id
        WHERE sp.id = ?
    ";
    $stmt_get_proposal_data = $conn->prepare($sql_get_proposal_data);
    if (!$stmt_get_proposal_data) {
        throw new Exception("Error preparing statement to get proposal data: " . $conn->error);
    }
    $stmt_get_proposal_data->bind_param("i", $proposal_id);
    $stmt_get_proposal_data->execute();
    $result_proposal_data = $stmt_get_proposal_data->get_result();
    $proposal_data = $result_proposal_data->fetch_assoc();
    $stmt_get_proposal_data->close();
    
    if (!$proposal_data) {
        throw new Exception("Proposal with ID " . htmlspecialchars($proposal_id) . " not found.");
    }
} catch (Exception $e) {
    $error = $e->getMessage();
}

// Handle form submission to generate contract
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid CSRF token. Please try again.";
    } else {
        $conn->begin_transaction();

        try {
            $rfq_id = $proposal_data['rfq_id'];
            $proposal_amount = $proposal_data['amount'];
            
            // 2. Get the RFQ's associated requisition ID and the user's department ID
            $user_id = $_SESSION['user_id'];
            $current_year = date('Y');

            $sql_get_requisition = "SELECT r.requisition_id, u.department_id FROM rfqs r JOIN users u ON r.created_by = u.id WHERE r.id = ?";
            $stmt_get_requisition = $conn->prepare($sql_get_requisition);
            if (!$stmt_get_requisition) {
                throw new Exception("Error preparing statement to get requisition data: " . $conn->error);
            }
            $stmt_get_requisition->bind_param("i", $rfq_id);
            $stmt_get_requisition->execute();
            $result_requisition = $stmt_get_requisition->get_result();
            $requisition_data = $result_requisition->fetch_assoc();
            $stmt_get_requisition->close();

            if (!$requisition_data) {
                throw new Exception("Associated requisition not found for this RFQ.");
            }
            $requisition_id = $requisition_data['requisition_id'];
            $department_id = $requisition_data['department_id'];

            // 3. Get the original committed amount from the requisition
            $sql_get_committed = "SELECT total_estimated_cost FROM requisitions WHERE id = ?";
            $stmt_get_committed = $conn->prepare($sql_get_committed);
            if (!$stmt_get_committed) {
                throw new Exception("Error preparing statement to get committed cost: " . $conn->error);
            }
            $stmt_get_committed->bind_param("i", $requisition_id);
            $stmt_get_committed->execute();
            $result_committed = $stmt_get_committed->get_result();
            $committed_amount = $result_committed->fetch_assoc()['total_estimated_cost'];
            $stmt_get_committed->close();

            // 4. Update the budget by moving funds from committed to spent
            $sql_update_budget = "UPDATE budgets SET committed_amount = committed_amount - ?, spent_amount = spent_amount + ? WHERE department_id = ? AND fiscal_year = ?";
            $stmt_update_budget = $conn->prepare($sql_update_budget);
            if (!$stmt_update_budget) {
                throw new Exception("Error preparing statement to update budget: " . $conn->error);
            }
            $stmt_update_budget->bind_param("ddis", $committed_amount, $proposal_amount, $department_id, $current_year);
            if (!$stmt_update_budget->execute()) {
                throw new Exception("Failed to update budget: " . $stmt_update_budget->error);
            }
            $stmt_update_budget->close();

            // 5. Mark the selected proposal as 'accepted'
            $sql_accept = "UPDATE supplier_proposals SET status = 'accepted' WHERE id = ?";
            $stmt_accept = $conn->prepare($sql_accept);
            if (!$stmt_accept) {
                throw new Exception("Error preparing statement to accept proposal: " . $conn->error);
            }
            $stmt_accept->bind_param("i", $proposal_id);
            if (!$stmt_accept->execute()) {
                throw new Exception("Failed to accept proposal: " . $stmt_accept->error);
            }
            $stmt_accept->close();

            // 6. Reject all other proposals for the same RFQ
            $sql_reject = "UPDATE supplier_proposals SET status = 'rejected' WHERE rfq_id = ? AND id != ?";
            $stmt_reject = $conn->prepare($sql_reject);
            if (!$stmt_reject) {
                throw new Exception("Error preparing statement to reject other proposals: " . $conn->error);
            }
            $stmt_reject->bind_param("ii", $rfq_id, $proposal_id);
            if (!$stmt_reject->execute()) {
                throw new Exception("Failed to reject other proposals: " . $stmt_reject->error);
            }
            $stmt_reject->close();

            // 7. Update the RFQ status to 'awarded'
            $sql_update_rfq = "UPDATE rfqs SET status = 'awarded' WHERE id = ?";
            $stmt_update_rfq = $conn->prepare($sql_update_rfq);
            if (!$stmt_update_rfq) {
                throw new Exception("Error preparing statement to update RFQ status: " . $conn->error);
            }
            $stmt_update_rfq->bind_param("i", $rfq_id);
            if (!$stmt_update_rfq->execute()) {
                throw new Exception("Failed to update RFQ status: " . $stmt_update_rfq->error);
            }
            $stmt_update_rfq->close();

            // 8. Create a new entry in the 'contracts' table
            $contract_no = 'CON-' . date('Ymd') . '-' . substr(md5(uniqid(rand(), true)), 0, 8);
            $award_date = date("Y-m-d");
            
            $sql_create_contract = "INSERT INTO contracts (contract_no, rfq_id, proposal_id, award_date, total_value, status) VALUES (?, ?, ?, ?, ?, 'active')";
            $stmt_create_contract = $conn->prepare($sql_create_contract);
            if (!$stmt_create_contract) {
                throw new Exception("Error preparing statement to create contract: " . $conn->error);
            }
            $stmt_create_contract->bind_param("siisd", $contract_no, $rfq_id, $proposal_id, $award_date, $proposal_amount);
            if (!$stmt_create_contract->execute()) {
                throw new Exception("Failed to create contract: " . $stmt_create_contract->error);
            }
            $contract_id = $stmt_create_contract->insert_id;
            $stmt_create_contract->close();

            $conn->commit();
            $message = "Contract generated successfully! Contract #: " . $contract_no;
            
            // Refresh proposal data
            $stmt_get_proposal_data = $conn->prepare($sql_get_proposal_data);
            $stmt_get_proposal_data->bind_param("i", $proposal_id);
            $stmt_get_proposal_data->execute();
            $result_proposal_data = $stmt_get_proposal_data->get_result();
            $proposal_data = $result_proposal_data->fetch_assoc();
            $stmt_get_proposal_data->close();

        } catch (Exception $e) {
            $conn->rollback();
            $error = "Transaction failed: " . $e->getMessage();
        }
    }
}

$conn->close();

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = isset($_SESSION['role_name']) ? $_SESSION['role_name'] : getUserRoleName($user_role_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Contract | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 0.35em 0.65em;
        }
        
        .info-card {
            border-left: 4px solid var(--secondary-color);
            background-color: #f8f9fa;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        .financial-summary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1 || $user_role_id == 2) { ?>
            <li class="nav-item">
                <a class="nav-link" href="view_proposals.php">
                    <i class="fas fa-file-contract"></i>
                    <span>View Proposals</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="#">
                    <i class="fas fa-file-signature"></i>
                    <span>Generate Contracts</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Generate Contract</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <a href="view_proposals.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to Proposals
                </a>
            </div>
            
            <?php if ($proposal_data): ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-file-signature me-2"></i>Contract Generation
                        </div>
                        <div class="card-body">
                            <?php if ($proposal_data['status'] === 'accepted'): ?>
                                <div class="alert alert-success">
                                    <i class="fas fa-check-circle me-2"></i>
                                    This proposal has already been accepted and a contract has been generated.
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Important:</strong> Generating a contract will automatically:
                                    <ul class="mb-0 mt-2">
                                        <li>Accept this proposal and reject all others for this RFQ</li>
                                        <li>Update the budget by moving funds from committed to spent</li>
                                        <li>Create a contract record in the system</li>
                                        <li>Update the RFQ status to "Awarded"</li>
                                    </ul>
                                </div>
                                
                                <form method="post" id="contractForm">
                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                    
                                    <div class="mb-4">
                                        <h5>Confirmation</h5>
                                        <p>Are you sure you want to generate a contract for this proposal?</p>
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" id="confirmation" required>
                                            <label class="form-check-label" for="confirmation">
                                                I confirm that I want to generate a contract for this proposal
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success btn-lg">
                                        <i class="fas fa-file-contract me-2"></i>Generate Contract
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="dashboard-card mt-4">
                        <div class="card-header">
                            <i class="fas fa-info-circle me-2"></i>Proposal Details
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-sm">
                                        <tr>
                                            <th width="40%">Proposal ID:</th>
                                            <td>#<?php echo htmlspecialchars($proposal_data['id']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>RFQ Number:</th>
                                            <td><?php echo htmlspecialchars($proposal_data['rfq_no']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>RFQ Title:</th>
                                            <td><?php echo htmlspecialchars($proposal_data['rfq_title']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Requisition Title:</th>
                                            <td><?php echo htmlspecialchars($proposal_data['requisition_title']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date Submitted:</th>
                                            <td><?php echo date('M j, Y g:i A', strtotime($proposal_data['submitted_at'])); ?></td>
                                        </tr>
                                    </table>
                                </div>
                                
                                <div class="col-md-6">
                                    <table class="table table-sm">
                                        <tr>
                                            <th width="40%">Supplier:</th>
                                            <td><?php echo htmlspecialchars($proposal_data['supplier_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Person:</th>
                                            <td><?php echo htmlspecialchars($proposal_data['contact_person']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Email:</th>
                                            <td><?php echo htmlspecialchars($proposal_data['contact_email']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Phone:</th>
                                            <td><?php echo htmlspecialchars($proposal_data['contact_phone']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Status:</th>
                                            <td>
                                                <span class="badge 
                                                    <?php 
                                                    if ($proposal_data['status'] == 'accepted') echo 'bg-success';
                                                    elseif ($proposal_data['status'] == 'rejected') echo 'bg-danger';
                                                    else echo 'bg-warning';
                                                    ?> status-badge">
                                                    <?php echo ucfirst($proposal_data['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="financial-summary mt-4">
                                <h5 class="text-white">Financial Summary</h5>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="d-block">Proposed Amount</span>
                                        <h3 class="text-white mb-0">$<?php echo number_format($proposal_data['amount'], 2); ?></h3>
                                    </div>
                                    <?php if ($proposal_data['proposal_file']): ?>
                                    <div>
                                        <a href="<?php echo htmlspecialchars($proposal_data['proposal_file']); ?>" 
                                           target="_blank" class="btn btn-light">
                                            <i class="fas fa-download me-1"></i>Download Proposal
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-lightbulb me-2"></i>Process Information
                        </div>
                        <div class="card-body">
                            <div class="alert alert-info">
                                <h6><i class="fas fa-info-circle me-1"></i>What happens next?</h6>
                                <ul class="small mb-0 ps-3">
                                    <li>A contract will be created with status "Active"</li>
                                    <li>The supplier will be notified of the award</li>
                                    <li>Budget funds will be moved from committed to spent</li>
                                    <li>All other proposals for this RFQ will be rejected</li>
                                    <li>The RFQ status will be updated to "Awarded"</li>
                                </ul>
                            </div>
                            
                            <div class="alert alert-warning">
                                <h6><i class="fas fa-exclamation-triangle me-1"></i>Important Notes</h6>
                                <ul class="small mb-0 ps-3">
                                    <li>This action cannot be undone</li>
                                    <li>Ensure all evaluation criteria have been met</li>
                                    <li>Verify supplier credentials and compliance</li>
                                    <li>Confirm budget availability</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-card mt-4">
                        <div class="card-header">
                            <i class="fas fa-cog me-2"></i>Quick Actions
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="view_proposals.php?rfq_id=<?php echo $proposal_data['rfq_id']; ?>" class="btn btn-outline-primary">
                                    <i class="fas fa-list me-1"></i>View All Proposals for this RFQ
                                </a>
                                <a href="view_rfq.php?id=<?php echo $proposal_data['rfq_id']; ?>" class="btn btn-outline-info">
                                    <i class="fas fa-eye me-1"></i>View RFQ Details
                                </a>
                                <a href="manage_contracts.php" class="btn btn-outline-success">
                                    <i class="fas fa-file-contract me-1"></i>Manage Contracts
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <?php echo htmlspecialchars($error ? $error : "Proposal not found."); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        // Form validation
        document.getElementById('contractForm')?.addEventListener('submit', function(e) {
            const confirmation = document.getElementById('confirmation');
            
            if (!confirmation.checked) {
                e.preventDefault();
                alert('Please confirm that you want to generate the contract.');
                confirmation.focus();
                return false;
            }
            
            if (!confirm('Are you sure you want to generate a contract for this proposal? This action cannot be undone.')) {
                e.preventDefault();
                return false;
            }
        });
    </script>
</body>
</html>