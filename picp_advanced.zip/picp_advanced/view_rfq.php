<?php
// view_rfq.php
session_start();
require_once 'users.php';

// Check if the supplier is logged in
if (!isset($_SESSION["supplier_id"])) {
    header("location: supplier_login.php");
    exit;
}

$conn = connectDB();
$rfq_details = null;
$rfq_items = [];
$message = '';

if (isset($_GET['rfq_no']) && !empty($_GET['rfq_no'])) {
    $rfq_no = $_GET['rfq_no'];
    $supplier_id = $_SESSION['supplier_id'];

    // Fetch RFQ details
    $sql_rfq = "SELECT id, rfq_no, title, due_date, status FROM rfqs WHERE rfq_no = ?";
    $stmt_rfq = $conn->prepare($sql_rfq);

    if ($stmt_rfq === false) {
        die("Error preparing RFQ statement: " . $conn->error);
    }

    $stmt_rfq->bind_param("s", $rfq_no);
    $stmt_rq->execute();
    $result_rfq = $stmt_rfq->get_result();
    $rfq_details = $result_rfq->fetch_assoc();
    $stmt_rfq->close();

    if ($rfq_details) {
        // Fetch items associated with the RFQ directly from the rfq_items table
        $sql_items = "
            SELECT
                id,
                quantity,
                item_description,
                unit_of_measure
            FROM rfq_items
            WHERE rfq_id = ?
        ";
        $stmt_items = $conn->prepare($sql_items);
        if ($stmt_items === false) {
            die("Error preparing items statement: " . $conn->error);
        }
        $stmt_items->bind_param("i", $rfq_details['id']);
        $stmt_items->execute();
        $result_items = $stmt_items->get_result();
        $rfq_items = $result_items->fetch_all(MYSQLI_ASSOC);
        $stmt_items->close();
    } else {
        $message = "RFQ not found.";
    }
} else {
    $message = "No RFQ number provided.";
}

// Handle proposal submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rfq_id = $_POST['rfq_id'];
    $supplier_id = $_POST['supplier_id'];
    $proposal_date = date("Y-m-d H:i:s");
    $items = $_POST['items'];

    $conn->begin_transaction();
    try {
        // Insert a new proposal
        $sql_proposal = "INSERT INTO supplier_proposals (rfq_id, supplier_id, proposal_date) VALUES (?, ?, ?)";
        $stmt_proposal = $conn->prepare($sql_proposal);
        if ($stmt_proposal === false) {
            throw new Exception("Proposal statement failed: " . $conn->error);
        }
        $stmt_proposal->bind_param("iis", $rfq_id, $supplier_id, $proposal_date);
        $stmt_proposal->execute();
        $proposal_id = $stmt_proposal->insert_id;
        $stmt_proposal->close();

        // Insert proposal items
        $sql_proposal_item = "INSERT INTO proposal_items (proposal_id, rfq_item_id, offered_price, comments) VALUES (?, ?, ?, ?)";
        $stmt_proposal_item = $conn->prepare($sql_proposal_item);
        if ($stmt_proposal_item === false) {
            throw new Exception("Proposal item statement failed: " . $conn->error);
        }

        foreach ($items as $item) {
            $rfq_item_id = $item['rfq_item_id'];
            $offered_price = $item['offered_price'];
            $comments = $item['comments'];

            $stmt_proposal_item->bind_param("iids", $proposal_id, $rfq_item_id, $offered_price, $comments);
            $stmt_proposal_item->execute();
        }
        $stmt_proposal_item->close();

        $conn->commit();
        $message = "Your proposal has been submitted successfully!";
        // You might want to redirect to a confirmation page here
        // header("location: supplier_inbox.php?success=1");
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error: " . $e->getMessage();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View RFQ: <?php echo htmlspecialchars($rfq_details['rfq_no'] ?? ''); ?> | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .status-badge {
            padding: 8px 15px;
            border-radius: 30px;
            font-weight: 600;
        }
        
        .status-open {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-closed {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .status-draft {
            background-color: #e2e3e5;
            color: #383d41;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .due-date-alert {
            border-left: 4px solid var(--accent-color);
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <!-- Navigation -->
        <nav class="mb-4">
            <a href="supplier_inbox.php" class="btn btn-outline-primary">
                <i class="fas fa-arrow-left me-2"></i>Back to Inbox
            </a>
        </nav>

        <!-- Message Alert -->
        <?php if ($message): ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if ($rfq_details) { ?>
        <!-- RFQ Header -->
        <div class="header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="h3 mb-1"><?php echo htmlspecialchars($rfq_details['title']); ?></h1>
                    <p class="mb-0">RFQ #<?php echo htmlspecialchars($rfq_details['rfq_no']); ?></p>
                </div>
                <div class="col-md-4 text-md-end">
                    <span class="status-badge status-<?php echo strtolower($rfq_details['status']); ?>">
                        <?php echo ucfirst($rfq_details['status']); ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- RFQ Details -->
        <div class="row">
            <div class="col-md-6">
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-info-circle me-2"></i>RFQ Information
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-sm-4 fw-bold">RFQ Number:</div>
                            <div class="col-sm-8"><?php echo htmlspecialchars($rfq_details['rfq_no']); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-sm-4 fw-bold">Title:</div>
                            <div class="col-sm-8"><?php echo htmlspecialchars($rfq_details['title']); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-sm-4 fw-bold">Status:</div>
                            <div class="col-sm-8">
                                <span class="status-badge status-<?php echo strtolower($rfq_details['status']); ?>">
                                    <?php echo ucfirst($rfq_details['status']); ?>
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 fw-bold">Due Date:</div>
                            <div class="col-sm-8">
                                <?php 
                                $due_date = new DateTime($rfq_details['due_date']);
                                $today = new DateTime();
                                $interval = $today->diff($due_date);
                                $days_left = $interval->format('%r%a');
                                
                                echo htmlspecialchars($rfq_details['due_date']);
                                if ($days_left > 0) {
                                    echo " <span class='badge bg-warning text-dark ms-2'>" . $days_left . " days left</span>";
                                } elseif ($days_left == 0) {
                                    echo " <span class='badge bg-danger ms-2'>Due today</span>";
                                } else {
                                    echo " <span class='badge bg-secondary ms-2'>Expired</span>";
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-exclamation-circle me-2"></i>Submission Guidelines
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i>Fill in all required fields</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i>Provide competitive pricing</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i>Add comments for any special terms</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i>Review before submission</li>
                            <li><i class="fas fa-check-circle text-success me-2"></i>Submit before the due date</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Proposal Form -->
        <form action="view_rfq.php?rfq_no=<?php echo urlencode($rfq_details['rfq_no']); ?>" method="post">
            <input type="hidden" name="rfq_id" value="<?php echo htmlspecialchars($rfq_details['id']); ?>">
            <input type="hidden" name="supplier_id" value="<?php echo htmlspecialchars($_SESSION['supplier_id']); ?>">
            
            <div class="dashboard-card">
                <div class="card-header">
                    <i class="fas fa-list me-2"></i>RFQ Items - Submit Your Proposal
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Item Description</th>
                                    <th>Quantity</th>
                                    <th>Unit</th>
                                    <th>Offered Price</th>
                                    <th>Comments</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rfq_items as $item) { ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['item_description']); ?></td>
                                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                        <td><?php echo htmlspecialchars($item['unit_of_measure']); ?></td>
                                        <td>
                                            <input type="hidden" name="items[<?php echo htmlspecialchars($item['id']); ?>][rfq_item_id]" value="<?php echo htmlspecialchars($item['id']); ?>">
                                            <div class="input-group">
                                                <span class="input-group-text">$</span>
                                                <input type="number" class="form-control" name="items[<?php echo htmlspecialchars($item['id']); ?>][offered_price]" step="0.01" min="0" required>
                                            </div>
                                        </td>
                                        <td>
                                            <textarea class="form-control" name="items[<?php echo htmlspecialchars($item['id']); ?>][comments]" rows="2" placeholder="Optional comments..."></textarea>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer text-end">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-paper-plane me-2"></i>Submit Proposal
                    </button>
                </div>
            </div>
        </form>
        
        <?php } else { ?>
        <div class="alert alert-warning text-center py-5">
            <i class="fas fa-exclamation-triangle fa-3x mb-3"></i>
            <h3><?php echo htmlspecialchars($message); ?></h3>
            <p class="mt-3">Please check the RFQ number and try again.</p>
            <a href="supplier_inbox.php" class="btn btn-primary mt-2">
                <i class="fas fa-arrow-left me-2"></i>Return to Inbox
            </a>
        </div>
        <?php } ?>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>