<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and is an admin
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    header("location: dashboard.php");
    exit;
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$error = '';
$conn = connectDB();
$user_data = null;

// Handle form submission to update user
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid CSRF token. Please try again.";
    } else {
        $user_id = filter_input(INPUT_POST, 'user_id', FILTER_SANITIZE_NUMBER_INT);
        $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $department_id = filter_input(INPUT_POST, 'department_id', FILTER_SANITIZE_NUMBER_INT);
        $role_id = filter_input(INPUT_POST, 'role_id', FILTER_SANITIZE_NUMBER_INT);
        $location_id = filter_input(INPUT_POST, 'location_id', FILTER_SANITIZE_NUMBER_INT);
        $phone_number = filter_input(INPUT_POST, 'phone_number', FILTER_SANITIZE_STRING);
        $job_title = filter_input(INPUT_POST, 'job_title', FILTER_SANITIZE_STRING);

        // Validate inputs
        if (empty($name) || empty($email) || empty($department_id) || empty($role_id) || empty($location_id)) {
            $error = "All required fields must be filled.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format.";
        } else {
            // Update SQL query
            $sql = "UPDATE users SET name = ?, email = ?, department_id = ?, role_id = ?, location_id = ?, phone_number = ?, job_title = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssiiissi", $name, $email, $department_id, $role_id, $location_id, $phone_number, $job_title, $user_id);
            
            if ($stmt->execute()) {
                $message = "User updated successfully!";
            } else {
                $error = "Error updating user: " . $stmt->error;
            }
            $stmt->close();
            
            // Re-fetch user data after update
            $user_sql = "SELECT * FROM users WHERE id = ?";
            $stmt_user = $conn->prepare($user_sql);
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $user_data = $stmt_user->get_result()->fetch_assoc();
            $stmt_user->close();
        }
    }
} else {
    // Fetch user data for the form
    if (isset($_GET['id'])) {
        $user_id = $_GET['id'];
        $user_sql = "SELECT * FROM users WHERE id = ?";
        $stmt_user = $conn->prepare($user_sql);
        $stmt_user->bind_param("i", $user_id);
        $stmt_user->execute();
        $user_data = $stmt_user->get_result()->fetch_assoc();
        $stmt_user->close();

        if (!$user_data) {
            $error = "User not found.";
        }
    } else {
        header("location: manage_users.php");
        exit;
    }
}

// Fetch departments, roles, and locations for dropdowns
$departments = $conn->query("SELECT id, name FROM departments ORDER BY name ASC");
$roles = $conn->query("SELECT id, name FROM roles ORDER BY name ASC");
$locations = $conn->query("SELECT id, name FROM locations ORDER BY name ASC");
$conn->close();

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = isset($_SESSION['role_name']) ? $_SESSION['role_name'] : getUserRoleName($user_role_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 0.35em 0.65em;
        }
        
        .user-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link active" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Edit User</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($user_data): ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-user-edit me-2"></i>Edit User Details
                        </div>
                        <div class="card-body">
                            <form action="edit_user.php" method="post" id="userForm">
                                <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_data['id']); ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user_data['name']); ?>" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="phone_number" class="form-label">Phone Number</label>
                                        <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($user_data['phone_number']); ?>">
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="job_title" class="form-label">Job Title</label>
                                        <input type="text" class="form-control" id="job_title" name="job_title" value="<?php echo htmlspecialchars($user_data['job_title']); ?>">
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="department_id" class="form-label">Department <span class="text-danger">*</span></label>
                                        <select class="form-select" id="department_id" name="department_id" required>
                                            <?php while($dept = $departments->fetch_assoc()) { ?>
                                                <option value="<?php echo $dept['id']; ?>" <?php echo ($dept['id'] == $user_data['department_id']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($dept['name']); ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="role_id" class="form-label">Role <span class="text-danger">*</span></label>
                                        <select class="form-select" id="role_id" name="role_id" required>
                                            <?php while($role = $roles->fetch_assoc()) { ?>
                                                <option value="<?php echo $role['id']; ?>" <?php echo ($role['id'] == $user_data['role_id']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($role['name']); ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="location_id" class="form-label">Location <span class="text-danger">*</span></label>
                                        <select class="form-select" id="location_id" name="location_id" required>
                                            <?php while($loc = $locations->fetch_assoc()) { ?>
                                                <option value="<?php echo $loc['id']; ?>" <?php echo ($loc['id'] == $user_data['location_id']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($loc['name']); ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between mt-4">
                                    <a href="manage_users.php" class="btn btn-secondary">
                                        <i class="fas fa-arrow-left me-1"></i>Back to Users
                                    </a>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-save me-1"></i>Update User
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-info-circle me-2"></i>User Information
                        </div>
                        <div class="card-body text-center">
                            <div class="mb-3">
                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user_data['name']); ?>&background=3498db&color=fff&size=100" 
                                     alt="User Avatar" class="user-avatar">
                            </div>
                            
                            <h5><?php echo htmlspecialchars($user_data['name']); ?></h5>
                            <p class="text-muted"><?php echo htmlspecialchars($user_data['email']); ?></p>
                            
                            <div class="mb-3">
                                <strong>Account Status:</strong><br>
                                <span class="badge bg-<?php echo ($user_data['status'] == 1) ? 'success' : 'danger'; ?> status-badge">
                                    <?php echo ($user_data['status'] == 1) ? 'Active' : 'Inactive'; ?>
                                </span>
                            </div>
                            
                            <div class="mb-3">
                                <strong>Last Login:</strong><br>
                                <?php echo isset($user_data['last_login_at']) && $user_data['last_login_at'] != '0000-00-00 00:00:00' ? 
                                    date('M j, Y g:i A', strtotime($user_data['last_login_at'])) : 'Never logged in'; ?>
                            </div>
                            
                            <div class="mb-3">
                                <strong>Date Created:</strong><br>
                                <?php echo date('M j, Y', strtotime($user_data['created_at'])); ?>
                            </div>
                            
                            <div class="alert alert-info mt-3">
                                <small>
                                    <i class="fas fa-lightbulb me-1"></i>
                                    <strong>Note:</strong> To change user's account status or reset password, use the dedicated functions in the user management system.
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-card mt-4">
                        <div class="card-header">
                            <i class="fas fa-cog me-2"></i>Quick Actions
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="manage_users.php" class="btn btn-outline-primary">
                                    <i class="fas fa-list me-1"></i>View All Users
                                </a>
                                <a href="manage_users.php" class="btn btn-outline-success">
                                    <i class="fas fa-plus me-1"></i>Add New User
                                </a>
                                <button type="button" class="btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#resetPasswordModal">
                                    <i class="fas fa-key me-1"></i>Reset Password
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <?php echo htmlspecialchars($error ? $error : "User not found."); ?>
                </div>
                <div class="text-center mt-3">
                    <a href="manage_users.php" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-1"></i>Back to Manage Users
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Reset Password Modal -->
    <div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-labelledby="resetPasswordModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="resetPasswordModalLabel">Reset Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to reset the password for <strong><?php echo htmlspecialchars($user_data['name']); ?></strong>?</p>
                    <p>A temporary password will be generated and emailed to the user.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-warning" onclick="alert('Password reset functionality would be implemented here.');">
                        <i class="fas fa-key me-1"></i>Reset Password
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        // Form validation
        document.getElementById('userForm').addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const department = document.getElementById('department_id').value;
            const role = document.getElementById('role_id').value;
            const location = document.getElementById('location_id').value;
            
            if (!name) {
                e.preventDefault();
                alert('Full name is required.');
                document.getElementById('name').focus();
                return false;
            }
            
            if (!email) {
                e.preventDefault();
                alert('Email address is required.');
                document.getElementById('email').focus();
                return false;
            }
            
            if (!isValidEmail(email)) {
                e.preventDefault();
                alert('Please enter a valid email address.');
                document.getElementById('email').focus();
                return false;
            }
            
            if (!department) {
                e.preventDefault();
                alert('Department is required.');
                document.getElementById('department_id').focus();
                return false;
            }
            
            if (!role) {
                e.preventDefault();
                alert('Role is required.');
                document.getElementById('role_id').focus();
                return false;
            }
            
            if (!location) {
                e.preventDefault();
                alert('Location is required.');
                document.getElementById('location_id').focus();
                return false;
            }
        });
        
        function isValidEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
    </script>
</body>
</html>