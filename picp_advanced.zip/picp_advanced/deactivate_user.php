<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

if ($_SESSION['role_id'] != 1) { // Only Admin can deactivate
    echo "You do not have permission to access this page.";
    exit;
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid request.");
}

$user_id = intval($_GET['id']);
$conn = connectDB();

$sql = "UPDATE users SET user_status = 0 WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    header("Location: manage_users.php?msg=User+deactivated");
    exit;
} else {
    echo "Error deactivating user: " . $conn->error;
}
$conn->close();
?>
