<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: index.php");
    exit;
}

$message = '';
$message_type = ''; // success, danger, warning, info
$po_details = null;
$po_items = [];
$conn = connectDB();

if (isset($_GET['po_id'])) {
    $po_id = intval($_GET['po_id']);

    // Fetch PO details
    $sql_po = "SELECT po.*, s.name AS supplier_name, s.address AS supplier_address, 
                      s.contact_person, s.phone, s.email
               FROM purchase_orders po 
               JOIN suppliers s ON po.supplier_id = s.id 
               WHERE po.id = ?";
    $stmt_po = $conn->prepare($sql_po);
    $stmt_po->bind_param("i", $po_id);
    $stmt_po->execute();
    $result_po = $stmt_po->get_result();
    if ($result_po->num_rows > 0) {
        $po_details = $result_po->fetch_assoc();
    } else {
        $message = "Purchase order not found.";
        $message_type = "danger";
    }
    $stmt_po->close();

    // Fetch PO items
    $sql_items = "SELECT poi.*, i.name AS item_name, i.sku 
                  FROM purchase_order_items poi 
                  LEFT JOIN items i ON poi.item_id = i.id 
                  WHERE poi.po_id = ?";
    $stmt_items = $conn->prepare($sql_items);
    $stmt_items->bind_param("i", $po_id);
    $stmt_items->execute();
    $result_items = $stmt_items->get_result();
    $po_items = $result_items->fetch_all(MYSQLI_ASSOC);
    $stmt_items->close();

} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['po_id'])) {
    $po_id = intval($_POST['po_id']);
    $received_quantities = $_POST['received_quantity'];
    $item_ids = $_POST['item_id'];
    $batch_numbers = $_POST['batch_number'];
    $expiry_dates = $_POST['expiry_date'];

    $conn->begin_transaction();
    try {
        $all_received = true;
        foreach ($item_ids as $key => $item_id) {
            $received_qty = intval($received_quantities[$key]);
            $batch_number = !empty($batch_numbers[$key]) ? $batch_numbers[$key] : null;
            $expiry_date = !empty($expiry_dates[$key]) ? $expiry_dates[$key] : null;
            
            if ($received_qty > 0) {
                // Update received_qty in the po_items table
                $sql_update_po_item = "UPDATE purchase_order_items SET received_quantity = received_quantity + ? WHERE id = ?";
                $stmt_update_po_item = $conn->prepare($sql_update_po_item);
                $stmt_update_po_item->bind_param("ii", $received_qty, $item_id);
                if (!$stmt_update_po_item->execute()) {
                    throw new Exception("Error updating received quantity: " . $stmt_update_po_item->error);
                }
                $stmt_update_po_item->close();

                // Update inventory table
                $sql_update_inventory = "INSERT INTO inventory (item_id, quantity, batch_number, expiry_date, location_id) 
                                         VALUES (?, ?, ?, ?, 1) 
                                         ON DUPLICATE KEY UPDATE quantity = quantity + ?";
                $stmt_update_inventory = $conn->prepare($sql_update_inventory);
                $stmt_update_inventory->bind_param("iissi", $item_id, $received_qty, $batch_number, $expiry_date, $received_qty);
                if (!$stmt_update_inventory->execute()) {
                    throw new Exception("Error updating inventory: " . $stmt_update_inventory->error);
                }
                $stmt_update_inventory->close();
            }

            // Check if all items are fully received
            $sql_check = "SELECT quantity, received_quantity FROM purchase_order_items WHERE id = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("i", $item_id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            $check_item = $result_check->fetch_assoc();
            $stmt_check->close();

            if ($check_item['quantity'] > $check_item['received_quantity']) {
                $all_received = false;
            }
        }

        // Update PO status
        $new_status = $all_received ? 'received' : 'partially_received';
        $sql_update_po_status = "UPDATE purchase_orders SET status = ? WHERE id = ?";
        $stmt_update_po_status = $conn->prepare($sql_update_po_status);
        $stmt_update_po_status->bind_param("si", $new_status, $po_id);
        if (!$stmt_update_po_status->execute()) {
            throw new Exception("Error updating PO status: " . $stmt_update_po_status->error);
        }
        $stmt_update_po_status->close();
        
        $conn->commit();
        $message = "Goods received successfully! Inventory has been updated.";
        $message_type = "success";
        header("location: view_purchase_orders.php?message=" . urlencode($message) . "&type=success");
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error processing receipt: " . $e->getMessage();
        $message_type = "danger";
    }
}
$conn->close();

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = $_SESSION['role_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receive Goods | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .section-title {
            border-left: 4px solid var(--secondary-color);
            padding-left: 10px;
            margin: 25px 0 15px;
            font-weight: 600;
        }
        
        .status-badge {
            font-size: 0.9rem;
            padding: 5px 15px;
            border-radius: 20px;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .quantity-input {
            max-width: 100px;
        }
        
        .info-card {
            background-color: #e9ecef;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_purchase_orders.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Purchase Orders</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="#">
                    <i class="fas fa-truck-loading"></i>
                    <span>Receive Goods</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inventory.php">
                    <i class="fas fa-boxes"></i>
                    <span>Inventory</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0"><i class="fas fa-truck-loading me-2"></i>Receive Goods</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Content -->
        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                    <i class="fas <?php echo $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> me-2"></i>
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="section-title">Goods Receiving</h4>
                <a href="view_purchase_orders.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Purchase Orders
                </a>
            </div>
    
            <?php if ($po_details): ?>
                <!-- PO Information Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-file-invoice-dollar me-2"></i>Purchase Order Details
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-card">
                                    <h6 class="fw-bold">PO Information</h6>
                                    <p class="mb-1"><strong>PO Number:</strong> <?= htmlspecialchars($po_details['po_no']); ?></p>
                                    <p class="mb-1"><strong>Status:</strong> 
                                        <span class="status-badge 
                                            <?= $po_details['status'] == 'approved' ? 'bg-success' : 
                                              ($po_details['status'] == 'pending' ? 'bg-warning text-dark' : 
                                              ($po_details['status'] == 'received' ? 'bg-info' : 
                                              ($po_details['status'] == 'partially_received' ? 'bg-primary' : 'bg-secondary'))); ?>">
                                            <?= ucfirst(str_replace('_', ' ', $po_details['status'])); ?>
                                        </span>
                                    </p>
                                    <p class="mb-1"><strong>Order Date:</strong> <?= date('M j, Y', strtotime($po_details['created_at'])); ?></p>
                                    <p class="mb-0"><strong>Total Amount:</strong> $<?= number_format($po_details['total_amount'], 2); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-card">
                                    <h6 class="fw-bold">Supplier Information</h6>
                                    <p class="mb-1"><strong>Name:</strong> <?= htmlspecialchars($po_details['supplier_name']); ?></p>
                                    <?php if (!empty($po_details['supplier_address'])): ?>
                                    <p class="mb-1"><strong>Address:</strong> <?= htmlspecialchars($po_details['supplier_address']); ?></p>
                                    <?php endif; ?>
                                    <?php if (!empty($po_details['contact_person'])): ?>
                                    <p class="mb-1"><strong>Contact:</strong> <?= htmlspecialchars($po_details['contact_person']); ?></p>
                                    <?php endif; ?>
                                    <?php if (!empty($po_details['phone'])): ?>
                                    <p class="mb-1"><strong>Phone:</strong> <?= htmlspecialchars($po_details['phone']); ?></p>
                                    <?php endif; ?>
                                    <?php if (!empty($po_details['email'])): ?>
                                    <p class="mb-0"><strong>Email:</strong> <?= htmlspecialchars($po_details['email']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Receiving Form -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <i class="fas fa-clipboard-check me-2"></i>Confirm Received Items
                    </div>
                    <div class="card-body">
                        <form action="receive_goods.php" method="post" id="receivingForm">
                            <input type="hidden" name="po_id" value="<?= htmlspecialchars($po_details['id']); ?>">
                            
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Item Description</th>
                                            <th>SKU</th>
                                            <th>Ordered Qty</th>
                                            <th>Received So Far</th>
                                            <th>Receiving Now</th>
                                            <th>Batch Number</th>
                                            <th>Expiry Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($po_items as $item): 
                                            $remaining = $item['quantity'] - $item['received_quantity'];
                                        ?>
                                            <tr>
                                                <td><?= htmlspecialchars($item['item_name'] ?: $item['item_description']); ?></td>
                                                <td><?= htmlspecialchars($item['sku'] ?? 'N/A'); ?></td>
                                                <td><?= htmlspecialchars($item['quantity']); ?></td>
                                                <td><?= htmlspecialchars($item['received_quantity']); ?></td>
                                                <td>
                                                    <input type="number" class="form-control quantity-input" 
                                                           name="received_quantity[]" min="0" max="<?= $remaining; ?>" 
                                                           value="0" required <?= $remaining == 0 ? 'readonly' : ''; ?>>
                                                    <input type="hidden" name="item_id[]" value="<?= htmlspecialchars($item['id']); ?>">
                                                </td>
                                                <td>
                                                    <input type="text" class="form-control" name="batch_number[]" 
                                                           placeholder="Optional" maxlength="50">
                                                </td>
                                                <td>
                                                    <input type="date" class="form-control" name="expiry_date[]">
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                                <button type="reset" class="btn btn-outline-secondary me-md-2">
                                    <i class="fas fa-undo me-1"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-check-circle me-1"></i> Confirm Receipt
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    No valid Purchase Order found to confirm receipt for.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Form validation
            document.getElementById('receivingForm').addEventListener('submit', function(e) {
                let isValid = false;
                const quantityInputs = document.querySelectorAll('input[name="received_quantity[]"]');
                
                // Check if at least one item has quantity > 0
                quantityInputs.forEach(input => {
                    if (parseInt(input.value) > 0) {
                        isValid = true;
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    alert('Please enter quantity for at least one item.');
                    return false;
                }
            });
            
            // Auto-disable fully received items
            const quantityInputs = document.querySelectorAll('input[name="received_quantity[]"]');
            quantityInputs.forEach(input => {
                if (input.readOnly) {
                    input.closest('tr').style.opacity = '0.6';
                }
            });
        });
    </script>
</body>
</html>