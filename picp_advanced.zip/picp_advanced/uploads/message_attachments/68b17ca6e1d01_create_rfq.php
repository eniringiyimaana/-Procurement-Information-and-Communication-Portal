<?php
session_start();
require_once 'users.php';

// Establish a database connection
$conn = connectDB();

if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 2) {
    header("location: dashboard.php");
    exit;
}

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_rfq'])) {
    $requisition_id = $_POST['requisition_id'];
    $title = $_POST['title'];
    $due_date = $_POST['due_date'];
    $invited_suppliers = $_POST['invited_suppliers'];
    $rfq_no = 'RFQ-' . date('Ymd-') . uniqid();
    $created_by = $_SESSION['user_id'];

    $conn->begin_transaction();

    try {
        // 1. Insert the new RFQ into the rfqs table
        $sql_rfq = "INSERT INTO rfqs (rfq_no, requisition_id, title, due_date, created_by, status) VALUES (?, ?, ?, ?, ?, 'published')";
        $stmt_rfq = $conn->prepare($sql_rfq);
        if (!$stmt_rfq) {
            throw new Exception("RFQ insert failed: " . $conn->error);
        }
        $stmt_rfq->bind_param("sisss", $rfq_no, $requisition_id, $title, $due_date, $created_by);
        $stmt_rfq->execute();
        $rfq_id = $conn->insert_id;
        $stmt_rfq->close();

        // 2. Copy items from requisition_items to rfq_items
        $sql_copy_items = "
            INSERT INTO rfq_items (rfq_id, requisition_item_id, quantity, estimated_cost, item_description, unit_of_measure)
            SELECT ?, ri.id, ri.quantity, ri.estimated_cost, i.item_description, i.unit_of_measure
            FROM requisition_items ri
            JOIN items i ON ri.item_id = i.id
            WHERE ri.requisition_id = ?
        ";
        $stmt_copy = $conn->prepare($sql_copy_items);
        if (!$stmt_copy) {
             throw new Exception("Item copy failed: " . $conn->error);
        }
        $stmt_copy->bind_param("ii", $rfq_id, $requisition_id);
        $stmt_copy->execute();
        $stmt_copy->close();

        // 3. Insert invitations for each supplier
        $sql_invite = "INSERT INTO rfq_invites (rfq_id, supplier_id, token, status) VALUES (?, ?, ?, 'pending')";
        $stmt_invite = $conn->prepare($sql_invite);
        if (!$stmt_invite) {
            throw new Exception("Invite insert failed: " . $conn->error);
        }
        foreach ($invited_suppliers as $supplier_id) {
            $token = bin2hex(random_bytes(32)); // Generate a unique token
            $stmt_invite->bind_param("iis", $rfq_id, $supplier_id, $token);
            $stmt_invite->execute();
        }
        $stmt_invite->close();

        // Commit the transaction
        $conn->commit();
        $message = "RFQ RFQ-{$rfq_no} created successfully!";

    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        $message = "Error creating RFQ: " . $e->getMessage();
    }
}
// Fetch approved requisitions
$sql_requisitions = "SELECT id, requisition_no, title FROM requisitions WHERE status = 'approved'";
$requisitions_result = $conn->query($sql_requisitions);
$requisition_options = "";
if ($requisitions_result->num_rows > 0) {
    while ($row = $requisitions_result->fetch_assoc()) {
        $requisition_options .= "<option value='{$row['id']}'>" . htmlspecialchars($row['requisition_no']) . " - " . htmlspecialchars($row['title']) . "</option>";
    }
} else {
    $requisition_options = "<option value=''>No approved requisitions available</option>";
}
// Fetch all active suppliers
$suppliers_result = $conn->query("SELECT id, name FROM suppliers WHERE status = 'active' ORDER BY name ASC");
$suppliers_checkboxes = "";
while ($row = $suppliers_result->fetch_assoc()) {
    $suppliers_checkboxes .= "<div><input type='checkbox' id='supplier_{$row['id']}' name='invited_suppliers[]' value='{$row['id']}'>\r\n    <label for='supplier_{$row['id']}'>" . htmlspecialchars($row['name']) . "</label></div>";
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create New RFQ</title>
</head>
<body>
    <h2>Create New RFQ</h2>
    <a href="dashboard.php">Back to Dashboard</a>

    <?php if (isset($message)) { echo "<p><strong>" . $message . "</strong></p>"; } ?>

    <hr>
    <form method="post" action="create_rfq.php">
        <label for="requisition_id">Select Requisition:</label>
        <select name="requisition_id" required>
            <?php echo $requisition_options; ?>
        </select><br><br>

        <label for="title">RFQ Title:</label>
        <input type="text" name="title" required><br><br>

        <label for="due_date">Due Date:</label>
        <input type="date" name="due_date" required><br><br>

        <label>Invite Suppliers:</label><br>
        <?php echo $suppliers_checkboxes; ?><br>

        <button type="submit" name="create_rfq">Create RFQ</button>
    </form>
</body>
</html>