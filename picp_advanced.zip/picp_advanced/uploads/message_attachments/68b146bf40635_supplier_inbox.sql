-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2025 at 08:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `picp_advanced`
--

-- --------------------------------------------------------

--
-- Table structure for table `supplier_inbox`
--

CREATE TABLE `supplier_inbox` (
  `id` int(11) NOT NULL,
  `sender_user_id` int(11) DEFAULT NULL,
  `sender_supplier_id` int(11) DEFAULT NULL,
  `recipient_user_id` int(11) DEFAULT NULL,
  `recipient_supplier_id` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message_body` text NOT NULL,
  `status` enum('unread','read','replied') NOT NULL DEFAULT 'unread',
  `sent_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_inbox`
--

INSERT INTO `supplier_inbox` (`id`, `sender_user_id`, `sender_supplier_id`, `recipient_user_id`, `recipient_supplier_id`, `subject`, `message_body`, `status`, `sent_at`) VALUES
(1, NULL, 4, 3, NULL, 'Testing', 'fffffghdsw', 'unread', '2025-08-29 08:51:43'),
(2, NULL, 4, 3, NULL, 'View my verified achievement from Cisco!', 'ertytr', 'unread', '2025-08-29 08:53:10'),
(3, NULL, 4, 3, NULL, 'View my verified achievement from Cisco!', 'ertytr', 'unread', '2025-08-29 09:13:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `supplier_inbox`
--
ALTER TABLE `supplier_inbox`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_user_id` (`sender_user_id`),
  ADD KEY `sender_supplier_id` (`sender_supplier_id`),
  ADD KEY `recipient_user_id` (`recipient_user_id`),
  ADD KEY `recipient_supplier_id` (`recipient_supplier_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `supplier_inbox`
--
ALTER TABLE `supplier_inbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `supplier_inbox`
--
ALTER TABLE `supplier_inbox`
  ADD CONSTRAINT `supplier_inbox_ibfk_1` FOREIGN KEY (`sender_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `supplier_inbox_ibfk_2` FOREIGN KEY (`sender_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `supplier_inbox_ibfk_3` FOREIGN KEY (`recipient_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `supplier_inbox_ibfk_4` FOREIGN KEY (`recipient_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
