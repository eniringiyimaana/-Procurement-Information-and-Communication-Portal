<?php
session_start();
require_once 'users.php';

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

$message = '';
$departments = [];
$items = [];

$conn = connectDB();

// Fetch departments for the form dropdown
$sql_departments = "SELECT id, name FROM departments";
$departments_result = $conn->query($sql_departments);
if ($departments_result) {
    while ($row = $departments_result->fetch_assoc()) {
        $departments[] = $row;
    }
}

// Fetch items and their associated GL accounts and spend categories for the form
$sql_items = "SELECT i.id, i.item_description, i.unit_of_measure, i.spend_category_id, ga.account_name, ga.account_no, ga.id as gl_account_id
              FROM items i
              JOIN gl_accounts ga ON i.gl_account_id = ga.id
              ORDER BY i.item_description ASC";
$items_result = $conn->query($sql_items);
if ($items_result) {
    while ($row = $items_result->fetch_assoc()) {
        $items[] = $row;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $justification = $_POST['justification'];
    $department_id = $_POST['department_id'];
    $requested_by = $_SESSION['user_id'];
    $item_ids = $_POST['item_id'];
    $quantities = $_POST['quantity'];
    $estimated_costs = $_POST['estimated_cost'];
    $total_amount = 0;
    
    // Calculate total amount
    for ($i = 0; $i < count($item_ids); $i++) {
        $total_amount += $quantities[$i] * $estimated_costs[$i];
    }

    $conn->begin_transaction();

    try {
        // Check for sufficient budget
        $fiscal_year = date("Y");
        $sql_budget = "SELECT allocated_amount, committed_amount, spent_amount FROM budgets WHERE department_id = ? AND fiscal_year = ?";
        $stmt_budget = $conn->prepare($sql_budget);
        if (!$stmt_budget) {
            throw new Exception("Budget check failed: " . $conn->error);
        }
        $stmt_budget->bind_param("ii", $department_id, $fiscal_year);
        $stmt_budget->execute();
        $budget_result = $stmt_budget->get_result();
        $budget = $budget_result->fetch_assoc();
        $stmt_budget->close();

        if ($budget) {
            $remaining_budget = $budget['allocated_amount'] - $budget['committed_amount'] - $budget['spent_amount'];
            if ($total_amount > $remaining_budget) {
                throw new Exception("Requisition amount exceeds the remaining budget for this department.");
            }
        }

        // Generate a unique requisition number
        $requisition_no = 'REQ-' . date('Ymd-') . uniqid();

        // Insert into requisitions table
        $sql = "INSERT INTO requisitions (requisition_no, title, justification, department_id, requested_by, total_amount, status) VALUES (?, ?, ?, ?, ?, ?, 'submitted')";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Requisition insert failed: " . $conn->error);
        }
        $stmt->bind_param("sssiid", $requisition_no, $title, $justification, $department_id, $requested_by, $total_amount);
        $stmt->execute();
        $requisition_id = $stmt->insert_id;
        $stmt->close();
        
        // Insert into requisition_items table
        $sql_items = "INSERT INTO requisition_items (requisition_id, item_description, quantity, unit_of_measure, estimated_cost, spend_category_id, gl_account_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt_items = $conn->prepare($sql_items);
        if (!$stmt_items) {
            throw new Exception("Requisition items insert failed: " . $conn->error);
        }
        
        // Create an array for quick item data lookup
        $item_lookup = [];
        foreach ($items as $item) {
            $item_lookup[$item['id']] = $item;
        }

        for ($i = 0; $i < count($item_ids); $i++) {
            $item_id = $item_ids[$i];
            $quantity = $quantities[$i];
            $estimated_cost = $estimated_costs[$i];
            
            // Look up item details based on the selected item_id
            $item_details = $item_lookup[$item_id];
            $item_description = $item_details['item_description'];
            $unit_of_measure = $item_details['unit_of_measure'];
            $spend_category_id = $item_details['spend_category_id'];
            $gl_account_id = $item_details['gl_account_id'];

            $stmt_items->bind_param("isidsii", $requisition_id, $item_description, $quantity, $unit_of_measure, $estimated_cost, $spend_category_id, $gl_account_id);
            $stmt_items->execute();
        }
        $stmt_items->close();

        // Update the committed amount in the budgets table
        $sql_update_budget = "UPDATE budgets SET committed_amount = committed_amount + ? WHERE department_id = ? AND fiscal_year = ?";
        $stmt_update_budget = $conn->prepare($sql_update_budget);
        if (!$stmt_update_budget) {
            throw new Exception("Budget update failed: " . $conn->error);
        }
        $stmt_update_budget->bind_param("dii", $total_amount, $department_id, $fiscal_year);
        $stmt_update_budget->execute();
        $stmt_update_budget->close();
        
        $conn->commit();
        $message = "Requisition submitted successfully with number: " . $requisition_no . "!";
        
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error submitting requisition: " . $e->getMessage();
    } finally {
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create New Requisition</title>
    <style>
        .item-row {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <h2>Create New Requisition</h2>
    <p><?php echo htmlspecialchars($message); ?></p>
    
    <form action="create_requisition.php" method="post" onsubmit="return confirm('Are you sure you want to submit this requisition?');">
        <label for="title">Requisition Title:</label><br>
        <input type="text" id="title" name="title" required><br><br>

        <label for="department_id">Department:</label><br>
        <select id="department_id" name="department_id" required>
            <?php foreach ($departments as $department) { ?>
                <option value="<?php echo htmlspecialchars($department['id']); ?>">
                    <?php echo htmlspecialchars($department['name']); ?>
                </option>
            <?php } ?>
        </select><br><br>
        
        <label for="justification">Justification:</label><br>
        <textarea id="justification" name="justification" rows="4" cols="50" required></textarea><br><br>
        
        <h3>Requisition Items</h3>
        <div id="items-container">
            <div class="item-row">
                <label for="item_id[]">Select Item:</label>
                <select name="item_id[]" required>
                    <?php foreach ($items as $item) { ?>
                        <option value="<?php echo htmlspecialchars($item['id']); ?>" 
                                data-unit="<?php echo htmlspecialchars($item['unit_of_measure']); ?>" 
                                data-gl-account-id="<?php echo htmlspecialchars($item['gl_account_id']); ?>">
                            <?php echo htmlspecialchars($item['item_description'] . ' (' . $item['unit_of_measure'] . ') - ' . $item['account_no']); ?>
                        </option>
                    <?php } ?>
                </select>
                
                <label for="quantity[]">Quantity:</label>
                <input type="number" name="quantity[]" required>
                
                <label for="estimated_cost[]">Estimated Cost:</label>
                <input type="number" name="estimated_cost[]" step="0.01" required>
            </div>
        </div>
        <button type="button" onclick="addItemRow()">Add Another Item</button>
        <br><br>

        <input type="submit" value="Submit Requisition">
    </form>

    <script>
        function addItemRow() {
            var container = document.getElementById("items-container");
            var newItemRow = document.createElement("div");
            newItemRow.className = "item-row";
            
            var itemOptions = '';
            <?php foreach ($items as $item) { ?>
                itemOptions += `<option value="<?php echo htmlspecialchars($item['id']); ?>" data-unit="<?php echo htmlspecialchars($item['unit_of_measure']); ?>" data-gl-account-id="<?php echo htmlspecialchars($item['gl_account_id']); ?>">
                                    <?php echo htmlspecialchars($item['item_description'] . ' (' . $item['unit_of_measure'] . ') - ' . $item['account_no']); ?>
                                </option>`;
            <?php } ?>

            newItemRow.innerHTML = `
                <br>
                <label for="item_id[]">Select Item:</label>
                <select name="item_id[]" required>${itemOptions}</select>
                
                <label for="quantity[]">Quantity:</label>
                <input type="number" name="quantity[]" required>
                
                <label for="estimated_cost[]">Estimated Cost:</label>
                <input type="number" name="estimated_cost[]" step="0.01" required>
            `;
            container.appendChild(newItemRow);
        }
    </script>
    <br>
    <a href="dashboard.php">Go back to Dashboard</a>
</body>
</html>