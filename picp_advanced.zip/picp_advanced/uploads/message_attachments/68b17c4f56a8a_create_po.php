<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and has the right role
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    header("location: index.php");
    exit;
}

$message = '';
$requisition = null;
$requisition_items = [];
$suppliers = [];

$conn = connectDB();

// Handle form submission to create the PO
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $requisition_id = $_POST['requisition_id'];
    $supplier_id = $_POST['supplier_id'];
    $po_no = "PO-" . date("Ymd") . "-" . uniqid();
    $total_amount = $_POST['total_amount'];

    $conn->begin_transaction();

    try {
        // Step 1: Insert into purchase_orders table
        $sql_po = "INSERT INTO purchase_orders (po_no, requisition_id, supplier_id, total_amount, status) VALUES (?, ?, ?, ?, 'issued')";
        $stmt_po = $conn->prepare($sql_po);
        $stmt_po->bind_param("siid", $po_no, $requisition_id, $supplier_id, $total_amount);
        $stmt_po->execute();
        $po_id = $stmt_po->insert_id;
        $stmt_po->close();

        // Step 2: Update requisition status
        $sql_req = "UPDATE requisitions SET status = 'po_created' WHERE id = ?";
        $stmt_req = $conn->prepare($sql_req);
        $stmt_req->bind_param("i", $requisition_id);
        $stmt_req->execute();
        $stmt_req->close();

        // Step 3: Fetch requisition items and insert into po_items
        $sql_items = "SELECT ri.item_id, ri.quantity, ri.estimated_cost, ri.gl_account_id, ri.spend_category_id, i.item_description FROM requisition_items ri JOIN items i ON ri.item_id = i.id WHERE ri.requisition_id = ?";
        $stmt_items = $conn->prepare($sql_items);
        $stmt_items->bind_param("i", $requisition_id);
        $stmt_items->execute();
        $result_items = $stmt_items->get_result();

        $sql_po_item = "INSERT INTO po_items (purchase_order_id, item_description, quantity, unit_price, gl_account_id, spend_category_id) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt_po_item = $conn->prepare($sql_po_item);
        if ($stmt_po_item === false) {
             throw new Exception("Error preparing statement: " . $conn->error);
        }

        while ($item = $result_items->fetch_assoc()) {
            $stmt_po_item->bind_param("isidii", $po_id, $item['item_description'], $item['quantity'], $item['estimated_cost'], $item['gl_account_id'], $item['spend_category_id']);
            $stmt_po_item->execute();
        }
        $stmt_items->close();
        $stmt_po_item->close();

        $conn->commit();
        $message = "Purchase Order #{$po_no} created successfully!";

    } catch (Exception $e) {
        $conn->rollback();
        $message = "Failed to create Purchase Order: " . $e->getMessage();
    } finally {
        $conn->close();
    }

}

// Fetch requisition details and items if a requisition_id is provided in the URL or POST
if (isset($_GET['requisition_id']) || isset($_POST['requisition_id'])) {
    $requisition_id = isset($_GET['requisition_id']) ? $_GET['requisition_id'] : $_POST['requisition_id'];
    $conn = connectDB();

    // Fetch requisition details
    $sql_req = "SELECT r.*, u.name as requested_by_name, d.name as department_name FROM requisitions r JOIN users u ON r.requested_by = u.id JOIN departments d ON r.department_id = d.id WHERE r.id = ?";
    $stmt_req = $conn->prepare($sql_req);
    $stmt_req->bind_param("i", $requisition_id);
    $stmt_req->execute();
    $result_req = $stmt_req->get_result();

    if ($result_req->num_rows > 0) {
        $requisition = $result_req->fetch_assoc();

        // Fetch requisition items
        $sql_items = "SELECT ri.*, i.item_description FROM requisition_items ri JOIN items i ON ri.item_id = i.id WHERE ri.requisition_id = ?";
        $stmt_items = $conn->prepare($sql_items);
        $stmt_items->bind_param("i", $requisition_id);
        $stmt_items->execute();
        $result_items = $stmt_items->get_result();
        while ($row = $result_items->fetch_assoc()) {
            $requisition_items[] = $row;
        }
        $stmt_items->close();

        // Fetch active suppliers for the dropdown
        $sql_suppliers = "SELECT id, name FROM suppliers WHERE status = 'active'";
        $result_suppliers = $conn->query($sql_suppliers);
        while ($row = $result_suppliers->fetch_assoc()) {
            $suppliers[] = $row;
        }
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Purchase Order</title>
</head>
<body>
    <h2>Create Purchase Order</h2>
    <a href="requisitions.php">Back to Requisitions</a>
    <hr>
    <?php if (isset($message)) { ?>
        <p><strong><?php echo htmlspecialchars($message); ?></strong></p>
    <?php } ?>

    <?php if ($requisition) { ?>
        <h3>Requisition Details</h3>
        <p><strong>Requisition #:</strong> <?php echo htmlspecialchars($requisition['requisition_no']); ?></p>
        <p><strong>Title:</strong> <?php echo htmlspecialchars($requisition['title']); ?></p>
        <p><strong>Total Amount:</strong> $<?php echo htmlspecialchars(number_format($requisition['total_amount'], 2)); ?></p>
        <p><strong>Requested By:</strong> <?php echo htmlspecialchars($requisition['requested_by_name']); ?></p>
        <p><strong>Department:</strong> <?php echo htmlspecialchars($requisition['department_name']); ?></p>
        <p><strong>Justification:</strong> <?php echo htmlspecialchars($requisition['justification']); ?></p>
        <h4>Items:</h4>
        <ul>
            <?php foreach ($requisition_items as $item) { ?>
                <li><?php echo htmlspecialchars($item['item_description']); ?> (Qty: <?php echo htmlspecialchars($item['quantity']); ?>, Cost: $<?php echo htmlspecialchars(number_format($item['estimated_cost'], 2)); ?>)</li>
            <?php } ?>
        </ul>
    </div>

    <form action="create_po.php" method="post">
        <input type="hidden" name="requisition_id" value="<?php echo htmlspecialchars($requisition['id']); ?>">
        <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($requisition['total_amount']); ?>">
        
        <label for="supplier_id">Select Supplier:</label><br>
        <select name="supplier_id" id="supplier_id" required>
            <?php foreach ($suppliers as $supplier) { ?>
                <option value="<?php echo htmlspecialchars($supplier['id']); ?>"><?php echo htmlspecialchars($supplier['name']); ?></option>
            <?php } ?>
        </select><br><br>
        
        <input type="submit" value="Generate Purchase Order">
    </form>
    <?php } else { ?>
        <p>No valid requisition found.</p>
    <?php } ?>
</body>
</html>