<?php
session_start();
require_once 'users.php';

// Establish a database connection
$conn = connectDB();

// Check if user is logged in and is an Admin (role_id = 1)
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    header("location: dashboard.php");
    exit;
}

// Handle form submission for editing the contract
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_contract'])) {
    $id = $_POST['contract_id'];
    $supplier_id = $_POST['supplier_id'];
    $contract_no = $_POST['contract_no'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $value = $_POST['value'];
    
    $sql = "UPDATE contracts SET supplier_id=?, contract_no=?, start_date=?, end_date=?, value=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssdi", $supplier_id, $contract_no, $start_date, $end_date, $value, $id);
    
    if ($stmt->execute()) {
        $message = "Contract updated successfully!";
    } else {
        $message = "Error: " . $stmt->error;
    }
}

// Fetch contract data based on the ID from the URL
$contract_data = null;
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM contracts WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $contract_data = $result->fetch_assoc();
    
    if (!$contract_data) {
        $message = "Contract not found!";
    }
} else {
    $message = "No contract ID specified!";
}

// Fetch all suppliers to populate the dropdown menu
$suppliers_result = $conn->query("SELECT id, name FROM suppliers ORDER BY name ASC");
$suppliers_options = "";
while ($row = $suppliers_result->fetch_assoc()) {
    $selected = ($contract_data && $row['id'] == $contract_data['supplier_id']) ? 'selected' : '';
    $suppliers_options .= "<option value='{$row['id']}' {$selected}>{$row['name']}</option>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Contract</title>
</head>
<body>
    <h2>Edit Contract</h2>
    <a href="manage_contracts.php">Back to Manage Contracts</a>
    
    <?php if (isset($message)) { echo "<p><strong>" . $message . "</strong></p>"; } ?>

    <?php if ($contract_data) { ?>
        <hr>
        <form method="post" action="edit_contract.php">
            <input type="hidden" name="contract_id" value="<?php echo htmlspecialchars($contract_data['id']); ?>">
            
            <label for="supplier_id">Supplier:</label>
            <select name="supplier_id" required>
                <?php echo $suppliers_options; ?>
            </select><br><br>
            
            <label for="contract_no">Contract Number:</label>
            <input type="text" name="contract_no" value="<?php echo htmlspecialchars($contract_data['contract_no']); ?>" required><br><br>

            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" value="<?php echo htmlspecialchars($contract_data['start_date']); ?>" required><br><br>
            
            <label for="end_date">End Date:</label>
            <input type="date" name="end_date" value="<?php echo htmlspecialchars($contract_data['end_date']); ?>" required><br><br>
            
            <label for="value">Value:</label>
            <input type="number" step="0.01" name="value" value="<?php echo htmlspecialchars($contract_data['value']); ?>" required><br><br>
            
            <input type="submit" name="update_contract" value="Update Contract">
        </form>
    <?php } ?>

</body>
</html>