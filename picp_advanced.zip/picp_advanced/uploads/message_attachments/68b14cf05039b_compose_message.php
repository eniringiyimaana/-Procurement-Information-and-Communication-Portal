<?php
session_start();
require_once 'users.php';


if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

$message = '';
$users = [];
$suppliers = [];
$conn = connectDB();

// Directory where files will be uploaded
$upload_dir = 'uploads/message_attachments/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Fetch all internal users to populate the recipient dropdown
$sql_users = "SELECT id, name FROM users WHERE id != ?";
$stmt_users = $conn->prepare($sql_users);
$stmt_users->bind_param("i", $_SESSION['user_id']);
$stmt_users->execute();
$result_users = $stmt_users->get_result();
while ($row = $result_users->fetch_assoc()) {
    $users[] = $row;
}
$stmt_users->close();

// Fetch all suppliers to populate the recipient dropdown
$sql_suppliers = "SELECT id, name FROM suppliers";
$result_suppliers = $conn->query($sql_suppliers);
while ($row = $result_suppliers->fetch_assoc()) {
    $suppliers[] = $row;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recipient_info = explode('_', $_POST['recipient']);
    $recipient_type = $recipient_info[0];
    $recipient_id = $recipient_info[1];
    $subject = $_POST['subject'];
    $message_body = $_POST['message_body'];
    $sender_id = $_SESSION['user_id'];
    $sent_at = date('Y-m-d H:i:s');
    
    $conn->begin_transaction();

    try {
        if ($recipient_type == 'user') {
            $sql = "INSERT INTO inbox (sender_id, recipient_id, subject, message_body, sent_at) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Error preparing user message statement: " . $conn->error);
            $stmt->bind_param("iisss", $sender_id, $recipient_id, $subject, $message_body, $sent_at);
            $stmt->execute();
            $message_id = $stmt->insert_id;
            $stmt->close();
        } elseif ($recipient_type == 'supplier') {
            $sql = "INSERT INTO supplier_inbox (sender_user_id, recipient_supplier_id, subject, message_body, sent_at) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Error preparing supplier message statement: " . $conn->error);
            $stmt->bind_param("iisss", $sender_id, $recipient_id, $subject, $message_body, $sent_at);
            $stmt->execute();
            $message_id = $stmt->insert_id;
            $stmt->close();
        } else {
            throw new Exception("Invalid recipient type.");
        }
        
        // Handle file upload
        if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
            $file_name = $_FILES['attachment']['name'];
            $file_tmp_name = $_FILES['attachment']['tmp_name'];
            $new_file_name = uniqid() . '_' . $file_name;
            $file_path = $upload_dir . $new_file_name;

            if (move_uploaded_file($file_tmp_name, $file_path)) {
                $sql_attach = "INSERT INTO message_attachments (message_id, file_name, file_path) VALUES (?, ?, ?)";
                $stmt_attach = $conn->prepare($sql_attach);
                if (!$stmt_attach) throw new Exception("Attachment insert failed: " . $conn->error);
                $stmt_attach->bind_param("iss", $message_id, $file_name, $file_path);
                $stmt_attach->execute();
                $stmt_attach->close();
            } else {
                throw new Exception("Failed to move uploaded file.");
            }
        }

        $conn->commit();
        $message = "Message sent successfully!";

    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error sending message: " . $e->getMessage();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Compose Message</title>
</head>
<body>
    <h2>Compose New Message</h2>
    <p><?php echo htmlspecialchars($message); ?></p>
    
    <form action="compose_message.php" method="post" enctype="multipart/form-data">
        <label for="recipient">To:</label><br>
        <select id="recipient" name="recipient" required>
            <optgroup label="Internal Staff">
                <?php foreach ($users as $user) { ?>
                    <option value="user_<?php echo htmlspecialchars($user['id']); ?>"><?php echo htmlspecialchars($user['name']); ?></option>
                <?php } ?>
            </optgroup>
            <optgroup label="Suppliers">
                <?php foreach ($suppliers as $supplier) { ?>
                    <option value="supplier_<?php echo htmlspecialchars($supplier['id']); ?>"><?php echo htmlspecialchars($supplier['name']); ?></option>
                <?php } ?>
            </optgroup>
        </select><br><br>

        <label for="subject">Subject:</label><br>
        <input type="text" id="subject" name="subject" required><br><br>

        <label for="message_body">Message:</label><br>
        <textarea id="message_body" name="message_body" rows="10" cols="50" required></textarea><br><br>
        
        <label for="attachment">Attachment:</label><br>
        <input type="file" id="attachment" name="attachment"><br><br>

        <input type="submit" value="Send Message">
    </form>
</body>
</html>