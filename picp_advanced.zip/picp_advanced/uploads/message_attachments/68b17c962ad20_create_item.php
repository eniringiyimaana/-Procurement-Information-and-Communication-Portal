<?php
session_start();
require_once 'users.php'; // Reuse the database connection

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

$message = '';
$gl_accounts = [];
$spend_categories = [];

$conn = connectDB();

// Fetch GL accounts for the form dropdown
$sql_gl = "SELECT id, CONCAT(account_no, ' - ', account_name) AS display_name FROM gl_accounts ORDER BY account_no ASC";
$gl_result = $conn->query($sql_gl);
if ($gl_result) {
    while ($row = $gl_result->fetch_assoc()) {
        $gl_accounts[] = $row;
    }
}

// Fetch spend categories for the form dropdown
$sql_sc = "SELECT id, name FROM spend_categories ORDER BY name ASC";
$sc_result = $conn->query($sql_sc);
if ($sc_result) {
    while ($row = $sc_result->fetch_assoc()) {
        $spend_categories[] = $row;
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_item'])) {
    $item_description = $_POST['item_description'];
    $unit_of_measure = $_POST['unit_of_measure'];
    $gl_account_id = $_POST['gl_account_id'];
    $spend_category_id = $_POST['spend_category_id'];

    if (empty($item_description) || empty($unit_of_measure) || empty($gl_account_id) || empty($spend_category_id)) {
        $message = "Please fill in all required fields.";
    } else {
        $sql = "INSERT INTO items (item_description, unit_of_measure, gl_account_id, spend_category_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        
        if ($stmt === false) {
            $message = "Error preparing statement: " . $conn->error;
        } else {
            $stmt->bind_param("ssii", $item_description, $unit_of_measure, $gl_account_id, $spend_category_id);
            if ($stmt->execute()) {
                $message = "Item '{$item_description}' added successfully!";
            } else {
                $message = "Error adding item: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create New Item</title>
    <style>
        body { font-family: sans-serif; }
        .container { max-width: 600px; margin: auto; padding: 20px; }
        input, select { width: 100%; padding: 8px; margin-bottom: 10px; }
        button { padding: 10px 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Create New Item</h2>
        <a href="dashboard.php">Back to Dashboard</a>
        <br><br>

        <?php if (!empty($message)) { echo "<p><strong>" . htmlspecialchars($message) . "</strong></p>"; } ?>
        
        <form method="post" action="create_item.php">
            <label for="item_description">Item Description:</label>
            <input type="text" id="item_description" name="item_description" required><br>

            <label for="unit_of_measure">Unit of Measure:</label>
            <input type="text" id="unit_of_measure" name="unit_of_measure" required><br>

            <label for="gl_account_id">GL Account:</label>
            <select id="gl_account_id" name="gl_account_id" required>
                <?php foreach ($gl_accounts as $account) { ?>
                    <option value="<?php echo htmlspecialchars($account['id']); ?>">
                        <?php echo htmlspecialchars($account['display_name']); ?>
                    </option>
                <?php } ?>
            </select><br>

            <label for="spend_category_id">Spend Category:</label>
            <select id="spend_category_id" name="spend_category_id" required>
                <?php foreach ($spend_categories as $category) { ?>
                    <option value="<?php echo htmlspecialchars($category['id']); ?>">
                        <?php echo htmlspecialchars($category['name']); ?>
                    </option>
                <?php } ?>
            </select><br>

            <button type="submit" name="create_item">Add Item</button>
        </form>
    </div>
</body>
</html>