<?php
session_start();
require_once 'users.php';

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

$user_role_id = $_SESSION['role_id'];

// Get the role name for display purposes
$role_name = getUserRoleName($user_role_id);
$_SESSION['role_name'] = $role_name;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h2>
    <p>Your role: <?php echo htmlspecialchars($_SESSION['role_name']); ?></p>
    <p>This is your personalized dashboard. Use the links below to navigate the system.</p>

    <div style="margin-top: 20px;">
        <h3>General Actions</h3>
        <ul>
            <li><a href="create_requisition.php">Create New Requisition</a></li>
            <li><a href="view_my_requisitions.php">View My Requisitions</a></li>
        </ul>
    </div>
    
    <div style="margin-top: 20px;">
        <h3>User Account</h3>
        <ul>
            <li><a href="profile.php">My Profile</a></li>
            <li><a href="settings.php">Settings</a></li>
        </ul>
    </div>

    <div style="margin-top: 20px;">
        <h3>Messaging & Notifications</h3>
        <ul>
            <li><a href="inbox.php">Inbox</a></li>
            <li><a href="compose_message.php">Compose Message</a></li>
            <li><a href="notifications.php">My Notifications</a></li>
        </ul>
    </div>
    
    <?php if ($user_role_id == 2) { // Procurement/Finance Officer ?>
        <div style="margin-top: 20px;">
            <h3>Procurement & Finance</h3>
            <ul>
                <li><a href="approve_requisitions.php">Approve Requisitions</a></li>
                <li><a href="create_po.php">Create Purchase Order</a></li>
                <li><a href="manage_pos.php">Manage Purchase Orders</a></li>
                <li><a href="process_invoice.php">Process Invoice</a></li>
                <li><a href="manage_invoices.php">Manage Invoices</a></li>
                <li><a href="manage_payments.php">Manage Payments</a></li>
                <li><a href="goods_receipt.php">Goods Receipt (GRN)</a></li>
            </ul>
        </div>
    <?php } ?>

    <?php if ($user_role_id == 1) { // Admin only ?>
        <div style="margin-top: 20px;">
            <h3>System Administration</h3>
            <ul>
                <li><a href="manage_users.php">Manage Users</a></li>
                <li><a href="manage_suppliers.php">Manage Suppliers</a></li>
                <li><a href="manage_items.php">Manage Inventory Items</a></li>
                <li><a href="manage_gl_accounts.php">Manage GL Accounts</a></li>
                <li><a href="manage_spend_categories.php">Manage Spend Categories</a></li>
                <li><a href="manage_budgets.php">Manage Budgets</a></li>
            </ul>
        </div>
    <?php } ?>
    
    <div style="margin-top: 20px;">
        <h3>Reports</h3>
        <ul>
            <?php if ($user_role_id == 1 || $user_role_id == 2) { // Admin or Procurement/Finance Officer ?>
                <li><a href="invoice_report.php">Invoice & Payment Report</a></li>
                <li><a href="spend_analysis.php">Spend Analysis Report</a></li>
            <?php } ?>
        </ul>
    </div>

    <div style="margin-top: 20px;">
        <p><a href="logout.php">Logout</a></p>
    </div>
</body>
</html>