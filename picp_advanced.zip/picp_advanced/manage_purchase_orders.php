<?php
session_start();
require_once 'users.php';

// ✅ Check login
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$conn = connectDB();

// ✅ Fetch all purchase orders with supplier + requisition details
$sql = "
    SELECT po.*, s.name AS supplier_name, r.requisition_no, r.title AS requisition_title
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.supplier_id = s.id
    LEFT JOIN requisitions r ON po.requisition_id = r.id
    ORDER BY po.created_at DESC
";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Purchase Orders | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-issued {
            background-color: #17a2b8;
            color: white;
        }
        
        .status-in_transit {
            background-color: #ffc107;
            color: #212529;
        }
        
        .status-fulfilled {
            background-color: #28a745;
            color: white;
        }
        
        .status-invoiced {
            background-color: #6f42c1;
            color: white;
        }
        
        .status-paid {
            background-color: #20c997;
            color: white;
        }
        
        .status-closed {
            background-color: #6c757d;
            color: white;
        }
        
        .po-amount {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .action-buttons .btn {
            margin-right: 5px;
            border-radius: 5px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_invoices.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Manage Invoices</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_payments.php">
                    <i class="fas fa-money-check"></i>
                    <span>Manage Payments</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link active" href="manage_purchase_orders.php">
                    <i class="fas fa-file-purchase-order"></i>
                    <span>Purchase Orders</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage Purchase Orders</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Purchase Orders Content -->
        <div class="container-fluid">
            <!-- Purchase Order Statistics -->
            <?php
            $total_pos = $result->num_rows;
            $issued_count = 0;
            $in_transit_count = 0;
            $fulfilled_count = 0;
            $invoiced_count = 0;
            $paid_count = 0;
            $closed_count = 0;
            $total_amount = 0;
            
            if ($result->num_rows > 0) {
                $result->data_seek(0);
                while($row = $result->fetch_assoc()) {
                    $total_amount += $row['total_amount'];
                    switch($row['status']) {
                        case 'issued': $issued_count++; break;
                        case 'in_transit': $in_transit_count++; break;
                        case 'fulfilled': $fulfilled_count++; break;
                        case 'invoiced': $invoiced_count++; break;
                        case 'paid': $paid_count++; break;
                        case 'closed': $closed_count++; break;
                    }
                }
                $result->data_seek(0);
            }
            ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary"><?php echo $total_pos; ?></div>
                        <div class="stats-label">Total POs</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success">$<?php echo number_format($total_amount, 2); ?></div>
                        <div class="stats-label">Total Value</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-info"><?php echo $issued_count; ?></div>
                        <div class="stats-label">Issued POs</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-warning"><?php echo $in_transit_count; ?></div>
                        <div class="stats-label">In Transit</div>
                    </div>
                </div>
            </div>

            <!-- Purchase Orders Table -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-file-purchase-order me-2"></i>All Purchase Orders</span>
                    <span class="badge bg-light text-dark"><?php echo $total_pos; ?> orders</span>
                </div>
                <div class="card-body">
                    <?php if ($result->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>PO No</th>
                                    <th>Requisition</th>
                                    <th>Supplier</th>
                                    <th>Total Amount</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($row['po_no']) ?></strong>
                                    </td>
                                    <td><?= htmlspecialchars($row['requisition_no']) ?> - <?= htmlspecialchars($row['requisition_title']) ?></td>
                                    <td><?= htmlspecialchars($row['supplier_name']) ?></td>
                                    <td class="po-amount">$<?= number_format($row['total_amount'], 2) ?></td>
                                    <td>
                                        <span class="status-badge status-<?= $row['status'] ?>">
                                            <?= ucfirst($row['status']) ?>
                                        </span>
                                    </td>
                                    <td><?= date('M j, Y', strtotime($row['created_at'])) ?></td>
                                    <td class="action-buttons">
                                        <a href="print_po.php?po_id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-secondary" target="_blank" title="Print PO">
                                            <i class="fas fa-print"></i>
                                        </a>
                                        <a href="http://localhost/picp_advanced/compose_message.php" class="btn btn-sm btn-outline-success" title="Send Message">
                                            <i class="fas fa-paper-plane"></i>
                                        </a>
                                        <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2): ?>
                                        
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-file-invoice fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No Purchase Orders</h4>
                        <p class="text-muted">There are no purchase orders in the system yet.</p>
                        <a href="create_po.php" class="btn btn-primary mt-2">
                            <i class="fas fa-plus me-1"></i> Create Purchase Order
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>