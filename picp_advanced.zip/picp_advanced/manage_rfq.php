<?php
session_start();
require_once 'users.php';

// Check if the user is a Procurement Officer
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 2) {
    header("location: index.php");
    exit;
}

$conn = connectDB();
$rfqs = [];
$message = isset($_GET['message']) ? $_GET['message'] : '';

// Fetch all RFQs with their associated requisition details, including the total estimated cost
$sql = "SELECT r.*, rq.title as requisition_title, rq.total_estimated_cost
        FROM rfqs r
        JOIN requisitions rq ON r.requisition_id = rq.id
        ORDER BY r.created_at DESC";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $rfqs[] = $row;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage RFQs | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-draft {
            background-color: #6c757d;
            color: white;
        }
        
        .status-published {
            background-color: #17a2b8;
            color: white;
        }
        
        .status-closed {
            background-color: #6f42c1;
            color: white;
        }
        
        .status-evaluating {
            background-color: #ffc107;
            color: #212529;
        }
        
        .status-awarded {
            background-color: #28a745;
            color: white;
        }
        
        .status-cancelled {
            background-color: #dc3545;
            color: white;
        }
        
        .rfq-amount {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #495057;
            background-color: #f8f9fa;
        }
        
        .action-buttons .btn {
            margin-right: 5px;
            border-radius: 5px;
        }
        
        .due-date {
            font-weight: 500;
        }
        
        .due-date.overdue {
            color: #dc3545;
            font-weight: 600;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2 || $_SESSION['role_id'] == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link active" href="manage_rfq.php">
                    <i class="fas fa-file-contract"></i>
                    <span>Manage RFQs</span>
                </a>
            </li>
            <?php if ($_SESSION['role_id'] == 1 || $_SESSION['role_id'] == 2) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_invoices.php">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Manage Invoices</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="manage_payments.php">
                    <i class="fas fa-money-check"></i>
                    <span>Manage Payments</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($_SESSION['role_id'] == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Manage RFQs</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- RFQs Content -->
        <div class="container-fluid">
            <!-- Alert Message -->
            <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- RFQ Statistics -->
            <?php
            $total_rfqs = count($rfqs);
            $draft_count = 0;
            $published_count = 0;
            $closed_count = 0;
            $evaluating_count = 0;
            $awarded_count = 0;
            $cancelled_count = 0;
            $total_value = 0;
            
            foreach ($rfqs as $rfq) {
                $total_value += $rfq['total_estimated_cost'];
                switch($rfq['status']) {
                    case 'draft': $draft_count++; break;
                    case 'published': $published_count++; break;
                    case 'closed': $closed_count++; break;
                    case 'evaluating': $evaluating_count++; break;
                    case 'awarded': $awarded_count++; break;
                    case 'cancelled': $cancelled_count++; break;
                }
            }
            ?>
            <div class="row mb-4">
                <div class="col-md-2">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-primary"><?php echo $total_rfqs; ?></div>
                        <div class="stats-label">Total RFQs</div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success">$<?php echo number_format($total_value, 2); ?></div>
                        <div class="stats-label">Total Value</div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-info"><?php echo $published_count; ?></div>
                        <div class="stats-label">Published</div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-warning"><?php echo $evaluating_count; ?></div>
                        <div class="stats-label">Evaluating</div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="dashboard-card stats-card">
                        <div class="stats-number text-success"><?php echo $awarded_count; ?></div>
                        <div class="stats-label">Awarded</div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="dashboard-card stats-card">
                        <a href="create_rfq.php" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i> New RFQ
                        </a>
                    </div>
                </div>
            </div>

            <!-- RFQs Table -->
            <div class="dashboard-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-file-contract me-2"></i>All Request for Quotations</span>
                    <span class="badge bg-light text-dark"><?php echo $total_rfqs; ?> RFQs</span>
                </div>
                <div class="card-body">
                    <?php if (count($rfqs) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>RFQ No.</th>
                                    <th>Title</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                    <th>Requisition Amount</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rfqs as $rfq): 
                                    $due_date = new DateTime($rfq['due_date']);
                                    $today = new DateTime();
                                    $is_overdue = $due_date < $today && $rfq['status'] != 'awarded' && $rfq['status'] != 'cancelled';
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($rfq['rfq_no']); ?></strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($rfq['title']); ?></td>
                                    <td class="due-date <?php echo $is_overdue ? 'overdue' : ''; ?>">
                                        <?php echo date('M j, Y', strtotime($rfq['due_date'])); ?>
                                        <?php if ($is_overdue): ?>
                                            <span class="badge bg-danger ms-1"></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo $rfq['status']; ?>">
                                            <?php echo ucfirst($rfq['status']); ?>
                                        </span>
                                    </td>
                                    <td class="rfq-amount">$<?php echo number_format($rfq['total_estimated_cost'], 2); ?></td>
                                    <td class="action-buttons">
                                        
                                        <?php if ($rfq['status'] == 'awarded'): ?>
                                            <?php
                                            // Get the accepted proposal's ID to pass to the generate_contract.php script
                                            $conn = connectDB();
                                            $sql_proposal = "SELECT id FROM supplier_proposals WHERE rfq_id = ? AND status = 'accepted'";
                                            $stmt_proposal = $conn->prepare($sql_proposal);
                                            $stmt_proposal->bind_param("i", $rfq['id']);
                                            $stmt_proposal->execute();
                                            $result_proposal = $stmt_proposal->get_result();
                                            $proposal = $result_proposal->fetch_assoc();
                                            $stmt_proposal->close();
                                            $conn->close();
                                            ?>
                                            <?php if ($proposal): ?>
                                                <a href="generate_contract.php?proposal_id=<?php echo htmlspecialchars($proposal['id']); ?>" class="btn btn-sm btn-outline-success" title="Generate Contract" onclick="return confirm('Are you sure you want to generate a contract for the awarded proposal? This will finalize the budget spend.')">
                                                    <i class="fas fa-file-contract"></i>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-file-contract fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No RFQs Created</h4>
                        <p class="text-muted">You haven't created any Request for Quotations yet.</p>
                        <a href="create_rfq.php" class="btn btn-primary mt-2">
                            <i class="fas fa-plus me-1"></i> Create Your First RFQ
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>