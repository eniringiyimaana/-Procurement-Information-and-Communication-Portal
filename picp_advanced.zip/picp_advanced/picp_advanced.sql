-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2025 at 12:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `picp_advanced`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_sessions`
--

CREATE TABLE `active_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `login_time` datetime NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

CREATE TABLE `approvals` (
  `id` int(11) NOT NULL,
  `object_type` enum('requisition','po','invoice','contract') NOT NULL,
  `object_id` int(11) NOT NULL,
  `approver_id` int(11) NOT NULL,
  `decision` enum('pending','approved','rejected') DEFAULT 'pending',
  `comment` text DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `approvals`
--

INSERT INTO `approvals` (`id`, `object_type`, `object_id`, `approver_id`, `decision`, `comment`, `decided_at`, `level`) VALUES
(0, 'requisition', 0, 0, 'approved', 'haaahhaa', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `budgets`
--

CREATE TABLE `budgets` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `fiscal_year` year(4) NOT NULL,
  `allocated_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `committed_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `spent_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `budgets`
--

INSERT INTO `budgets` (`id`, `department_id`, `fiscal_year`, `allocated_amount`, `committed_amount`, `spent_amount`, `created_at`, `updated_at`) VALUES
(2, 3, '2025', 5000.00, 10.00, 0.00, '2025-08-28 15:07:48', '2025-08-29 15:02:14'),
(3, 1, '2025', 20000.00, 10650.00, 0.00, '2025-08-29 14:09:52', '2025-08-30 16:52:59'),
(4, 3, '2025', 0.00, 10.00, 0.00, '2025-08-29 15:17:44', '2025-08-29 15:17:44'),
(5, 3, '2025', 0.00, 10.00, 0.00, '2025-08-29 15:18:26', '2025-08-29 15:18:26'),
(6, 1, '2025', 20000.00, 10612.00, 0.00, '2025-08-29 15:32:51', '2025-08-30 16:52:59'),
(7, 3, '2025', 0.00, 13.00, 0.00, '2025-08-29 15:43:04', '2025-08-29 15:43:04'),
(8, 1, '2025', 20000.00, 16760.00, 0.00, '2025-08-29 17:12:13', '2025-08-30 16:52:59'),
(9, 1, '2025', 20000.00, 16760.00, 0.00, '2025-08-29 18:00:11', '2025-08-30 16:52:59');

-- --------------------------------------------------------

--
-- Table structure for table `contracts`
--

CREATE TABLE `contracts` (
  `id` int(11) NOT NULL,
  `rfq_id` int(11) DEFAULT NULL,
  `contract_no` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `award_date` date NOT NULL,
  `total_value` decimal(15,2) NOT NULL,
  `value` decimal(15,2) NOT NULL,
  `status` enum('active','signed','expired','terminated') NOT NULL DEFAULT 'active',
  `renewal_reminder_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `proposal_id` int(11) DEFAULT NULL,
  `contract_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contracts`
--

INSERT INTO `contracts` (`id`, `rfq_id`, `contract_no`, `supplier_id`, `start_date`, `end_date`, `award_date`, `total_value`, `value`, `status`, `renewal_reminder_date`, `created_at`, `updated_at`, `proposal_id`, `contract_file`) VALUES
(0, 20, 'CON-20250830-1c48d9db', 1, '0000-00-00', '0000-00-00', '2025-08-30', 51000.00, 0.00, 'signed', NULL, '2025-08-30 10:37:29', '2025-08-30 11:19:30', NULL, 'uploads/contracts/contract_68b2b412b5d58_68b2b3431b85c_Print Contract CON-20250830-1c48d9db.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `contract_items`
--

CREATE TABLE `contract_items` (
  `id` int(11) NOT NULL,
  `contract_id` int(11) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_of_measure` varchar(50) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'IT Department', 'Handles all technology-related procurement.', '2025-08-27 14:25:03'),
(2, 'Human Resources', 'Manages procurement for HR and office supplies.', '2025-08-27 14:25:03'),
(3, 'Finance', 'Oversees all financial aspects of procurement.', '2025-08-27 14:25:03'),
(4, 'Marketing', 'Manages all marketing and campaign-related procurement.', '2025-08-27 14:25:03');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `object_type` enum('requisition','po','invoice','supplier','contract') NOT NULL,
  `object_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gl_accounts`
--

CREATE TABLE `gl_accounts` (
  `id` int(11) NOT NULL,
  `account_no` int(11) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `account_type` enum('Asset','Liability','Equity','Revenue','Expense') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gl_accounts`
--

INSERT INTO `gl_accounts` (`id`, `account_no`, `account_name`, `account_type`) VALUES
(1, 1000, 'Cash', 'Asset'),
(2, 1100, 'Accounts Receivable', 'Asset'),
(3, 1200, 'Prepaid Expenses', 'Asset'),
(4, 2000, 'Accounts Payable', 'Liability'),
(5, 2100, 'Accrued Expenses', 'Liability'),
(6, 3000, 'Retained Earnings', 'Equity'),
(7, 4000, 'Sales Revenue', 'Revenue'),
(8, 5000, 'Cost of Goods Sold', 'Expense'),
(9, 6000, 'Salaries and Wages', 'Expense'),
(10, 6100, 'Rent Expense', 'Expense'),
(11, 6200, 'Utilities Expense', 'Expense'),
(12, 6300, 'Office Supplies Expense', 'Expense');

-- --------------------------------------------------------

--
-- Table structure for table `goods_receipts`
--

CREATE TABLE `goods_receipts` (
  `id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `received_by` int(11) NOT NULL,
  `receipt_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grn_items`
--

CREATE TABLE `grn_items` (
  `id` int(11) NOT NULL,
  `grn_id` int(11) NOT NULL,
  `po_item_id` int(11) NOT NULL,
  `received_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE `inbox` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message_body` text NOT NULL,
  `status` enum('unread','read') NOT NULL DEFAULT 'unread',
  `sent_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inbox`
--

INSERT INTO `inbox` (`id`, `sender_id`, `recipient_id`, `subject`, `message_body`, `status`, `sent_at`) VALUES
(1, 1, 3, 'Testing', 'ssff', 'read', '2025-08-28 12:14:22');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity_on_hand` int(11) NOT NULL DEFAULT 0,
  `last_updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `purchase_order_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `status` enum('submitted','verified','approved','paid','overdue','cancelled') NOT NULL DEFAULT 'submitted',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `invoice_no`, `purchase_order_id`, `supplier_id`, `invoice_date`, `due_date`, `amount`, `status`, `created_at`) VALUES
(0, 'PO-20250830-Invoice', 1, 1, '2025-08-30', '2025-08-31', 5600.00, 'paid', '2025-08-30 15:37:16');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `gl_account_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `invoice_id`, `item_description`, `quantity`, `unit_price`, `gl_account_id`) VALUES
(1, 0, 'Laptop Dell Inspiron', 2, 2000.00, 1),
(2, 0, 'Wireless Mouse', 5, 100.00, 1),
(3, 0, 'Office Chair', 2, 550.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `spend_category_id` int(11) DEFAULT NULL,
  `gl_account_id` int(11) NOT NULL,
  `unit_of_measure` varchar(50) DEFAULT NULL,
  `current_stock` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `item_description`, `spend_category_id`, `gl_account_id`, `unit_of_measure`, `current_stock`, `created_at`) VALUES
(2, 'N/A', 2, 1, '1', 0, '2025-08-27 13:15:34'),
(3, 'Demo', 2, 1, '1', 1, '2025-08-28 12:15:38'),
(4, 'Printer Paper', 2, 12, 'Ream', 0, '2025-08-30 13:18:24'),
(5, 'Ink Cartridges', 2, 12, 'Peice', 0, '2025-08-30 13:21:16'),
(6, 'Toner Cartridge', 2, 12, 'Peice', 0, '2025-08-30 13:29:38');

-- --------------------------------------------------------

--
-- Table structure for table `item_catalog`
--

CREATE TABLE `item_catalog` (
  `id` int(11) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `unit_of_measure` varchar(50) DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `preferred_supplier_id` int(11) DEFAULT NULL,
  `spend_category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`, `address`, `city`, `country`) VALUES
(1, 'Main Headquarters', '123 Business Blvd', 'Capital City', NULL),
(2, 'Regional Office North', '456 Tech Lane', 'Techville', NULL),
(3, 'Warehouse', '789 Industrial Drive', 'Portside', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `sent_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `message_attachments`
--

CREATE TABLE `message_attachments` (
  `id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `message_attachments`
--

INSERT INTO `message_attachments` (`id`, `message_id`, `file_name`, `file_path`, `uploaded_at`) VALUES
(1, 4, 'supplier_inbox.sql', 'uploads/message_attachments/68b146bf40635_supplier_inbox.sql', '2025-08-29 09:20:47'),
(2, 5, 'supplier_inbox.sql', 'uploads/message_attachments/68b14cd9a37fd_supplier_inbox.sql', '2025-08-29 09:46:49'),
(3, 6, 'compose_message.php', 'uploads/message_attachments/68b14cf05039b_compose_message.php', '2025-08-29 09:47:12'),
(4, 7, 'create_requisition.php', 'uploads/message_attachments/68b15ce723afe_create_requisition.php', '2025-08-29 10:55:19'),
(5, 8, 'create_requisition.php', 'uploads/message_attachments/68b15d4de76a2_create_requisition.php', '2025-08-29 10:57:01'),
(6, 9, 'edit_contract.php', 'uploads/message_attachments/68b1655c6fe99_edit_contract.php', '2025-08-29 11:31:24'),
(7, 10, 'create_po.php', 'uploads/message_attachments/68b17c4f56a8a_create_po.php', '2025-08-29 13:09:19'),
(10, 13, 'Print Contract CON-20250830-1c48d9db.pdf', 'uploads/message_attachments/68b2b3431b85c_Print Contract CON-20250830-1c48d9db.pdf', '2025-08-30 11:16:03'),
(11, 14, 'Print Purchase Order PO-20250830-68b2bd5b702c5.pdf', 'uploads/message_attachments/68b2d4487eca9_Print Purchase Order PO-20250830-68b2bd5b702c5.pdf', '2025-08-30 13:36:56');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `payment_date` datetime NOT NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `invoice_id`, `payment_date`, `amount`, `payment_method`, `reference_no`) VALUES
(0, 0, '2025-08-30 16:39:25', 5600.00, 'Bank Transfer', '100202039393949');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `po_items`
--

CREATE TABLE `po_items` (
  `id` int(11) NOT NULL,
  `purchase_order_id` int(11) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_of_measure` varchar(50) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `received_qty` int(11) NOT NULL DEFAULT 0,
  `spend_category_id` int(11) DEFAULT NULL,
  `gl_account_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `po_items`
--

INSERT INTO `po_items` (`id`, `purchase_order_id`, `item_description`, `quantity`, `unit_of_measure`, `unit_price`, `received_qty`, `spend_category_id`, `gl_account_id`) VALUES
(5, 1, 'Laptop Dell Inspiron', 2, 'pcs', 2000.00, 0, 1, 1),
(6, 1, 'Wireless Mouse', 5, 'pcs', 100.00, 0, 1, 1),
(7, 1, 'Office Chair', 2, 'pcs', 550.00, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL,
  `po_no` varchar(50) NOT NULL,
  `requisition_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `status` enum('draft','issued','in_transit','fulfilled','invoiced','paid','closed') NOT NULL DEFAULT 'draft',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `po_no`, `requisition_id`, `supplier_id`, `total_amount`, `status`, `created_at`, `updated_at`) VALUES
(1, 'PO-20250830-68b2bd5b702c5', 17, 1, 5600.00, 'invoiced', '2025-08-30 11:59:07', '2025-08-30 15:37:16');

-- --------------------------------------------------------

--
-- Table structure for table `requisitions`
--

CREATE TABLE `requisitions` (
  `id` int(11) NOT NULL,
  `requisition_no` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `justification` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `requested_by` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `status` enum('draft','pending_approval','approved','rejected','processed','paid') DEFAULT 'pending_approval',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total_estimated_cost` decimal(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requisitions`
--

INSERT INTO `requisitions` (`id`, `requisition_no`, `title`, `justification`, `created_by`, `requested_by`, `department_id`, `total_amount`, `status`, `created_at`, `updated_at`, `total_estimated_cost`) VALUES
(17, 'REQ-2025-08-30-ac723e83', '- IT Department Computer Upgrade', '- IT Department Computer Upgrade', 1, 5, 1, 5600.00, '', '2025-08-30 11:56:41', '2025-08-30 11:59:07', 5600.00);

-- --------------------------------------------------------

--
-- Table structure for table `requisition_items`
--

CREATE TABLE `requisition_items` (
  `id` int(11) NOT NULL,
  `requisition_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_description` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_of_measure` varchar(50) NOT NULL,
  `estimated_cost` decimal(15,2) DEFAULT NULL,
  `spend_category_id` int(11) DEFAULT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requisition_items`
--

INSERT INTO `requisition_items` (`id`, `requisition_id`, `item_id`, `item_description`, `quantity`, `unit_of_measure`, `estimated_cost`, `spend_category_id`, `gl_account_id`, `created_at`) VALUES
(20, 17, 3, '', 2, '', 5600.00, NULL, 1, '2025-08-30 11:56:41');

-- --------------------------------------------------------

--
-- Table structure for table `rfqs`
--

CREATE TABLE `rfqs` (
  `id` int(11) NOT NULL,
  `rfq_no` varchar(50) NOT NULL,
  `requisition_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `publish_date` datetime NOT NULL DEFAULT current_timestamp(),
  `due_date` datetime NOT NULL,
  `status` enum('draft','published','closed','awarded') NOT NULL DEFAULT 'draft',
  `awarded_proposal_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rfqs`
--

INSERT INTO `rfqs` (`id`, `rfq_no`, `requisition_id`, `title`, `publish_date`, `due_date`, `status`, `awarded_proposal_id`, `created_by`, `created_at`) VALUES
(1, 'RFQ-20250828-68b0036393588', 1, '45', '2025-08-28 10:21:07', '2025-08-28 10:20:00', 'published', NULL, 1, '2025-08-28 10:21:07'),
(2, 'RFQ-20250828-68b01e33bd27e', 2, 'fhhhg', '2025-08-28 12:15:31', '2025-08-28 00:00:00', 'published', NULL, 3, '2025-08-28 12:15:31'),
(3, 'RFQ-20250828-68b020c81918c', 1, '567', '2025-08-28 12:26:32', '2025-08-28 00:00:00', 'published', NULL, 3, '2025-08-28 12:26:32'),
(4, 'RFQ-20250828-68b0225030757', 1, '5678', '2025-08-28 12:33:04', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 12:33:04'),
(5, 'RFQ-20250828-68b0237730c3b', 2, '345', '2025-08-28 12:37:59', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 12:37:59'),
(6, 'RFQ-20250828-68b029be8c5a3', 2, 'rti', '2025-08-28 13:04:46', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 13:04:46'),
(7, 'RFQ-20250828-68b02c4c57534', 1, '345y', '2025-08-28 13:15:40', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 13:15:40'),
(8, 'RFQ-20250828-68b0307323c3c', 1, '345', '2025-08-28 13:33:23', '2025-08-28 00:00:00', 'published', NULL, 3, '2025-08-28 13:33:23'),
(9, 'RFQ-20250828-68b0310c867f7', 1, 'qwer', '2025-08-28 13:35:56', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 13:35:56'),
(10, 'RFQ-20250828-68b031a999ec7', 2, 'qwer', '2025-08-28 13:38:33', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 13:38:33'),
(11, 'RFQ-20250828-68b039c17aeec', 2, 'wert', '2025-08-28 14:13:05', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 14:13:05'),
(12, 'RFQ-20250828-68b03cf8693ad', 1, 'as', '2025-08-28 14:26:48', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 14:26:48'),
(16, 'RFQ-20250828-68b0413b2c355', 1, 'ede', '2025-08-28 14:44:59', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 14:44:59'),
(17, 'RFQ-20250828-68b04221df615', 1, 'asd', '2025-08-28 14:48:49', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 14:48:49'),
(18, 'RFQ-20250828-68b0646482306', 1, 'wer', '2025-08-28 17:15:00', '2025-08-29 00:00:00', 'published', NULL, 3, '2025-08-28 17:15:00'),
(19, 'RFQ-20250829-68b1a9ce26882', 10, 'Newone', '2025-08-29 16:23:26', '2025-08-30 00:00:00', 'published', NULL, 5, '2025-08-29 16:23:26'),
(20, 'RFQ-20250830-68b29781eacac', 16, 'IT Department Computer Upgrade', '2025-08-30 09:17:37', '2025-08-31 00:00:00', 'awarded', 5, 5, '2025-08-30 09:17:37'),
(21, 'RFQ-20250830-68b2996e24a24', 16, 'IT Department Computer Upgrade', '2025-08-30 09:25:50', '2025-08-31 00:00:00', 'published', NULL, 5, '2025-08-30 09:25:50'),
(22, 'RFQ-20250830-68b2bd1be6afa', 17, '- IT Department Computer Upgrade', '2025-08-30 11:58:03', '2025-08-31 00:00:00', 'published', NULL, 3, '2025-08-30 11:58:03');

-- --------------------------------------------------------

--
-- Table structure for table `rfq_invites`
--

CREATE TABLE `rfq_invites` (
  `id` int(11) NOT NULL,
  `rfq_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `invited_at` datetime NOT NULL DEFAULT current_timestamp(),
  `token` varchar(255) NOT NULL,
  `status` enum('pending','sent','responded') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rfq_invites`
--

INSERT INTO `rfq_invites` (`id`, `rfq_id`, `supplier_id`, `invited_at`, `token`, `status`) VALUES
(2, 6, 1, '2025-08-28 13:04:46', 'b7a0a1cacf468f83d869537c0160a13582f6385acf34d504467cc2d1d2226c9e', 'sent'),
(3, 7, 1, '2025-08-28 13:15:40', '1d653a58193971ac5cc4573f8bb384ccf76b581f8a9c380c3daf3cb540a80aac', 'sent'),
(4, 8, 1, '2025-08-28 13:33:23', 'dc76051cab0745773062952b64d7a44ca30306de884c91a57ce2caaa6fde78bf', 'responded'),
(5, 9, 1, '2025-08-28 13:35:56', 'f936c14b32a65a7b0e0cadb5c8b12f235588243c3a4ad138873931aa455a4ff9', 'responded'),
(6, 10, 1, '2025-08-28 13:38:33', '3b76c765a48af991ff4a6fa0babbab14cb0ac276fddc53242bade7a8774b6b12', 'sent'),
(7, 11, 1, '2025-08-28 14:13:05', '6b33d2b6157fdf18be0f716ed55022c5a71671ecac25362b670287beb14c56a0', 'sent'),
(8, 12, 2, '2025-08-28 14:26:48', 'ae2ec6e4d8eca4295febc92270ecf937f6c65ee905d3ddadefca8020d11f3087', 'sent'),
(9, 16, 4, '2025-08-28 14:44:59', '838e95df0604c550920446a2372b9827a2cb7d48cbf946442366db93f9a5ca67', 'responded'),
(10, 17, 1, '2025-08-28 14:48:49', '747a1ebf5a1b6821d4f6b9cb23d573b94b0b7da806c6ca03dc5d12e977a26a57', 'sent'),
(11, 18, 4, '2025-08-28 17:15:00', '0db7cf8ee6bc49807190ea8477ff1a17e6655055c770e051a7e5dc50fa62a6a7', 'sent'),
(12, 19, 1, '2025-08-29 16:23:26', 'd79e178256f526977319eba88c604b25355c2a94de9310f1519a815dd5312410', 'sent'),
(13, 20, 1, '2025-08-30 09:17:37', 'e1f6bff079a1ec561f8eda610437f7a74a3c8c0712f901c34b615acc5b13142f', 'sent'),
(14, 21, 1, '2025-08-30 09:25:50', '0d74636e30bab8dd6960f6812dc0c1aacfe34c195bb65e8b882b4162fd069aad', 'pending'),
(15, 22, 1, '2025-08-30 11:58:03', 'd80bcbdd29177352ec8d7715e3e68d491e0e5afa78a12aeda7533e3f772667ae', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `rfq_items`
--

CREATE TABLE `rfq_items` (
  `id` int(11) NOT NULL,
  `rfq_id` int(11) NOT NULL,
  `requisition_item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `estimated_cost` decimal(15,2) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `unit_of_measure` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rfq_items`
--

INSERT INTO `rfq_items` (`id`, `rfq_id`, `requisition_item_id`, `quantity`, `estimated_cost`, `item_description`, `unit_of_measure`) VALUES
(1, 19, 11, 1, 13.00, 'N/A', '1'),
(2, 20, 19, 3, 5000.00, 'Demo', '1'),
(3, 21, 19, 3, 5000.00, 'Demo', '1'),
(4, 22, 20, 2, 5600.00, 'Demo', '1');

-- --------------------------------------------------------

--
-- Table structure for table `rfq_responses`
--

CREATE TABLE `rfq_responses` (
  `id` int(11) NOT NULL,
  `rfq_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `response_date` datetime NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(15,2) NOT NULL,
  `status` enum('submitted','under_review','awarded','rejected') NOT NULL DEFAULT 'submitted',
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rfq_response_items`
--

CREATE TABLE `rfq_response_items` (
  `id` int(11) NOT NULL,
  `rfq_response_id` int(11) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Admin', 'Full access to all system features.', '2025-08-27 14:24:46'),
(2, 'Procurement Officer', 'Manages requisitions, RFQs, and purchase orders.', '2025-08-27 14:24:46'),
(3, 'Finance Officer', 'Manages invoices and payments.', '2025-08-27 14:24:46'),
(4, 'Requisitioner', 'Can create and view their own requisitions.', '2025-08-27 14:24:46');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `spend_categories`
--

CREATE TABLE `spend_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `spend_categories`
--

INSERT INTO `spend_categories` (`id`, `name`, `description`) VALUES
(1, 'IT Equipment', NULL),
(2, 'Office Supplies', NULL),
(3, 'Marketing', NULL),
(4, 'Travel', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `tin` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive','blacklisted') NOT NULL DEFAULT 'active',
  `rating` decimal(3,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `login_token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `contact_email`, `contact_phone`, `address`, `tin`, `status`, `rating`, `created_at`, `login_token`, `token_expiry`) VALUES
(1, 'Tech Solutions Inc.', 'John Smith', 'contact@techsolutions.com', '123-456-7890', '101 Tech Way, Silicon Valley, USA', NULL, 'active', NULL, '2025-08-27 14:48:34', '03037214beb81d82d4436b759aedbac30c79b29459437b45ef07c1624d88c828', '2025-08-28 13:15:31'),
(2, 'Office Supply Co.', 'Jane Doe', 'sales@officesupply.com', '987-654-3210', '202 Business Ave, Metropolis, USA', NULL, 'active', NULL, '2025-08-27 14:48:34', NULL, NULL),
(3, 'Global Logistics Ltd.', 'Chris Evans', 'info@globallogistics.com', '111-222-3333', '303 Warehouse Rd, Portside, USA', NULL, 'active', NULL, '2025-08-27 14:48:34', NULL, NULL),
(4, 'Furniture Experts', 'Sarah Lee', 'sarah@furnitureexperts.com', '444-555-6666', '404 Design Street, Creative City, USA', '123456789', 'active', NULL, '2025-08-27 14:48:34', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_docs`
--

CREATE TABLE `supplier_docs` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `document_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supplier_inbox`
--

CREATE TABLE `supplier_inbox` (
  `id` int(11) NOT NULL,
  `sender_user_id` int(11) DEFAULT NULL,
  `sender_supplier_id` int(11) DEFAULT NULL,
  `recipient_user_id` int(11) DEFAULT NULL,
  `recipient_supplier_id` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message_body` text NOT NULL,
  `status` enum('unread','read','replied') NOT NULL DEFAULT 'unread',
  `sent_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_inbox`
--

INSERT INTO `supplier_inbox` (`id`, `sender_user_id`, `sender_supplier_id`, `recipient_user_id`, `recipient_supplier_id`, `subject`, `message_body`, `status`, `sent_at`) VALUES
(1, NULL, 4, 3, NULL, 'Testing', 'fffffghdsw', 'read', '2025-08-29 08:51:43'),
(2, NULL, 4, 3, NULL, 'View my verified achievement from Cisco!', 'ertytr', 'read', '2025-08-29 08:53:10'),
(3, NULL, 4, 3, NULL, 'View my verified achievement from Cisco!', 'ertytr', 'read', '2025-08-29 09:13:56'),
(4, NULL, 4, 3, NULL, 'Re: Testing', 'asdfg', 'read', '2025-08-29 09:20:47'),
(5, 3, NULL, NULL, 4, 'Testing', 'ertytuty', 'read', '2025-08-29 08:46:49'),
(6, 3, NULL, NULL, 4, 'View my verified achievement from Cisco!', 'ertgty', 'read', '2025-08-29 08:47:12'),
(7, NULL, 4, 3, NULL, 'as', 'sdd', 'unread', '2025-08-29 10:55:19'),
(8, NULL, 4, 3, NULL, 'as', 'sdd', 'unread', '2025-08-29 10:57:01'),
(9, NULL, 4, 3, NULL, 'Testing', '56', 'read', '2025-08-29 11:31:24'),
(10, 1, NULL, NULL, 4, 'Testing', 'Thanks', 'unread', '2025-08-29 12:09:19'),
(13, 1, NULL, NULL, 1, 'Your contract', 'Here sign your contract', 'read', '2025-08-30 10:16:03'),
(14, 1, NULL, NULL, 1, 'purchase order', 'purchase order', 'unread', '2025-08-30 12:36:56');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_performance`
--

CREATE TABLE `supplier_performance` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `metric` varchar(100) NOT NULL,
  `score` decimal(5,2) NOT NULL,
  `date_recorded` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supplier_proposals`
--

CREATE TABLE `supplier_proposals` (
  `id` int(11) NOT NULL,
  `rfq_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `proposal_file` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` enum('pending','accepted','rejected') DEFAULT 'pending',
  `contract_id` int(11) DEFAULT NULL,
  `submitted_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_proposals`
--

INSERT INTO `supplier_proposals` (`id`, `rfq_id`, `supplier_id`, `proposal_file`, `amount`, `status`, `contract_id`, `submitted_at`) VALUES
(5, 20, 1, 'uploads/proposals/prop_68b29bf19ef1c_picp_advanced (3).sql', 51000.00, 'accepted', 0, '2025-08-30 08:36:33');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_risks`
--

CREATE TABLE `supplier_risks` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `risk_type` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `severity` enum('low','medium','high','critical') NOT NULL,
  `identified_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `email_notifications` tinyint(1) DEFAULT 1 COMMENT '0=disabled, 1=enabled',
  `in_app_notifications` tinyint(1) DEFAULT 1 COMMENT '0=disabled, 1=enabled',
  `two_fa_secret` varchar(255) DEFAULT NULL COMMENT 'Stores the secret for Two-Factor Authentication',
  `last_login_at` datetime DEFAULT NULL COMMENT 'Timestamp of the user''s last successful login',
  `last_login_ip` varchar(45) DEFAULT NULL COMMENT 'IP address of the user''s last successful login',
  `theme` varchar(50) NOT NULL DEFAULT 'light-theme' COMMENT 'User''s preferred theme (e.g., light-theme, dark-theme)',
  `timezone` varchar(100) NOT NULL DEFAULT 'UTC' COMMENT 'User''s local time zone',
  `date_format` varchar(20) NOT NULL DEFAULT 'YYYY-MM-DD' COMMENT 'User''s preferred date format'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `department_id`, `role_id`, `location_id`, `phone_number`, `job_title`, `status`, `created_at`, `updated_at`, `email_notifications`, `in_app_notifications`, `two_fa_secret`, `last_login_at`, `last_login_ip`, `theme`, `timezone`, `date_format`) VALUES
(1, 'Admin User', 'admin@picp.com', '$2y$10$c2.jF7lZycze9Xwz15cKpuxR9SzN9s3NSD3ukgG8wn3b7Ti5LjOQy', 1, 1, 1, '555-123-4567', 'System Administrator', 'active', '2025-08-27 14:25:33', '2025-09-03 08:09:09', 1, 1, NULL, NULL, NULL, 'dark-theme', 'UTC', 'YYYY-MM-DD'),
(3, 'Emma Loic', 'emma@picp.com', '$2y$10$IuND7SS6xR.oO8Zj9G1WG.tdAOVMGGll5vXP/fVqPang6nQDXf39K', 2, 2, 1, '0703497337', 'Freelancing', 'active', '2025-08-28 10:03:48', '2025-08-29 09:57:03', 1, 1, NULL, NULL, NULL, 'light-theme', 'UTC', 'YYYY-MM-DD'),
(4, 'Niringiyimaana Emmanuel', 'emmanuel@picp.com', '$2y$10$534j2yhvJ70YR4.QKs.FUOupFeqb/hnBYTczqHhL2hH/GaE.Fy9zK', 3, 3, 1, '0703497367', 'Finance Tr', 'active', '2025-08-29 13:55:14', '2025-08-29 13:55:14', 1, 1, NULL, NULL, NULL, 'light-theme', 'UTC', 'YYYY-MM-DD'),
(5, 'Tom Cat', 'tom@picp.com', '$2y$10$910B8Yj8dN77aj/4ABEYH.lXwbch1AIqs5.Hqn7i..XkbspxsCsUW', 2, 2, 1, '0703497330', 'requisitoner', 'active', '2025-08-29 16:03:17', '2025-08-29 16:03:17', 1, 1, NULL, NULL, NULL, 'light-theme', 'UTC', 'YYYY-MM-DD');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_sessions`
--
ALTER TABLE `active_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `session_id` (`session_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `budgets`
--
ALTER TABLE `budgets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `contracts`
--
ALTER TABLE `contracts`
  ADD UNIQUE KEY `contract_no` (`contract_no`),
  ADD KEY `proposal_id` (`proposal_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `gl_accounts`
--
ALTER TABLE `gl_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_no` (`account_no`);

--
-- Indexes for table `goods_receipts`
--
ALTER TABLE `goods_receipts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `po_id` (`po_id`),
  ADD KEY `received_by` (`received_by`);

--
-- Indexes for table `grn_items`
--
ALTER TABLE `grn_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `grn_id` (`grn_id`),
  ADD KEY `po_item_id` (`po_item_id`);

--
-- Indexes for table `inbox`
--
ALTER TABLE `inbox`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_inbox_sender` (`sender_id`),
  ADD KEY `fk_inbox_recipient` (`recipient_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_item_location` (`item_id`,`location_id`),
  ADD KEY `fk_location` (`location_id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_no` (`invoice_no`),
  ADD KEY `purchase_order_id` (`purchase_order_id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `gl_account_id` (`gl_account_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `spend_category_id` (`spend_category_id`),
  ADD KEY `items_ibfk_2` (`gl_account_id`);

--
-- Indexes for table `item_catalog`
--
ALTER TABLE `item_catalog`
  ADD UNIQUE KEY `sku` (`sku`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `recipient_id` (`recipient_id`);

--
-- Indexes for table `message_attachments`
--
ALTER TABLE `message_attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `message_id` (`message_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `po_items`
--
ALTER TABLE `po_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `po_no` (`po_no`);

--
-- Indexes for table `requisitions`
--
ALTER TABLE `requisitions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `requisition_no` (`requisition_no`);

--
-- Indexes for table `requisition_items`
--
ALTER TABLE `requisition_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requisition_id` (`requisition_id`),
  ADD KEY `spend_category_id` (`spend_category_id`),
  ADD KEY `gl_account_id` (`gl_account_id`);

--
-- Indexes for table `rfqs`
--
ALTER TABLE `rfqs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rfq_no` (`rfq_no`);

--
-- Indexes for table `rfq_invites`
--
ALTER TABLE `rfq_invites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `rfq_items`
--
ALTER TABLE `rfq_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rfq_id` (`rfq_id`);

--
-- Indexes for table `spend_categories`
--
ALTER TABLE `spend_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_inbox`
--
ALTER TABLE `supplier_inbox`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_user_id` (`sender_user_id`),
  ADD KEY `sender_supplier_id` (`sender_supplier_id`),
  ADD KEY `recipient_user_id` (`recipient_user_id`),
  ADD KEY `recipient_supplier_id` (`recipient_supplier_id`);

--
-- Indexes for table `supplier_proposals`
--
ALTER TABLE `supplier_proposals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rfq_id` (`rfq_id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `active_sessions`
--
ALTER TABLE `active_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `budgets`
--
ALTER TABLE `budgets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `gl_accounts`
--
ALTER TABLE `gl_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `inbox`
--
ALTER TABLE `inbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `message_attachments`
--
ALTER TABLE `message_attachments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `po_items`
--
ALTER TABLE `po_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `requisitions`
--
ALTER TABLE `requisitions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `requisition_items`
--
ALTER TABLE `requisition_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `rfqs`
--
ALTER TABLE `rfqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `rfq_invites`
--
ALTER TABLE `rfq_invites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `rfq_items`
--
ALTER TABLE `rfq_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `spend_categories`
--
ALTER TABLE `spend_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `supplier_inbox`
--
ALTER TABLE `supplier_inbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `supplier_proposals`
--
ALTER TABLE `supplier_proposals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `active_sessions`
--
ALTER TABLE `active_sessions`
  ADD CONSTRAINT `fk_active_sessions_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `budgets`
--
ALTER TABLE `budgets`
  ADD CONSTRAINT `fk_budgets_departments` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `contracts`
--
ALTER TABLE `contracts`
  ADD CONSTRAINT `contracts_ibfk_1` FOREIGN KEY (`proposal_id`) REFERENCES `supplier_proposals` (`id`);

--
-- Constraints for table `inbox`
--
ALTER TABLE `inbox`
  ADD CONSTRAINT `fk_inbox_recipient` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_inbox_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `fk_item` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `fk_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`);

--
-- Constraints for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoice_items_ibfk_2` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_accounts` (`id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`spend_category_id`) REFERENCES `spend_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `items_ibfk_2` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_accounts` (`id`);

--
-- Constraints for table `message_attachments`
--
ALTER TABLE `message_attachments`
  ADD CONSTRAINT `message_attachments_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `supplier_inbox` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `requisition_items`
--
ALTER TABLE `requisition_items`
  ADD CONSTRAINT `fk_requisition_items_gl_accounts` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_accounts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_requisition_items_requisitions` FOREIGN KEY (`requisition_id`) REFERENCES `requisitions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_requisition_items_spend_categories` FOREIGN KEY (`spend_category_id`) REFERENCES `spend_categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `rfq_items`
--
ALTER TABLE `rfq_items`
  ADD CONSTRAINT `rfq_items_ibfk_1` FOREIGN KEY (`rfq_id`) REFERENCES `rfqs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `supplier_inbox`
--
ALTER TABLE `supplier_inbox`
  ADD CONSTRAINT `supplier_inbox_ibfk_1` FOREIGN KEY (`sender_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `supplier_inbox_ibfk_2` FOREIGN KEY (`sender_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `supplier_inbox_ibfk_3` FOREIGN KEY (`recipient_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `supplier_inbox_ibfk_4` FOREIGN KEY (`recipient_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `supplier_proposals`
--
ALTER TABLE `supplier_proposals`
  ADD CONSTRAINT `supplier_proposals_ibfk_1` FOREIGN KEY (`rfq_id`) REFERENCES `rfqs` (`id`),
  ADD CONSTRAINT `supplier_proposals_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
