<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and has the right role
if (!isset($_SESSION["user_id"]) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("location: index.php");
    exit;
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$error = '';
$po_details = null;
$po_items = [];
$conn = connectDB();

// Handle form submission to mark PO as received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid CSRF token. Please try again.";
    } else {
        $po_id = $_POST['po_id'];
        $receipt_notes = isset($_POST['receipt_notes']) ? filter_input(INPUT_POST, 'receipt_notes', FILTER_SANITIZE_STRING) : '';

        $conn->begin_transaction();
        try {
            // Update the purchase order status to 'received'
            $sql_update_po = "UPDATE purchase_orders SET status = 'received', received_date = NOW(), receipt_notes = ? WHERE id = ?";
            $stmt_update_po = $conn->prepare($sql_update_po);
            $stmt_update_po->bind_param("si", $receipt_notes, $po_id);
            if (!$stmt_update_po->execute()) {
                throw new Exception("Error updating PO status: " . $stmt_update_po->error);
            }
            $stmt_update_po->close();
            
            $conn->commit();
            $message = "Goods for Purchase Order have been successfully received!";
            // Redirect to the PO list with a success message
            header("location: view_purchase_orders.php?message=" . urlencode($message));
            exit;

        } catch (Exception $e) {
            $conn->rollback();
            $error = "Transaction failed: " . $e->getMessage();
        }
    }
} else if (isset($_GET['po_id']) && is_numeric($_GET['po_id'])) {
    // Fetch PO details to pre-populate the form
    $po_id = $_GET['po_id'];
    $sql_po = "SELECT po.*, s.name as supplier_name, s.contact_person, s.contact_email, s.contact_phone, 
                      r.requisition_no as requisition_no, r.title as requisition_title
               FROM purchase_orders po 
               JOIN suppliers s ON po.supplier_id = s.id 
               JOIN requisitions r ON po.requisition_id = r.id 
               WHERE po.id = ? AND po.status = 'invoiced'";
    $stmt_po = $conn->prepare($sql_po);
    $stmt_po->bind_param("i", $po_id);
    $stmt_po->execute();
    $result_po = $stmt_po->get_result();

    if ($result_po->num_rows > 0) {
        $po_details = $result_po->fetch_assoc();
        
        // Fetch PO items
        $sql_items = "SELECT poi.*, ri.item_description 
                      FROM purchase_order_items poi 
                      JOIN requisition_items ri ON poi.requisition_item_id = ri.id 
                      WHERE poi.purchase_order_id = ?";
        $stmt_items = $conn->prepare($sql_items);
        $stmt_items->bind_param("i", $po_id);
        $stmt_items->execute();
        $result_items = $stmt_items->get_result();
        
        while ($item = $result_items->fetch_assoc()) {
            $po_items[] = $item;
        }
        $stmt_items->close();
    } else {
        $error = "Purchase Order not found or is not in 'invoiced' status.";
    }
    $stmt_po->close();

} else {
    $error = "Invalid request.";
}
$conn->close();

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = isset($_SESSION['role_name']) ? $_SESSION['role_name'] : getUserRoleName($user_role_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Goods Receipt (GRN) | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 0.35em 0.65em;
        }
        
        .item-row {
            border-left: 4px solid var(--secondary-color);
            background-color: #f8f9fa;
            margin-bottom: 10px;
            border-radius: 5px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        .receipt-summary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1 || $user_role_id == 2) { ?>
            <li class="nav-item">
                <a class="nav-link" href="view_purchase_orders.php">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Purchase Orders</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="#">
                    <i class="fas fa-truck-loading"></i>
                    <span>Goods Receipt</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Goods Receipt (GRN)</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <a href="view_purchase_orders.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to Purchase Orders
                </a>
            </div>
            
            <?php if ($po_details): ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-truck-loading me-2"></i>Goods Receipt Confirmation
                        </div>
                        <div class="card-body">
                            <?php if ($po_details['status'] === 'received'): ?>
                                <div class="alert alert-success">
                                    <i class="fas fa-check-circle me-2"></i>
                                    This Purchase Order has already been marked as received on <?php echo date('M j, Y', strtotime($po_details['received_date'])); ?>.
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Important:</strong> Confirming goods receipt will:
                                    <ul class="mb-0 mt-2">
                                        <li>Update the PO status to "Received"</li>
                                        <li>Record the current date as the receipt date</li>
                                        <li>Complete the procurement cycle for this order</li>
                                    </ul>
                                </div>
                                
                                <form method="post" id="receiptForm">
                                    <input type="hidden" name="po_id" value="<?php echo htmlspecialchars($po_details['id']); ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                    
                                    <div class="mb-4">
                                        <h5>Receipt Confirmation</h5>
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" id="confirmation" required>
                                            <label class="form-check-label" for="confirmation">
                                                I confirm that all goods for this Purchase Order have been received in good condition
                                            </label>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="receipt_notes" class="form-label">Receipt Notes (Optional):</label>
                                            <textarea class="form-control" id="receipt_notes" name="receipt_notes" rows="3" placeholder="Any notes about the received goods, condition, or discrepancies"></textarea>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success btn-lg">
                                        <i class="fas fa-check-circle me-2"></i>Confirm Goods Received
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="dashboard-card mt-4">
                        <div class="card-header">
                            <i class="fas fa-info-circle me-2"></i>Purchase Order Details
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-sm">
                                        <tr>
                                            <th width="40%">PO Number:</th>
                                            <td><?php echo htmlspecialchars($po_details['po_no']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Requisition No:</th>
                                            <td><?php echo htmlspecialchars($po_details['requisition_no']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Requisition Title:</th>
                                            <td><?php echo htmlspecialchars($po_details['requisition_title']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>PO Date:</th>
                                            <td><?php echo date('M j, Y', strtotime($po_details['po_date'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Status:</th>
                                            <td>
                                                <span class="badge 
                                                    <?php 
                                                    if ($po_details['status'] == 'received') echo 'bg-success';
                                                    elseif ($po_details['status'] == 'invoiced') echo 'bg-info';
                                                    elseif ($po_details['status'] == 'ordered') echo 'bg-warning';
                                                    else echo 'bg-secondary';
                                                    ?> status-badge">
                                                    <?php echo ucfirst($po_details['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                
                                <div class="col-md-6">
                                    <table class="table table-sm">
                                        <tr>
                                            <th width="40%">Supplier:</th>
                                            <td><?php echo htmlspecialchars($po_details['supplier_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Person:</th>
                                            <td><?php echo htmlspecialchars($po_details['contact_person']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Email:</th>
                                            <td><?php echo htmlspecialchars($po_details['contact_email']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Phone:</th>
                                            <td><?php echo htmlspecialchars($po_details['contact_phone']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Delivery Address:</th>
                                            <td><?php echo htmlspecialchars($po_details['delivery_address']); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="receipt-summary mt-4">
                                <h5 class="text-white">Financial Summary</h5>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="d-block">Total Order Value</span>
                                        <h3 class="text-white mb-0">$<?php echo number_format($po_details['total_amount'], 2); ?></h3>
                                    </div>
                                    <div>
                                        <span class="d-block">Tax Amount</span>
                                        <h4 class="text-white mb-0">$<?php echo number_format($po_details['tax_amount'], 2); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($po_items)): ?>
                    <div class="dashboard-card mt-4">
                        <div class="card-header">
                            <i class="fas fa-list me-2"></i>Order Items
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Item Description</th>
                                            <th>Quantity</th>
                                            <th>Unit Price</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($po_items as $item): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($item['item_description']); ?></td>
                                            <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                            <td>$<?php echo number_format($item['unit_price'], 2); ?></td>
                                            <td>$<?php echo number_format($item['total_price'], 2); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="col-md-4">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-lightbulb me-2"></i>Receiving Guidelines
                        </div>
                        <div class="card-body">
                            <div class="alert alert-info">
                                <h6><i class="fas fa-info-circle me-1"></i>Receiving Checklist</h6>
                                <ul class="small mb-0 ps-3">
                                    <li>Verify all items against the packing slip</li>
                                    <li>Check quantities match the purchase order</li>
                                    <li>Inspect items for damage or defects</li>
                                    <li>Note any discrepancies in the receipt notes</li>
                                    <li>Ensure proper storage conditions</li>
                                </ul>
                            </div>
                            
                            <div class="alert alert-warning">
                                <h6><i class="fas fa-exclamation-triangle me-1"></i>Important Notes</h6>
                                <ul class="small mb-0 ps-3">
                                    <li>This action cannot be undone</li>
                                    <li>Only confirm receipt after physical verification</li>
                                    <li>Report any discrepancies immediately</li>
                                    <li>Keep all documentation for audit purposes</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-card mt-4">
                        <div class="card-header">
                            <i class="fas fa-history me-2"></i>Recent Activity
                        </div>
                        <div class="card-body">
                            <div class="timeline">
                                <div class="timeline-item">
                                    <div class="timeline-content">
                                        <div class="timeline-title">PO Created</div>
                                        <div class="timeline-date"><?php echo date('M j, Y', strtotime($po_details['po_date'])); ?></div>
                                    </div>
                                </div>
                                <div class="timeline-item">
                                    <div class="timeline-content">
                                        <div class="timeline-title">Ordered from Supplier</div>
                                        <div class="timeline-date"><?php echo date('M j, Y', strtotime($po_details['po_date'])); ?></div>
                                    </div>
                                </div>
                                <div class="timeline-item">
                                    <div class="timeline-content">
                                        <div class="timeline-title">Invoice Received</div>
                                        <div class="timeline-date">Status: Invoiced</div>
                                    </div>
                                </div>
                                <div class="timeline-item">
                                    <div class="timeline-content">
                                        <div class="timeline-title">Goods Receipt</div>
                                        <div class="timeline-date">Pending Confirmation</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <?php echo htmlspecialchars($error ? $error : "Purchase Order not found or is not in 'invoiced' status."); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        // Form validation
        document.getElementById('receiptForm')?.addEventListener('submit', function(e) {
            const confirmation = document.getElementById('confirmation');
            
            if (!confirmation.checked) {
                e.preventDefault();
                alert('Please confirm that all goods have been received in good condition.');
                confirmation.focus();
                return false;
            }
            
            if (!confirm('Are you sure you want to confirm receipt of all goods for this Purchase Order? This action cannot be undone.')) {
                e.preventDefault();
                return false;
            }
        });
    </script>
</body>
</html>