<?php
session_start();
require_once 'users.php';

// Check if the user is logged in and has the right role
if (!isset($_SESSION["user_id"]) || $_SESSION['role_id'] != 1) {
    header("location: index.php");
    exit;
}

// Get user role name for display
$user_role_id = $_SESSION['role_id'];
$role_name = getUserRoleName($user_role_id);
$_SESSION['role_name'] = $role_name;

$message = '';
$requisition = null;
$requisition_items = [];
$suppliers = [];

$conn = connectDB();

// Enable mysqli exceptions for debugging
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // Handle form submission to create the PO
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $requisition_id = $_POST['requisition_id'];
        $supplier_id = $_POST['supplier_id'];
        $total_amount = $_POST['total_amount'];
        $po_no = "PO-" . date("Ymd") . "-" . uniqid();

        $conn->begin_transaction();

        // Step 1: Insert into purchase_orders
        $sql_po = "INSERT INTO purchase_orders (po_no, requisition_id, supplier_id, total_amount, status)
                   VALUES (?, ?, ?, ?, 'issued')";
        $stmt_po = $conn->prepare($sql_po);
        $stmt_po->bind_param("siid", $po_no, $requisition_id, $supplier_id, $total_amount);
        $stmt_po->execute();
        $po_id = $stmt_po->insert_id;
        $stmt_po->close();

        // Step 2: Update requisition status
        $sql_req = "UPDATE requisitions SET status = 'po_created' WHERE id = ?";
        $stmt_req = $conn->prepare($sql_req);
        $stmt_req->bind_param("i", $requisition_id);
        $stmt_req->execute();
        $stmt_req->close();

        // Step 3: Fetch requisition items
        $sql_items = "SELECT ri.item_id, ri.quantity, ri.estimated_cost, ri.gl_account_id, ri.spend_category_id, i.item_description
                      FROM requisition_items ri
                      JOIN items i ON ri.item_id = i.id
                      WHERE ri.requisition_id = ?";
        $stmt_items = $conn->prepare($sql_items);
        $stmt_items->bind_param("i", $requisition_id);
        $stmt_items->execute();
        $result_items = $stmt_items->get_result();

        // Step 4: Insert items into po_items
        $sql_po_item = "INSERT INTO po_items (purchase_order_id, item_description, quantity, unit_price, gl_account_id, spend_category_id)
                        VALUES (?, ?, ?, ?, ?, ?)";
        $stmt_po_item = $conn->prepare($sql_po_item);

        while ($item = $result_items->fetch_assoc()) {
            // Ensure numeric values are correct
            $quantity = (int)$item['quantity'];
            $unit_price = (float)$item['estimated_cost'];
            $gl_account = isset($item['gl_account_id']) ? (int)$item['gl_account_id'] : null;
            $spend_category = isset($item['spend_category_id']) ? (int)$item['spend_category_id'] : null;

            $stmt_po_item->bind_param(
                "isidii",
                $po_id,
                $item['item_description'],
                $quantity,
                $unit_price,
                $gl_account,
                $spend_category
            );
            $stmt_po_item->execute();
        }

        $stmt_items->close();
        $stmt_po_item->close();

        $conn->commit();
        $message = '<div class="alert alert-success" role="alert">Purchase Order #' . htmlspecialchars($po_no) . ' created successfully!</div>';

    } else if (isset($_GET['requisition_id']) || isset($_POST['requisition_id'])) {
        $requisition_id = $_GET['requisition_id'] ?? $_POST['requisition_id'];

        // Fetch requisition details
        $sql_req = "SELECT r.*, u.name as requested_by_name, d.name as department_name
                    FROM requisitions r
                    JOIN users u ON r.requested_by = u.id
                    JOIN departments d ON r.department_id = d.id
                    WHERE r.id = ?";
        $stmt_req = $conn->prepare($sql_req);
        $stmt_req->bind_param("i", $requisition_id);
        $stmt_req->execute();
        $result_req = $stmt_req->get_result();

        if ($result_req->num_rows > 0) {
            $requisition = $result_req->fetch_assoc();

            // Fetch requisition items
            $sql_items = "SELECT ri.*, i.item_description
                          FROM requisition_items ri
                          JOIN items i ON ri.item_id = i.id
                          WHERE ri.requisition_id = ?";
            $stmt_items = $conn->prepare($sql_items);
            $stmt_items->bind_param("i", $requisition_id);
            $stmt_items->execute();
            $result_items = $stmt_items->get_result();
            while ($row = $result_items->fetch_assoc()) {
                $requisition_items[] = $row;
            }
            $stmt_items->close();

            // Fetch active suppliers
            $sql_suppliers = "SELECT id, name FROM suppliers WHERE status = 'active'";
            $result_suppliers = $conn->query($sql_suppliers);
            while ($row = $result_suppliers->fetch_assoc()) {
                $suppliers[] = $row;
            }
        }
        $stmt_req->close();
    }

} catch (Exception $e) {
    if ($conn->errno) $conn->rollback();
    $message = '<div class="alert alert-danger" role="alert">Error: ' . $e->getMessage() . '</div>';
} finally {
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Purchase Order | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .item-row {
            border-left: 4px solid var(--secondary-color);
            padding: 15px;
            margin-bottom: 15px;
            background-color: var(--light-bg);
            border-radius: 8px;
        }
        
        .total-display {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary-color);
            padding: 12px 20px;
            background-color: #eaecf4;
            border-radius: 8px;
        }
        
        .required-field::after {
            content: "*";
            color: var(--accent-color);
            margin-left: 4px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($_SESSION['role_name']); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0">Create Purchase Order</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="dashboard-card mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h4 class="m-0"><i class="fas fa-file-purchase-order me-2"></i>Create Purchase Order</h4>
                            <a href="view_requisitions.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-1"></i> Back to Requisitions
                            </a>
                        </div>
                        <div class="card-body">
                            <?php echo $message; ?>
                            
                            <?php if ($requisition) { ?>
                            <div class="alert alert-info mb-4">
                                <h5 class="alert-heading"><i class="fas fa-info-circle me-2"></i>Creating Purchase Order</h5>
                                <p class="mb-0">You are creating a purchase order based on the selected requisition. Please review all information before finalizing.</p>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="dashboard-card border-left-primary mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0"><i class="fas fa-file-alt me-2"></i>Requisition Details</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <p><strong>Requisition #:</strong><br> <?php echo htmlspecialchars($requisition['requisition_no']); ?></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <p><strong>Title:</strong><br> <?php echo htmlspecialchars($requisition['title']); ?></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <p><strong>Total Amount:</strong><br> $<?php echo htmlspecialchars(number_format($requisition['total_amount'], 2)); ?></p>
                                                </div>
                                            </div>
                                            <div class="row mt-3">
                                                <div class="col-md-4">
                                                    <p><strong>Requested By:</strong><br> <?php echo htmlspecialchars($requisition['requested_by_name']); ?></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <p><strong>Department:</strong><br> <?php echo htmlspecialchars($requisition['department_name']); ?></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <p><strong>Status:</strong><br> <?php echo htmlspecialchars($requisition['status']); ?></p>
                                                </div>
                                            </div>
                                            <?php if (!empty($requisition['justification'])) { ?>
                                            <div class="row mt-3">
                                                <div class="col-md-12">
                                                    <p><strong>Justification:</strong><br> <?php echo htmlspecialchars($requisition['justification']); ?></p>
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="dashboard-card mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0"><i class="fas fa-list-alt me-2"></i>Requisition Items</h6>
                                </div>
                                <div class="card-body">
                                    <?php 
                                    $item_total = 0;
                                    foreach ($requisition_items as $item) { 
                                        $item_total += $item['quantity'] * $item['estimated_cost'];
                                    ?>
                                        <div class="item-row mb-3">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p><strong>Item Description:</strong><br> <?php echo htmlspecialchars($item['item_description']); ?></p>
                                                </div>
                                                <div class="col-md-2">
                                                    <p><strong>Quantity:</strong><br> <?php echo htmlspecialchars($item['quantity']); ?></p>
                                                </div>
                                                <div class="col-md-2">
                                                    <p><strong>Unit Price:</strong><br> $<?php echo number_format($item['estimated_cost'], 2); ?></p>
                                                </div>
                                                <div class="col-md-2">
                                                    <p><strong>Total:</strong><br> $<?php echo number_format($item['quantity'] * $item['estimated_cost'], 2); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    
                                    <div class="row mt-4">
                                        <div class="col-md-12 text-end">
                                            <div class="total-display d-inline-block px-4 py-2">
                                                Total: $<?php echo number_format($item_total, 2); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <form action="create_po.php" method="post" id="poForm">
                                <input type="hidden" name="requisition_id" value="<?php echo htmlspecialchars($requisition['id']); ?>">
                                <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($requisition['total_amount']); ?>">
                                
                                <div class="dashboard-card mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0"><i class="fas fa-truck me-2"></i>Supplier Selection</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="form-group">
                                                    <label for="supplier_id" class="form-label required-field">Select Supplier</label>
                                                    <select name="supplier_id" id="supplier_id" class="form-select" required>
                                                        <option value="">Select a Supplier</option>
                                                        <?php foreach ($suppliers as $supplier) { ?>
                                                            <option value="<?php echo htmlspecialchars($supplier['id']); ?>"><?php echo htmlspecialchars($supplier['name']); ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mt-4">
                                    <div class="col-md-12 text-end">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fas fa-check-circle me-1"></i> Generate Purchase Order
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <?php } else { ?>
                                <div class="alert alert-warning" role="alert">
                                    <h4 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>No Valid Requisition</h4>
                                    <p>No valid requisition found for purchase order creation. Please select a requisition from the requisitions page.</p>
                                    <hr>
                                    <a href="view_requisitions.php" class="btn btn-primary">Go to Requisitions</a>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script>
        // Form validation
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('poForm');
            
            if (form) {
                form.addEventListener('submit', function(e) {
                    const supplierSelect = document.getElementById('supplier_id');
                    
                    if (!supplierSelect.value) {
                        e.preventDefault();
                        supplierSelect.classList.add('is-invalid');
                        alert('Please select a supplier.');
                    } else {
                        supplierSelect.classList.remove('is-invalid');
                    }
                });
            }
        });
    </script>
</body>
</html>