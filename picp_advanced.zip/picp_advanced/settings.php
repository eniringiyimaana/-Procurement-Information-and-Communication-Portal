<?php
session_start();
require_once 'users.php';

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

$message = '';
$message_type = '';
$user_id = $_SESSION['user_id'];
$conn = connectDB();

// Fetch current user data for display and pre-filling forms
$sql_fetch = "SELECT id, name, email, phone_number, job_title, department_id, role_id, location_id, password_hash, email_notifications, in_app_notifications, two_fa_secret, last_login_at, last_login_ip, theme, timezone, date_format FROM users WHERE id = ?";
$stmt_fetch = $conn->prepare($sql_fetch);
$stmt_fetch->bind_param("i", $user_id);
$stmt_fetch->execute();
$result_fetch = $stmt_fetch->get_result();
$user_data = $result_fetch->fetch_assoc();
$stmt_fetch->close();

if (!$user_data) {
    $message = "Error: User data not found.";
    $message_type = "danger";
}

// Handle all form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'update_profile':
            $new_name = trim($_POST['name']);
            $new_email = trim($_POST['email']);
            $new_phone_number = trim($_POST['phone_number']);
            $new_job_title = trim($_POST['job_title']);

            if (empty($new_name) || empty($new_email)) {
                $message = "Name and Email cannot be empty.";
                $message_type = "warning";
            } else {
                $sql_update = "UPDATE users SET name = ?, email = ?, phone_number = ?, job_title = ? WHERE id = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param("ssssi", $new_name, $new_email, $new_phone_number, $new_job_title, $user_id);
                if ($stmt_update->execute()) {
                    $message = "Profile updated successfully!";
                    $message_type = "success";
                    $user_data['name'] = $new_name;
                    $user_data['email'] = $new_email;
                    $user_data['phone_number'] = $new_phone_number;
                    $user_data['job_title'] = $new_job_title;
                    $_SESSION['username'] = $new_name;
                } else {
                    $message = "Error updating profile: " . $conn->error;
                    $message_type = "danger";
                }
                $stmt_update->close();
            }
            break;

        case 'change_password':
            $current_password = trim($_POST['current_password']);
            $new_password = trim($_POST['new_password']);
            $confirm_password = trim($_POST['confirm_password']);

            if (!password_verify($current_password, $user_data['password_hash'])) {
                $message = "Incorrect current password.";
                $message_type = "danger";
            } elseif ($new_password !== $confirm_password) {
                $message = "New passwords do not match.";
                $message_type = "warning";
            } elseif (strlen($new_password) < 8) {
                $message = "New password must be at least 8 characters long.";
                $message_type = "warning";
            } else {
                $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $sql_password = "UPDATE users SET password_hash = ? WHERE id = ?";
                $stmt_password = $conn->prepare($sql_password);
                $stmt_password->bind_param("si", $new_password_hash, $user_id);
                if ($stmt_password->execute()) {
                    $message = "Password changed successfully!";
                    $message_type = "success";
                    $user_data['password_hash'] = $new_password_hash;
                } else {
                    $message = "Error changing password: " . $conn->error;
                    $message_type = "danger";
                }
                $stmt_password->close();
            }
            break;

        case 'update_notifications':
            $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
            $in_app_notifications = isset($_POST['in_app_notifications']) ? 1 : 0;

            $sql_notify = "UPDATE users SET email_notifications = ?, in_app_notifications = ? WHERE id = ?";
            $stmt_notify = $conn->prepare($sql_notify);
            $stmt_notify->bind_param("iii", $email_notifications, $in_app_notifications, $user_id);
            if ($stmt_notify->execute()) {
                $message = "Notification preferences updated successfully!";
                $message_type = "success";
                $user_data['email_notifications'] = $email_notifications;
                $user_data['in_app_notifications'] = $in_app_notifications;
            } else {
                $message = "Error updating notification preferences: " . $conn->error;
                $message_type = "danger";
            }
            $stmt_notify->close();
            break;

        case 'update_display':
            $theme = $_POST['theme'];
            $timezone = $_POST['timezone'];
            $date_format = $_POST['date_format'];

            $sql_display = "UPDATE users SET theme = ?, timezone = ?, date_format = ? WHERE id = ?";
            $stmt_display = $conn->prepare($sql_display);
            $stmt_display->bind_param("sssi", $theme, $timezone, $date_format, $user_id);
            if ($stmt_display->execute()) {
                $message = "Display and localization settings updated successfully!";
                $message_type = "success";
                $user_data['theme'] = $theme;
                $user_data['timezone'] = $timezone;
                $user_data['date_format'] = $date_format;
            } else {
                $message = "Error updating display settings: " . $conn->error;
                $message_type = "danger";
            }
            $stmt_display->close();
            break;

        case 'logout_all':
            $sql_delete_sessions = "DELETE FROM active_sessions WHERE user_id = ?";
            $stmt_delete = $conn->prepare($sql_delete_sessions);
            $stmt_delete->bind_param("i", $user_id);
            if ($stmt_delete->execute()) {
                $message = "You have been logged out of all other devices.";
                $message_type = "success";
            } else {
                $message = "Error logging out of other devices: " . $conn->error;
                $message_type = "danger";
            }
            $stmt_delete->close();
            break;
    }
}
$conn->close();

// Set the user's preferred timezone for this session
if (!empty($user_data['timezone'])) {
    date_default_timezone_set($user_data['timezone']);
}

// Function to format timestamps based on user preference
function format_date_time($timestamp, $format_preference) {
    if (empty($timestamp)) {
        return 'N/A';
    }
    $php_format = '';
    switch ($format_preference) {
        case 'MM-DD-YYYY':
            $php_format = 'm-d-Y';
            break;
        case 'DD-MM-YYYY':
            $php_format = 'd-m-Y';
            break;
        case 'YYYY-MM-DD':
            $php_format = 'Y-m-d';
            break;
        default:
            $php_format = 'Y-m-d';
            break;
    }
    return date($php_format . ' H:i:s', strtotime($timestamp));
}

// Fetch active sessions for display
$sessions = [];
$conn_sessions = connectDB();
$sql_sessions = "SELECT login_time, ip_address, user_agent FROM active_sessions WHERE user_id = ?";
$stmt_sessions = $conn_sessions->prepare($sql_sessions);
$stmt_sessions->bind_param("i", $user_id);
$stmt_sessions->execute();
$result_sessions = $stmt_sessions->get_result();
while ($row = $result_sessions->fetch_assoc()) {
    $sessions[] = $row;
}
$stmt_sessions->close();
$conn_sessions->close();

// Get user role for sidebar
$user_role_id = $_SESSION['role_id'];
$role_name = $_SESSION['role_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Settings | Procurement System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .sidebar {
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .section-title {
            border-left: 4px solid var(--secondary-color);
            padding-left: 10px;
            margin: 25px 0 15px;
            font-weight: 600;
        }
        
        .settings-nav .nav-link {
            color: #495057;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 5px;
        }
        
        .settings-nav .nav-link.active {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .settings-nav .nav-link:hover:not(.active) {
            background-color: #e9ecef;
        }
        
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 38px;
            color: #6c757d;
        }
        
        .session-item {
            border-left: 3px solid var(--secondary-color);
            padding-left: 15px;
            margin-bottom: 15px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                text-align: center;
            }
            
            .sidebar .nav-link span {
                display: none;
            }
            
            .sidebar .nav-link i {
                margin-right: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4>Procurement System</h4>
            <div class="text-muted small"><?php echo htmlspecialchars($role_name); ?></div>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create_requisition.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Create Requisition</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_my_requisitions.php">
                    <i class="fas fa-list"></i>
                    <span>My Requisitions</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inbox.php">
                    <i class="fas fa-inbox"></i>
                    <span>Inbox</span>
                </a>
            </li>
            <?php if ($user_role_id == 1 || $user_role_id == 2 || $user_role_id == 3) { ?>
            <li class="nav-item">
                <a class="nav-link" href="approve_requisitions.php">
                    <i class="fas fa-check-circle"></i>
                    <span>Approve Requisitions</span>
                </a>
            </li>
            <?php } ?>
            <?php if ($user_role_id == 1) { ?>
            <li class="nav-item">
                <a class="nav-link" href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>My Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="settings.php">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <div class="container-fluid">
                <h2 class="mb-0"><i class="fas fa-cog me-2"></i>Settings</h2>
                <div class="d-flex align-items-center">
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    <div class="dropdown">
                        <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Content -->
        <div class="container-fluid">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                    <i class="fas <?php echo $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> me-2"></i>
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <!-- Settings Navigation -->
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <i class="fas fa-sliders-h me-2"></i>Settings Menu
                        </div>
                        <div class="card-body p-0">
                            <div class="list-group list-group-flush settings-nav" id="settingsTabs" role="tablist">
                                <a class="list-group-item list-group-item-action active" id="profile-tab" data-bs-toggle="tab" href="#profile" role="tab">
                                    <i class="fas fa-user me-2"></i>Profile
                                </a>
                                <a class="list-group-item list-group-item-action" id="password-tab" data-bs-toggle="tab" href="#password" role="tab">
                                    <i class="fas fa-key me-2"></i>Password
                                </a>
                                <a class="list-group-item list-group-item-action" id="notifications-tab" data-bs-toggle="tab" href="#notifications" role="tab">
                                    <i class="fas fa-bell me-2"></i>Notifications
                                </a>
                                <a class="list-group-item list-group-item-action" id="display-tab" data-bs-toggle="tab" href="#display" role="tab">
                                    <i class="fas fa-paint-brush me-2"></i>Display
                                </a>
                                <a class="list-group-item list-group-item-action" id="security-tab" data-bs-toggle="tab" href="#security" role="tab">
                                    <i class="fas fa-shield-alt me-2"></i>Security
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Settings Content -->
                <div class="col-md-9">
                    <div class="tab-content" id="settingsTabContent">
                        <!-- Profile Tab -->
                        <div class="tab-pane fade show active" id="profile" role="tabpanel">
                            <div class="dashboard-card">
                                <div class="card-header">
                                    <i class="fas fa-user me-2"></i>Profile Information
                                </div>
                                <div class="card-body">
                                    <form action="settings.php" method="post">
                                        <input type="hidden" name="action" value="update_profile">
                                        
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="name" class="form-label">Full Name</label>
                                                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user_data['name']); ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="email" class="form-label">Email Address</label>
                                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="phone_number" class="form-label">Phone Number</label>
                                                <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($user_data['phone_number']); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="job_title" class="form-label">Job Title</label>
                                                <input type="text" class="form-control" id="job_title" name="job_title" value="<?php echo htmlspecialchars($user_data['job_title']); ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-save me-1"></i> Update Profile
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Password Tab -->
                        <div class="tab-pane fade" id="password" role="tabpanel">
                            <div class="dashboard-card">
                                <div class="card-header">
                                    <i class="fas fa-key me-2"></i>Change Password
                                </div>
                                <div class="card-body">
                                    <form action="settings.php" method="post" id="passwordForm">
                                        <input type="hidden" name="action" value="change_password">
                                        
                                        <div class="mb-3">
                                            <label for="current_password" class="form-label">Current Password</label>
                                            <div class="position-relative">
                                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                                                <span class="password-toggle" onclick="togglePassword('current_password')">
                                                    <i class="fas fa-eye"></i>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="new_password" class="form-label">New Password</label>
                                            <div class="position-relative">
                                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                                <span class="password-toggle" onclick="togglePassword('new_password')">
                                                    <i class="fas fa-eye"></i>
                                                </span>
                                            </div>
                                            <div class="form-text">Password must be at least 8 characters long.</div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                                            <div class="position-relative">
                                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                                <span class="password-toggle" onclick="togglePassword('confirm_password')">
                                                    <i class="fas fa-eye"></i>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-warning">
                                                <i class="fas fa-key me-1"></i> Change Password
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Notifications Tab -->
                        <div class="tab-pane fade" id="notifications" role="tabpanel">
                            <div class="dashboard-card">
                                <div class="card-header">
                                    <i class="fas fa-bell me-2"></i>Notification Preferences
                                </div>
                                <div class="card-body">
                                    <form action="settings.php" method="post">
                                        <input type="hidden" name="action" value="update_notifications">
                                        
                                        <div class="mb-3">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" value="1" <?php echo ($user_data['email_notifications'] == 1) ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="email_notifications">Receive Email Notifications</label>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" id="in_app_notifications" name="in_app_notifications" value="1" <?php echo ($user_data['in_app_notifications'] == 1) ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="in_app_notifications">Receive In-App Pop-up Notifications</label>
                                            </div>
                                        </div>
                                        
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-save me-1"></i> Update Notification Settings
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Display Tab -->
                        <div class="tab-pane fade" id="display" role="tabpanel">
                            <div class="dashboard-card">
                                <div class="card-header">
                                    <i class="fas fa-paint-brush me-2"></i>Display & Localization
                                </div>
                                <div class="card-body">
                                    <form action="settings.php" method="post">
                                        <input type="hidden" name="action" value="update_display">
                                        
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="theme" class="form-label">Theme</label>
                                                <select class="form-select" id="theme" name="theme">
                                                    <option value="light-theme" <?php echo ($user_data['theme'] == 'light-theme') ? 'selected' : ''; ?>>Light</option>
                                                    <option value="dark-theme" <?php echo ($user_data['theme'] == 'dark-theme') ? 'selected' : ''; ?>>Dark</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="timezone" class="form-label">Time Zone</label>
                                                <select class="form-select" id="timezone" name="timezone">
                                                    <option value="UTC" <?php echo ($user_data['timezone'] == 'UTC') ? 'selected' : ''; ?>>UTC</option>
                                                    <option value="America/New_York" <?php echo ($user_data['timezone'] == 'America/New_York') ? 'selected' : ''; ?>>America/New_York</option>
                                                    <option value="Europe/London" <?php echo ($user_data['timezone'] == 'Europe/London') ? 'selected' : ''; ?>>Europe/London</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="date_format" class="form-label">Date Format</label>
                                            <select class="form-select" id="date_format" name="date_format">
                                                <option value="MM-DD-YYYY" <?php echo ($user_data['date_format'] == 'MM-DD-YYYY') ? 'selected' : ''; ?>>MM-DD-YYYY</option>
                                                <option value="DD-MM-YYYY" <?php echo ($user_data['date_format'] == 'DD-MM-YYYY') ? 'selected' : ''; ?>>DD-MM-YYYY</option>
                                                <option value="YYYY-MM-DD" <?php echo ($user_data['date_format'] == 'YYYY-MM-DD') ? 'selected' : ''; ?>>YYYY-MM-DD</option>
                                            </select>
                                        </div>
                                        
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-save me-1"></i> Update Display Settings
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Security Tab -->
                        <div class="tab-pane fade" id="security" role="tabpanel">
                            <div class="dashboard-card">
                                <div class="card-header">
                                    <i class="fas fa-shield-alt me-2"></i>Security Settings
                                </div>
                                <div class="card-body">
                                    <h5 class="mb-3">Last Login Information</h5>
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <p><strong>Date & Time:</strong> <?php echo format_date_time($user_data['last_login_at'], $user_data['date_format'] ?? 'YYYY-MM-DD'); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><strong>IP Address:</strong> <?php echo htmlspecialchars($user_data['last_login_ip'] ?? 'N/A'); ?></p>
                                        </div>
                                    </div>
                                    
                                    <h5 class="mb-3">Active Sessions</h5>
                                    <?php if (!empty($sessions)): ?>
                                        <?php foreach ($sessions as $session): ?>
                                            <div class="session-item">
                                                <p class="mb-1">
                                                    <strong>Logged in on:</strong> <?php echo format_date_time($session['login_time'], $user_data['date_format'] ?? 'YYYY-MM-DD'); ?>
                                                </p>
                                                <p class="mb-1">
                                                    <strong>IP Address:</strong> <?php echo htmlspecialchars($session['ip_address']); ?>
                                                </p>
                                                <p class="mb-0 text-muted small">
                                                    <strong>Device:</strong> <?php echo htmlspecialchars($session['user_agent']); ?>
                                                </p>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p class="text-muted">No active sessions found.</p>
                                    <?php endif; ?>
                                    
                                    <div class="mt-4">
                                        <form action="settings.php" method="post" onsubmit="return confirm('Are you sure you want to log out of all other devices?');">
                                            <input type="hidden" name="action" value="logout_all">
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fas fa-sign-out-alt me-1"></i> Log out of all devices
                                            </button>
                                        </form>
                                    </div>
                                    
                                    <hr class="my-4">
                                    
                                    <h5 class="mb-3">Two-Factor Authentication (2FA)</h5>
                                    <?php if (empty($user_data['two_fa_secret'])): ?>
                                        <p class="text-muted">Two-factor authentication is currently disabled.</p>
                                        <button class="btn btn-outline-primary" onclick="start2FA()">
                                            <i class="fas fa-shield-alt me-1"></i> Enable 2FA
                                        </button>
                                        <div id="2fa-setup" class="mt-3" style="display:none;">
                                            <p>Scan the QR code with your authenticator app (e.g., Google Authenticator) or enter the code manually:</p>
                                            <p><strong>Secret Code:</strong> <span id="2fa-secret"></span></p>
                                            <img id="2fa-qr" src="" alt="2FA QR Code" class="img-fluid mb-3">
                                            <form action="settings.php" method="post">
                                                <input type="hidden" name="action" value="confirm_2fa">
                                                <input type="hidden" name="2fa_secret" id="confirm-2fa-secret">
                                                <div class="mb-3">
                                                    <label for="2fa-code" class="form-label">Enter 6-digit code:</label>
                                                    <input type="text" class="form-control" id="2fa-code" name="2fa_code" required>
                                                </div>
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-check me-1"></i> Confirm and Enable
                                                </button>
                                            </form>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-success">
                                            <i class="fas fa-check-circle me-1"></i> Two-factor authentication is currently enabled.
                                        </p>
                                        <form action="settings.php" method="post">
                                            <input type="hidden" name="action" value="disable_2fa">
                                            <button type="submit" class="btn btn-outline-danger">
                                                <i class="fas fa-times me-1"></i> Disable 2FA
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    <script>
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const icon = input.nextElementSibling.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        function start2FA() {
            // In a real application, you would make an AJAX call here to generate the secret and QR code.
            // For demonstration, these are placeholders.
            const secret = 'YOUR_GENERATED_SECRET';
            const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=otpauth://totp/YourApp:<?php echo urlencode($user_data['email']); ?>?secret=' + secret + '&issuer=YourApp';
            document.getElementById('2fa-secret').textContent = secret;
            document.getElementById('2fa-qr').src = qrUrl;
            document.getElementById('confirm-2fa-secret').value = secret;
            document.getElementById('2fa-setup').style.display = 'block';
        }
        
        // Form validation
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (newPassword.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters long.');
                return false;
            }
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                alert('New passwords do not match.');
                return false;
            }
        });
    </script>
</body>
</html>